<?php
// customer/dashboard.php - Modern Customer Dashboard
require_once '../config/config.php';
require_once '../includes/customer.php';

// Require customer access
requireRole('customer');

$customer_id = getCurrentUser()['id'];
$customer_obj = new Customer(getDBConnection());
$customer_data = $customer_obj->getCustomerById($customer_id);

// Get customer statistics
$owned_plots_count = count($customer_obj->getCustomerProperties($customer_id));
$favorite_plots_count = count($customer_obj->getCustomerFavorites($customer_id));

$alert = getAlert();
?>

<!DOCTYPE html>
<html lang="lo">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ແຜງຄວບຄຸມລູກຄ້າ - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/themes.css">
    <link rel="stylesheet" href="../assets/css/image-fixes.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <!-- Customer Header -->
    <header class="header">
        <nav class="nav container">
            <a href="../index.php" class="logo">
                <span style="font-weight: 700; font-size: 1.8rem;">PPS Land</span>
            </a>
            <ul class="nav-menu">
                <li><a href="../index.php">ໜ້າຫຼັກ</a></li>
                <li><a href="../projects.php">ໂຄງການ</a></li>
                <li><a href="../plots.php">ແປງທີ່ດິນ</a></li>
                <li><a href="dashboard.php" style="color: var(--accent-color);">ແຜງຄວບຄຸມ</a></li>
                <li><a href="my_properties.php">ຊັບສິນຂອງຂ້ອຍ</a></li>
                <li><a href="favorites.php">ລາຍການທີ່ຊື່ນຊອບ</a></li>
                <li><a href="appointments.php">ນັດໝາຍ</a></li>
                <li><a href="../logout.php">ອອກຈາກລະບົບ</a></li>
            </ul>
            <button class="nav-toggle">☰</button>
        </nav>
    </header>

    <!-- Customer Dashboard Main -->
    <main style="margin-top: 80px; min-height: calc(100vh - 80px); background: var(--background-color);">
        <div class="container" style="padding: 40px 20px;">
            
            <!-- Welcome Header -->
            <div class="fade-in" style="text-align: center; margin-bottom: 40px;">
                <h1 style="font-size: 2.5rem; font-weight: 700; color: var(--text-primary); margin-bottom: 1rem;">
                    ຍິນດີຕ້ອນຮັບ, <?php echo htmlspecialchars($customer_data["first_name"]); ?>!
                </h1>
                <p style="color: var(--text-secondary); font-size: 1.1rem;">
                    ນີ້ແມ່ນພາບລວມຂອງບັນຊີຂອງທ່ານ ແລະ ຊັບສິນທີ່ທ່ານມີ
                </p>
            </div>

            <!-- Alert Messages -->
            <?php if ($alert): ?>
            <div class="container">
                <div class="alert alert-<?php echo $alert['type']; ?> fade-in" style="margin-bottom: 2rem;">
                    <?php echo htmlspecialchars($alert['message']); ?>
                </div>
            </div>
            <?php endif; ?>

            <!-- Statistics Cards -->
            <div class="grid grid-4 slide-up" style="margin-bottom: 40px;">
                <div class="card">
                    <div style="text-align: center;">
                        <div style="font-size: 3rem; color: var(--primary-color); margin-bottom: 1rem;">
                            <i class="fas fa-map-marked-alt"></i>
                        </div>
                        <div style="font-size: 2rem; font-weight: 700; color: var(--text-primary); margin-bottom: 0.5rem;">
                            <?php echo $owned_plots_count; ?>
                        </div>
                        <div style="color: var(--text-secondary); font-weight: 500;">
                            ຊັບສິນທີ່ຂ້ອຍມີ
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div style="text-align: center;">
                        <div style="font-size: 3rem; color: var(--accent-color); margin-bottom: 1rem;">
                            <i class="fas fa-heart"></i>
                        </div>
                        <div style="font-size: 2rem; font-weight: 700; color: var(--text-primary); margin-bottom: 0.5rem;">
                            <?php echo $favorite_plots_count; ?>
                        </div>
                        <div style="color: var(--text-secondary); font-weight: 500;">
                            ລາຍການທີ່ຊື່ນຊອບ
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div style="text-align: center;">
                        <div style="font-size: 3rem; color: var(--secondary-color); margin-bottom: 1rem;">
                            <i class="fas fa-calendar-check"></i>
                        </div>
                        <div style="font-size: 2rem; font-weight: 700; color: var(--text-primary); margin-bottom: 0.5rem;">
                            0
                        </div>
                        <div style="color: var(--text-secondary); font-weight: 500;">
                            ນັດໝາຍທີ່ຈະມາເຖິງ
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div style="text-align: center;">
                        <div style="font-size: 3rem; color: var(--primary-color); margin-bottom: 1rem;">
                            <i class="fas fa-chart-line"></i>
                        </div>
                        <div style="font-size: 2rem; font-weight: 700; color: var(--text-primary); margin-bottom: 0.5rem;">
                            ໃຫມ່
                        </div>
                        <div style="color: var(--text-secondary); font-weight: 500;">
                            ສະມາຊິກ
                        </div>
                    </div>
                </div>
            </div>

            <!-- Quick Actions -->
            <div class="card fade-in" style="margin-bottom: 40px;">
                <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 24px; padding-bottom: 16px; border-bottom: 1px solid var(--border-color);">
                    <h2 style="font-size: 1.5rem; font-weight: 600; color: var(--text-primary);">ການດຳເນີນການດ່ວນ</h2>
                </div>
                <div class="grid grid-2" style="gap: 16px;">
                    <a href="../plots.php" class="btn-primary" style="padding: 16px; text-align: center; display: block; text-decoration: none;">
                        <i class="fas fa-search" style="margin-right: 8px;"></i>
                        ຊອກຫາແປງທີ່ດິນ
                    </a>
                    <a href="my_properties.php" class="btn-secondary" style="padding: 16px; text-align: center; display: block; text-decoration: none;">
                        <i class="fas fa-home" style="margin-right: 8px;"></i>
                        ຊັບສິນຂອງຂ້ອຍ
                    </a>
                    <a href="favorites.php" class="btn-secondary" style="padding: 16px; text-align: center; display: block; text-decoration: none;">
                        <i class="fas fa-heart" style="margin-right: 8px;"></i>
                        ລາຍການທີ່ຊື່ນຊອບ
                    </a>
                    <a href="appointments.php" class="btn-secondary" style="padding: 16px; text-align: center; display: block; text-decoration: none;">
                        <i class="fas fa-calendar" style="margin-right: 8px;"></i>
                        ຈັດການນັດໝາຍ
                    </a>
                </div>
            </div>

            <!-- Personal Information -->
            <div class="card slide-up">
                <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 24px; padding-bottom: 16px; border-bottom: 1px solid var(--border-color);">
                    <h2 style="font-size: 1.5rem; font-weight: 600; color: var(--text-primary);">ຂໍ້ມູນສ່ວນຕົວ</h2>
                    <button class="btn-secondary" style="padding: 8px 16px;" onclick="editProfile()">
                        <i class="fas fa-edit" style="margin-right: 8px;"></i>
                        ແກ້ໄຂ
                    </button>
                </div>
                
                <div class="grid grid-2" style="gap: 24px;">
                    <div>
                        <div style="margin-bottom: 20px;">
                            <label style="display: block; margin-bottom: 8px; color: var(--text-secondary); font-weight: 500;">ຊື່ເຕັມ</label>
                            <div style="padding: 12px 16px; background: var(--surface-color); border: 1px solid var(--border-color); border-radius: 8px; color: var(--text-primary);">
                                <?php echo htmlspecialchars($customer_data["first_name"] . ' ' . $customer_data["last_name"]); ?>
                            </div>
                        </div>
                        
                        <div style="margin-bottom: 20px;">
                            <label style="display: block; margin-bottom: 8px; color: var(--text-secondary); font-weight: 500;">ອີເມວ</label>
                            <div style="padding: 12px 16px; background: var(--surface-color); border: 1px solid var(--border-color); border-radius: 8px; color: var(--text-primary);">
                                <?php echo htmlspecialchars($customer_data["email"]); ?>
                            </div>
                        </div>
                    </div>
                    
                    <div>
                        <div style="margin-bottom: 20px;">
                            <label style="display: block; margin-bottom: 8px; color: var(--text-secondary); font-weight: 500;">ເບີໂທ</label>
                            <div style="padding: 12px 16px; background: var(--surface-color); border: 1px solid var(--border-color); border-radius: 8px; color: var(--text-primary);">
                                <?php echo htmlspecialchars($customer_data["phone"]); ?>
                            </div>
                        </div>
                        
                        <div style="margin-bottom: 20px;">
                            <label style="display: block; margin-bottom: 8px; color: var(--text-secondary); font-weight: 500;">ທີ່ຢູ່</label>
                            <div style="padding: 12px 16px; background: var(--surface-color); border: 1px solid var(--border-color); border-radius: 8px; color: var(--text-primary);">
                                <?php echo htmlspecialchars($customer_data["address"] ?? 'ຍັງບໍ່ໄດ້ລະບຸ'); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </main>

    <!-- Footer -->
    <footer style="background: var(--surface-color); padding: 40px 0; border-top: 1px solid var(--border-color); margin-top: 60px;">
        <div class="container">
            <div style="text-align: center; color: var(--text-secondary);">
                <p>&copy; <?php echo date("Y"); ?> PPS Land Management System. ສະຫງວນລິຂະສິດທັງໝົດ.</p>
            </div>
        </div>
    </footer>

    <!-- JavaScript -->
    <script src="../assets/js/theme-switcher.js"></script>
    <script>
        // Customer Dashboard JavaScript
        document.addEventListener('DOMContentLoaded', function() {
            // Add animation on scroll
            const observerOptions = {
                threshold: 0.1,
                rootMargin: '0px 0px -50px 0px'
            };
            
            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.style.opacity = '1';
                        entry.target.style.transform = 'translateY(0)';
                    }
                });
            }, observerOptions);
            
            document.querySelectorAll('.fade-in, .slide-up').forEach(el => {
                el.style.opacity = '0';
                el.style.transform = 'translateY(20px)';
                el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
                observer.observe(el);
            });
        });

        function editProfile() {
            alert('ຟີເຈີ່ແກ້ໄຂຂໍ້ມູນສ່ວນຕົວຈະມາໃນເວີຊັນຕໍ່ໄປ');
        }
    </script>
</body>
</html>

