<?php
// customer/includes/header.php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/customer.php';

requireRole("customer");

$pdo = getDBConnection();
$customer_obj = new Customer($pdo);

$user_id = $_SESSION["user_id"];
$customer_data = $customer_obj->getCustomerByUserId($user_id);

if (!$customer_data) {
    showAlert("error", "Customer data not found.");
    redirect('../login.php');
}
$customer_id = $customer_data["id"];

$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="lo">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Dashboard - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <div class="dashboard-container">
        <aside class="dashboard-sidebar">
            <div class="sidebar-header">
                <h3><a href="../index.php" style="color: inherit; text-decoration: none;"><?php echo SITE_NAME; ?></a></h3>
            </div>
            <nav class="sidebar-nav">
                <ul>
                    <li class="<?php echo ($current_page == 'dashboard.php') ? 'active' : ''; ?>"><a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                    <li class="<?php echo ($current_page == 'my_properties.php') ? 'active' : ''; ?>"><a href="my_properties.php"><i class="fas fa-map-marked-alt"></i> My Properties</a></li>
                    <li class="<?php echo ($current_page == 'favorites.php') ? 'active' : ''; ?>"><a href="favorites.php"><i class="fas fa-heart"></i> Favorites</a></li>
                    <li class="<?php echo ($current_page == 'appointments.php') ? 'active' : ''; ?>"><a href="appointments.php"><i class="fas fa-calendar-check"></i> Appointments</a></li>
                    <li><a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                </ul>
            </nav>
        </aside>
        <main class="dashboard-content">