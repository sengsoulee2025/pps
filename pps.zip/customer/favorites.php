<?php
require_once __DIR__ . '/includes/header.php';
$favorite_plots = $customer_obj->getCustomerFavorites($customer_id);
?>

<header class="dashboard-main-header">
    <h2>Your Favorite Properties</h2>
    <p>Here are the land plots you have saved for consideration.</p>
</header>

<div class="content-card">
    <?php if (!empty($favorite_plots)): ?>
        <div class="properties-grid">
            <?php foreach ($favorite_plots as $plot): ?>
                <div class="plot-card" id="favorite-plot-<?php echo $plot['id']; ?>">
                    <img src="<?php echo htmlspecialchars($plot["image_url"] ?: "../assets/images/default-plot.jpg"); ?>" alt="Plot Image">
                    <div class="plot-info">
                        <h3>Plot #<?php echo htmlspecialchars($plot["plot_number"]); ?></h3>
                        <p><strong>Project:</strong> <?php echo htmlspecialchars($plot["project_name"]); ?></p>
                        <p><strong>Price:</strong> <span class="price"><?php echo formatPrice($plot["price"]); ?></span></p>
                        <p><strong>Status:</strong> <span class="status-<?php echo $plot['status']; ?>"><?php echo ucfirst($plot['status']); ?></span></p>
                        <div class="card-actions">
                            <a href="#" class="btn-sm">View Details</a>
                            <button class="btn-sm-danger" onclick="removeFavorite(this, <?php echo $plot['id']; ?>)">Remove</button>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <p>You have not favorited any properties yet.</p>
    <?php endif; ?>
</div>

<script>
function removeFavorite(button, plotId) {
    if (!confirm('Are you sure you want to remove this from your favorites?')) {
        return;
    }
    
    const formData = new FormData();
    formData.append('plot_id', plotId);
    
    fetch('../api/remove_favorite.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            const card = document.getElementById('favorite-plot-' + plotId);
            if (card) {
                card.style.display = 'none';
            }
        } else {
            alert(data.message || 'Failed to remove favorite.');
        }
    })
    .catch(error => alert('An error occurred.'));
}
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>