<?php
require_once __DIR__ . '/includes/header.php';
$owned_properties = $customer_obj->getCustomerProperties($customer_id);
?>

<header class="dashboard-main-header">
    <h2>My Properties</h2>
    <p>Here are the properties you have purchased.</p>
</header>

<div class="content-card">
    <?php if (!empty($owned_properties)): ?>
        <div class="properties-grid">
            <?php foreach ($owned_properties as $plot): ?>
                 <div class="plot-card">
                    <img src="<?php echo htmlspecialchars($plot["image_url"] ?: "../assets/images/default-plot.jpg"); ?>" alt="Plot Image">
                    <div class="plot-info">
                        <h3>Plot #<?php echo htmlspecialchars($plot["plot_number"]); ?></h3>
                        <p><strong>Project:</strong> <?php echo htmlspecialchars($plot["project_name"]); ?></p>
                        <p><strong>Area:</strong> <?php echo htmlspecialchars($plot["area"]); ?> sqm</p>
                        <p><strong>Purchased on:</strong> <?php echo formatDate($plot["sale_date"]); ?></p>
                        <a href="#" class="btn-sm">Download Documents</a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <p>You do not own any properties yet.</p>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>