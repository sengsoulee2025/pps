<?php
require_once __DIR__ . '/includes/header.php';
$appointments = $customer_obj->getCustomerAppointments($customer_id);
?>

<header class="dashboard-main-header">
    <h2>Your Appointments</h2>
    <p>View your appointment history and schedule new ones.</p>
    <button class="btn-primary" style="margin-top: 1rem;" onclick="openAppointmentModal()">+ Request New Appointment</button>
</header>

<div class="content-card">
    <h3>Appointment History</h3>
    <?php if (!empty($appointments)): ?>
        <table class="table">
            <thead>
                <tr><th>Date & Time</th><th>Employee</th><th>Purpose</th><th>Status</th></tr>
            </thead>
            <tbody>
                <?php foreach ($appointments as $appt): ?>
                    <tr>
                        <td><?php echo formatDateTime($appt['appointment_date']); ?></td>
                        <td><?php echo htmlspecialchars($appt['employee_first_name']); ?></td>
                        <td><?php echo htmlspecialchars($appt['purpose']); ?></td>
                        <td><span class="status-<?php echo $appt['status']; ?>"><?php echo ucfirst($appt['status']); ?></span></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>You have no appointments scheduled.</p>
    <?php endif; ?>
</div>

<div id="appointmentModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3>Request an Appointment</h3>
            <span class="close" onclick="closeModal('appointmentModal')">&times;</span>
        </div>
        <div class="modal-body">
            <form id="appointmentForm">
                <div id="appt-error" class="error-message" style="display: none;"></div>
                <div class="form-group">
                    <label for="appointment_date">Preferred Date & Time</label>
                    <input type="datetime-local" id="appointment_date" name="appointment_date" required>
                </div>
                <div class="form-group">
                    <label for="purpose">Purpose / Details</label>
                    <textarea id="purpose" name="purpose" rows="4" placeholder="E.g., Site visit for Green Valley Project, Plot A15" required></textarea>
                </div>
                <button type="submit" class="btn-primary">Submit Request</button>
            </form>
        </div>
    </div>
</div>

<script>
function openAppointmentModal() { document.getElementById('appointmentModal').style.display = 'flex'; }
function closeModal(modalId) { document.getElementById(modalId).style.display = 'none'; }

document.getElementById('appointmentForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const form = e.target;
    const formData = new FormData(form);
    const errorDiv = document.getElementById('appt-error');

    fetch('../api/create_appointment.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            closeModal('appointmentModal');
            alert(data.message);
            window.location.reload(); // Reload to see the new appointment
        } else {
            errorDiv.textContent = data.message || 'An error occurred.';
            errorDiv.style.display = 'block';
        }
    })
    .catch(error => {
        errorDiv.textContent = 'A network error occurred. Please try again.';
        errorDiv.style.display = 'block';
    });
});
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>