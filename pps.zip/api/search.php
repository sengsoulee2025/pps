<?php
require_once '../config/config.php';
require_once '../includes/plot.php';
require_once '../includes/project.php';

// Set JSON response header
header('Content-Type: application/json');

try {
    $plotManager = new Plot();
    $projectManager = new Project();
    
    // Get search parameters
    $search = isset($_GET['search']) ? sanitizeInput($_GET['search']) : '';
    $project_id = isset($_GET['project_id']) ? intval($_GET['project_id']) : null;
    $status = isset($_GET['status']) ? sanitizeInput($_GET['status']) : '';
    $min_price = isset($_GET['min_price']) ? floatval($_GET['min_price']) : null;
    $max_price = isset($_GET['max_price']) ? floatval($_GET['max_price']) : null;
    $min_area = isset($_GET['min_area']) ? floatval($_GET['min_area']) : null;
    $max_area = isset($_GET['max_area']) ? floatval($_GET['max_area']) : null;
    $limit = isset($_GET['limit']) ? intval($_GET['limit']) : 20;
    $offset = isset($_GET['offset']) ? intval($_GET['offset']) : 0;
    
    // Search plots
    $plots = $plotManager->searchPlots($search, $min_price, $max_price, $min_area, $max_area, $project_id);
    
    // Add favorite status if user is logged in
    if (isLoggedIn() && isset($_SESSION['customer_id'])) {
        require_once '../includes/customer.php';
        $customerManager = new Customer();
        
        foreach ($plots as &$plot) {
            $plot['is_favorite'] = $customerManager->isInFavorites($_SESSION['customer_id'], $plot['id']);
        }
    }
    
    // Apply pagination
    $total = count($plots);
    $plots = array_slice($plots, $offset, $limit);
    
    echo json_encode([
        'success' => true,
        'results' => $plots,
        'total' => $total,
        'limit' => $limit,
        'offset' => $offset
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Search failed: ' . $e->getMessage()
    ]);
}
?>

