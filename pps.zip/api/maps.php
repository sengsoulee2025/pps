<?php
require_once '../config/config.php';
require_once '../includes/project.php';

// Set JSON response header
header('Content-Type: application/json');

try {
    $projectManager = new Project();
    
    $action = $_GET['action'] ?? 'projects';
    
    switch ($action) {
        case 'projects':
            // Get all active projects with location data
            $projects = $projectManager->getAllProjects(null, 0, '', 'active');
            
            $mapData = [];
            foreach ($projects as $project) {
                // For demo purposes, we'll generate some sample coordinates
                // In a real application, you would store actual coordinates in the database
                $coordinates = $this->generateSampleCoordinates($project['id']);
                
                $mapData[] = [
                    'id' => $project['id'],
                    'name' => $project['name'],
                    'location' => $project['location'],
                    'description' => $project['description'],
                    'total_plots' => $project['total_plots'],
                    'available_plots' => $project['available_plots'],
                    'status' => $project['status'],
                    'coordinates' => $coordinates,
                    'url' => 'project-details.php?id=' . $project['id']
                ];
            }
            
            echo json_encode([
                'success' => true,
                'projects' => $mapData
            ]);
            break;
            
        case 'project_details':
            $project_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
            
            if ($project_id <= 0) {
                throw new Exception('Invalid project ID');
            }
            
            $project = $projectManager->getProjectById($project_id);
            if (!$project) {
                throw new Exception('Project not found');
            }
            
            // Get project plots
            $plots = $projectManager->getProjectPlots($project_id);
            
            // Generate sample coordinates for the project area
            $baseCoordinates = $this->generateSampleCoordinates($project_id);
            
            $plotData = [];
            foreach ($plots as $index => $plot) {
                // Generate coordinates for each plot within the project area
                $plotCoordinates = [
                    'lat' => $baseCoordinates['lat'] + (($index % 10) * 0.001) - 0.005,
                    'lng' => $baseCoordinates['lng'] + (floor($index / 10) * 0.001) - 0.005
                ];
                
                $plotData[] = [
                    'id' => $plot['id'],
                    'plot_number' => $plot['plot_number'],
                    'area' => $plot['area'],
                    'price' => $plot['price'],
                    'status' => $plot['status'],
                    'coordinates' => $plotCoordinates,
                    'url' => 'plot-details.php?id=' . $plot['id']
                ];
            }
            
            echo json_encode([
                'success' => true,
                'project' => [
                    'id' => $project['id'],
                    'name' => $project['name'],
                    'location' => $project['location'],
                    'coordinates' => $baseCoordinates
                ],
                'plots' => $plotData
            ]);
            break;
            
        default:
            throw new Exception('Invalid action');
    }
    
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}

// Helper function to generate sample coordinates for demo
function generateSampleCoordinates($project_id) {
    // Sample coordinates around Vientiane, Laos
    $base_lat = 17.9757;
    $base_lng = 102.6331;
    
    // Generate different coordinates for each project
    $offset_lat = (($project_id * 7) % 100) * 0.01 - 0.5;
    $offset_lng = (($project_id * 11) % 100) * 0.01 - 0.5;
    
    return [
        'lat' => $base_lat + $offset_lat,
        'lng' => $base_lng + $offset_lng
    ];
}
?>

