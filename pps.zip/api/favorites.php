<?php
require_once '../config/config.php';
require_once '../includes/customer.php';

// Set JSON response header
header('Content-Type: application/json');

// Check if user is logged in
if (!isLoggedIn() || !isset($_SESSION['customer_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Please log in to manage favorites']);
    exit;
}

try {
    $customerManager = new Customer();
    $customer_id = $_SESSION['customer_id'];
    
    $method = $_SERVER['REQUEST_METHOD'];
    
    if ($method === 'POST') {
        $input = json_decode(file_get_contents('php://input'), true);
        $action = $input['action'] ?? '';
        $plot_id = isset($input['plot_id']) ? intval($input['plot_id']) : 0;
        
        if ($plot_id <= 0) {
            throw new Exception('Invalid plot ID');
        }
        
        switch ($action) {
            case 'add':
                $result = $customerManager->addToFavorites($customer_id, $plot_id);
                if ($result) {
                    echo json_encode([
                        'success' => true,
                        'message' => 'Added to favorites',
                        'is_favorite' => true
                    ]);
                } else {
                    echo json_encode([
                        'success' => false,
                        'message' => 'Failed to add to favorites'
                    ]);
                }
                break;
                
            case 'remove':
                $result = $customerManager->removeFromFavorites($customer_id, $plot_id);
                if ($result) {
                    echo json_encode([
                        'success' => true,
                        'message' => 'Removed from favorites',
                        'is_favorite' => false
                    ]);
                } else {
                    echo json_encode([
                        'success' => false,
                        'message' => 'Failed to remove from favorites'
                    ]);
                }
                break;
                
            case 'toggle':
                $is_favorite = $customerManager->isInFavorites($customer_id, $plot_id);
                
                if ($is_favorite) {
                    $result = $customerManager->removeFromFavorites($customer_id, $plot_id);
                    $message = 'Removed from favorites';
                    $new_status = false;
                } else {
                    $result = $customerManager->addToFavorites($customer_id, $plot_id);
                    $message = 'Added to favorites';
                    $new_status = true;
                }
                
                if ($result) {
                    echo json_encode([
                        'success' => true,
                        'message' => $message,
                        'is_favorite' => $new_status
                    ]);
                } else {
                    echo json_encode([
                        'success' => false,
                        'message' => 'Failed to update favorites'
                    ]);
                }
                break;
                
            default:
                throw new Exception('Invalid action');
        }
        
    } elseif ($method === 'GET') {
        // Get user's favorites
        $favorites = $customerManager->getCustomerFavorites($customer_id);
        
        echo json_encode([
            'success' => true,
            'favorites' => $favorites
        ]);
        
    } else {
        throw new Exception('Method not allowed');
    }
    
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?>

