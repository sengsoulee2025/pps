<?php
// api/create_appointment.php
header('Content-Type: application/json');

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/customer.php';
require_once __DIR__ . '/../includes/employee.php'; // ເອີ້ນໃຊ້ Employee class

if (!isLoggedIn() || !hasRole('customer')) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

$purpose = trim($_POST['purpose'] ?? '');
$datetime = trim($_POST['appointment_date'] ?? '');

if (empty($purpose) || empty($datetime)) {
    echo json_encode(['success' => false, 'message' => 'Please provide all details.']);
    exit();
}

try {
    $pdo = getDBConnection();
    $customer_obj = new Customer($pdo);
    $employee_obj = new Employee($pdo);

    $customer_info = $customer_obj->getCustomerByUserId($_SESSION['user_id']);
    $customer_id = $customer_info['id'];
    
    // Assign to a random sales employee
    $employee_id = $employee_obj->getRandomSalesEmployeeId();
    if (!$employee_id) {
        echo json_encode(['success' => false, 'message' => 'No available sales staff at the moment. Please contact us directly.']);
        exit();
    }

    $data = [
        'customer_id' => $customer_id,
        'employee_id' => $employee_id,
        'appointment_date' => $datetime,
        'purpose' => $purpose
    ];

    if ($customer_obj->createAppointment($data)) {
        echo json_encode(['success' => true, 'message' => 'Appointment requested successfully! We will contact you to confirm.']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to request appointment.']);
    }
} catch (Exception $e) {
    error_log($e->getMessage());
    echo json_encode(['success' => false, 'message' => 'An error occurred.']);
}
?>