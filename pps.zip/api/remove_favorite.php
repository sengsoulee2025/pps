<?php
// api/remove_favorite.php
header('Content-Type: application/json');

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/customer.php';

if (!isLoggedIn() || !hasRole('customer')) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit();
}

$plot_id = $_POST['plot_id'] ?? null;
if (empty($plot_id)) {
    echo json_encode(['success' => false, 'message' => 'Plot ID is required.']);
    exit();
}

try {
    $pdo = getDBConnection();
    $customer_obj = new Customer($pdo);
    $customer_info = $customer_obj->getCustomerByUserId($_SESSION['user_id']);
    $customer_id = $customer_info['id'];

    if ($customer_obj->removeFromFavorites($customer_id, $plot_id)) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to remove favorite.']);
    }
} catch (Exception $e) {
    error_log($e->getMessage());
    echo json_encode(['success' => false, 'message' => 'An error occurred.']);
}
?>