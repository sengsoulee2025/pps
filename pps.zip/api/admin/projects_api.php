<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/project.php';
require_once __DIR__ . '/../../includes/upload.php';

function json_response($success, $message = '', $data = []) {
    echo json_encode(['success' => $success, 'message' => $message, 'data' => $data]);
    exit;
}

if (!isLoggedIn() || !hasRole('admin')) {
    json_response(false, 'Unauthorized access.');
}

$action = $_GET['action'] ?? '';

try {
    $pdo = getDBConnection();
    $projectManager = new Project($pdo);
    $fileUpload = new FileUpload();
} catch (Exception $e) {
    json_response(false, 'Database connection error: ' . $e->getMessage());
}

switch ($action) {
    case 'get':
        $id = $_GET['id'] ?? 0;
        $project = $projectManager->getProjectById((int)$id);
        if ($project) {
            json_response(true, 'Project fetched successfully.', $project);
        } else {
            json_response(false, 'Project not found.');
        }
        break;

    case 'create':
        $name = trim($_POST['name'] ?? '');
        if (empty($name)) {
            json_response(false, 'ກະລຸນາປ້ອນຊື່ໂຄງການ.');
        }

        if ($projectManager->isNameTaken($name)) {
            json_response(false, 'ຊື່ໂຄງການ "' . htmlspecialchars($name) . '" ນີ້ມີຢູ່ໃນລະບົບແລ້ວ. ກະລຸນາໃຊ້ຊື່ອື່ນ.');
        }
        
        $newImagePath = null;
        if (isset($_FILES['master_plan_image']) && $_FILES['master_plan_image']['error'] === UPLOAD_ERR_OK) {
            $uploadResult = $fileUpload->uploadFile($_FILES['master_plan_image'], 'image');
            if ($uploadResult['success']) {
                $newImagePath = $uploadResult['url'];
            } else {
                json_response(false, $uploadResult['message']);
            }
        }

        $data = [
            'name' => $name,
            'location' => $_POST['location'] ?? '',
            'description' => $_POST['description'] ?? '',
            'master_plan_url' => $newImagePath,
            'video_url' => null,
            'status' => 'active'
        ];
        
        if ($projectManager->createProject($data)) {
            json_response(true, 'ເພີ່ມໂຄງການໃໝ່ສຳເລັດ!');
        } else {
            json_response(false, 'Failed to create project.');
        }
        break;

    case 'update':
        $id = $_POST['project_id'] ?? 0;
        $name = trim($_POST['name'] ?? '');

        if (!$id || empty($name)) {
            json_response(false, 'ກະລຸນາປ້ອນຂໍ້ມູນໃຫ້ຄົບຖ້ວນ.');
        }

        if ($projectManager->isNameTaken($name, $id)) {
            json_response(false, 'ຊື່ໂຄງການ "' . htmlspecialchars($name) . '" ນີ້ມີໂຄງການອື່ນໃຊ້ແລ້ວ.');
        }
        
        $data = [
            'name' => $name,
            'location' => $_POST['location'] ?? '',
            'description' => $_POST['description'] ?? '',
        ];
        
        $oldProject = $projectManager->getProjectById($id);
        $oldImageUrl = $oldProject['master_plan_url'] ?? null;
        
        if (isset($_FILES['master_plan_image']) && $_FILES['master_plan_image']['error'] === UPLOAD_ERR_OK) {
            $uploadResult = $fileUpload->uploadFile($_FILES['master_plan_image'], 'image');
            if ($uploadResult['success']) {
                $data['master_plan_url'] = $uploadResult['url'];
                if ($oldImageUrl && strpos($oldImageUrl, 'default-project.jpg') === false) {
                    $oldServerPath = str_replace('uploads/', '', $oldImageUrl);
                    $fileUpload->deleteFile($oldServerPath);
                }
            } else {
                json_response(false, $uploadResult['message']);
            }
        }

        if ($projectManager->updateProject($id, $data)) {
            $updatedProject = $projectManager->getProjectById($id);
            json_response(true, 'ອັບເດດຂໍ້ມູນໂຄງການສຳເລັດແລ້ວ.', $updatedProject);
        } else {
            json_response(false, 'Failed to update project.');
        }
        break;

    case 'delete':
        $id = $_POST['project_id'] ?? 0;
        if (!$id) {
            json_response(false, 'Invalid Project ID.');
        }

        $projectToDelete = $projectManager->getProjectById($id);
        if (!$projectToDelete) {
            json_response(false, 'ບໍ່ພົບໂຄງການນີ້.');
        }
        $imageUrlToDelete = $projectToDelete['master_plan_url'] ?? null;

        if ($projectManager->deleteProject($id)) {
            if ($imageUrlToDelete && file_exists(__DIR__ . '/../../' . $imageUrlToDelete)) {
                if (strpos($imageUrlToDelete, 'default-project.jpg') === false) {
                    unlink(__DIR__ . '/../../' . $imageUrlToDelete);
                }
            }
            json_response(true, 'ໂຄງການໄດ້ຖືກລົບສຳເລັດ!');
        } else {
            json_response(false, 'ບໍ່ສາມາດລົບໂຄງການນີ້ໄດ້ ເພາະຍັງມີຕອນດິນຜູກຕິດຢູ່.');
        }
        break;

    default:
        json_response(false, 'Invalid action');
        break;
}
?>