
<?php
// ໄຟລ໌: admin/api/zones_api.php (ສະບັບແກ້ໄຂສົມບູນ)
header('Content-Type: application/json');
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/zone.php';

function json_response($success, $message = '', $data = []) {
    echo json_encode(['success' => $success, 'message' => $message, 'data' => $data]);
    exit;
}

if (!isLoggedIn() || !hasRole('admin')) {
    json_response(false, 'Unauthorized access.');
}

$action = $_GET['action'] ?? '';
$pdo = getDBConnection();
$zoneManager = new ProjectZone($pdo);

switch ($action) {
    case 'get_by_project':
        $projectId = $_GET['project_id'] ?? 0;
        $zones = $zoneManager->getZonesByProjectId($projectId);
        json_response(true, 'Zones fetched.', $zones);
        break;

    case 'get_one':
        $id = $_GET['id'] ?? 0;
        $zone = $zoneManager->getZoneById((int)$id);
        if ($zone) {
            json_response(true, 'Zone fetched.', $zone);
        } else {
            json_response(false, 'Zone not found.');
        }
        break;


    case 'create':
        try {
            $data = [
                'project_id' => $_POST['project_id'] ?? 0,
                'zone_name' => trim($_POST['zone_name'] ?? ''),
                'price_per_sqm' => $_POST['price_per_sqm'] ?? 0,
                'currency' => $_POST['currency'] ?? 'LAK',
            ];

            if (empty($data['project_id']) || empty($data['zone_name'])) {
                json_response(false, 'ກະລຸນາປ້ອນຂໍ້ມູນໃຫ້ຄົບ.');
            }

            if ($zoneManager->isZoneNameTaken($data['project_id'], $data['zone_name'])) {
                json_response(false, 'ຊື່ໂຊນນີ້ ມີຢູ່ໃນໂຄງການນີ້ແລ້ວ.');
            }

            if ($zoneManager->createZone($data)) {
                json_response(true, 'ເພີ່ມໂຊນໃໝ່ສຳເລັດ!');
            } else {
                json_response(false, 'ການສ້າງໂຊນລົ້ມເຫຼວໂດຍບໍ່ทราบสาเหตุ.');
            }
        } catch (Exception $e) {
            json_response(false, $e->getMessage());
        }
        break;
    
    case 'update':
        try {
            $id = $_POST['zone_id'] ?? 0;
            $data = [
                'project_id' => $_POST['project_id'] ?? 0,
                'zone_name' => trim($_POST['zone_name'] ?? ''),
                'price_per_sqm' => $_POST['price_per_sqm'] ?? 0,
                'currency' => $_POST['currency'] ?? 'LAK',
            ];

            if (empty($id) || empty($data['project_id']) || empty($data['zone_name'])) {
                json_response(false, 'ກະລຸນາປ້ອນຂໍ້ມູນໃຫ້ຄົບ.');
            }

            if ($zoneManager->isZoneNameTaken($data['project_id'], $data['zone_name'], $id)) {
                json_response(false, 'ຊື່ໂຊນນີ້ ມີຢູ່ໃນໂຄງການນີ້ແລ້ວ.');
            }

            if ($zoneManager->updateZone($id, $data)) {
                json_response(true, 'ອັບເດດໂຊນສຳເລັດ!');
            } else {
                json_response(false, 'Error updating zone.');
            }
        } catch (Exception $e) {
            json_response(false, $e->getMessage());
        }
        break;

    case 'delete':
        try {
            $id = $_POST['zone_id'] ?? 0;
            if (!$id) {
                json_response(false, 'Invalid Zone ID.');
            }
            if ($zoneManager->deleteZone($id)) {
                json_response(true, 'ລົບໂຊນສຳເລັດ!');
            } else {
                json_response(false, 'ບໍ່ສາມາດລົບໂຊນນີ້ໄດ້ ເພາະຍັງມີຕອນດິນນຳໃຊ້ຢູ່.');
            }
        } catch (Exception $e) {
            json_response(false, $e->getMessage());
        }
        break;
    
    default:
        json_response(false, 'Invalid action specified for zones API.');
}
?>