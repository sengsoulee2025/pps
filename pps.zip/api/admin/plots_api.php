<?php
// ໄຟລ໌: admin/api/plots_api.php
header('Content-Type: application/json');
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/plot.php';

function json_response($success, $message = '', $data = []) {
    echo json_encode(['success' => $success, 'message' => $message, 'data' => $data]);
    exit;
}

if (!isLoggedIn() || !hasRole('admin')) {
    json_response(false, 'Unauthorized access.');
}

$action = $_GET['action'] ?? '';
$pdo = getDBConnection();
$plotManager = new Plot($pdo);

switch ($action) {
    case 'get':
        $plot = $plotManager->getPlotById($_GET['id'] ?? 0);
        json_response($plot ? true : false, $plot ? 'Plot fetched.' : 'Plot not found.', $plot);
        break;
    case 'create':
        try {
            $data = ['project_id' => $_POST['project_id'] ?? 0, 'plot_number' => trim($_POST['plot_number'] ?? ''), 'area' => $_POST['area'] ?? 0, 'zone_id' => $_POST['zone_id'] ?? 0];
            if (empty($data['project_id'])||empty($data['plot_number'])||empty($data['area'])||empty($data['zone_id'])) { json_response(false, 'ກະລຸນາປ້ອນຂໍ້ມູນໃຫ້ຄົບຖ້ວນ.'); }
            if ($plotManager->isPlotNumberTaken($data['plot_number'], $data['project_id'])) { json_response(false, 'ເລກຕອນດິນ "' . htmlspecialchars($data['plot_number']) . '" ມີຢູ່ໃນໂຄງການນີ້ແລ້ວ.'); }
            if ($plotManager->createPlot($data)) { json_response(true, 'ເພີ່ມຕອນດິນສຳເລັດ!'); } else { json_response(false, 'ບໍ່ສາມາດສ້າງຕອນດິນໄດ້.'); }
        } catch (Exception $e) { json_response(false, $e->getMessage()); }
        break;
    case 'update':
        try {
            $id = $_POST['plot_id'] ?? 0;
            $data = ['project_id' => $_POST['project_id'] ?? 0, 'plot_number' => trim($_POST['plot_number'] ?? ''), 'area' => $_POST['area'] ?? 0, 'zone_id' => $_POST['zone_id'] ?? 0, 'status' => $_POST['status'] ?? 'available'];
            if (empty($id)||empty($data['project_id'])||empty($data['plot_number'])||empty($data['area'])||empty($data['zone_id'])) { json_response(false, 'ກະລຸນາປ້ອນຂໍ້ມູນໃຫ້ຄົບຖ້ວນ.'); }
            if ($plotManager->isPlotNumberTaken($data['plot_number'], $data['project_id'], $id)) { json_response(false, 'ເລກຕອນດິນ "' . htmlspecialchars($data['plot_number']) . '" ມີຢູ່ໃນໂຄງການນີ້ແລ້ວ.'); }
            if ($plotManager->updatePlot($id, $data)) { json_response(true, 'ອັບເດດຕອນດິນສຳເລັດ!'); } else { json_response(false, 'ບໍ່ສາມາດອັບເດດຕອນດິນໄດ້.'); }
        } catch (Exception $e) { json_response(false, $e->getMessage()); }
        break;
    case 'delete':
        try {
            if ($plotManager->deletePlot($_POST['plot_id'] ?? 0)) { json_response(true, 'ລົບຕອນດິນສຳເລັດ!'); } else { json_response(false, 'ບໍ່ສາມາດລົບຕອນດິນໄດ້.'); }
        } catch (Exception $e) { json_response(false, $e->getMessage()); }
        break;
    default:
        json_response(false, 'Invalid action.');
}
?>