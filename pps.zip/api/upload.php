<?php
require_once '../config/config.php';
require_once '../includes/upload.php';

// Set JSON response header
header('Content-Type: application/json');

// Check if user is logged in and has appropriate permissions
if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Authentication required']);
    exit;
}

// Only allow admin, manager, or sales roles to upload
if (!hasRole('admin') && !hasRole('manager') && !hasRole('sales')) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit;
}

try {
    $fileUpload = new FileUpload();
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Handle file upload
        if (isset($_FILES['files'])) {
            $type = isset($_POST['type']) ? $_POST['type'] : 'image';
            $validTypes = ['image', 'video', 'document'];
            
            if (!in_array($type, $validTypes)) {
                $type = 'image';
            }
            
            $results = $fileUpload->uploadMultipleFiles($_FILES['files'], $type);
            
            // Process image options if it's an image upload
            if ($type === 'image') {
                foreach ($results as &$result) {
                    if ($result['success']) {
                        // Resize image if requested
                        if (isset($_POST['resize']) && $_POST['resize'] === 'true') {
                            $maxWidth = isset($_POST['maxWidth']) ? (int)$_POST['maxWidth'] : 1200;
                            $maxHeight = isset($_POST['maxHeight']) ? (int)$_POST['maxHeight'] : 800;
                            $quality = isset($_POST['quality']) ? (int)$_POST['quality'] : 85;
                            
                            $fileUpload->resizeImage('images/' . $result['filename'], $maxWidth, $maxHeight, $quality);
                        }
                        
                        // Create thumbnail if requested
                        if (isset($_POST['thumbnail']) && $_POST['thumbnail'] === 'true') {
                            $thumbWidth = isset($_POST['thumbWidth']) ? (int)$_POST['thumbWidth'] : 200;
                            $thumbHeight = isset($_POST['thumbHeight']) ? (int)$_POST['thumbHeight'] : 200;
                            
                            $thumbUrl = $fileUpload->createThumbnail('images/' . $result['filename'], $thumbWidth, $thumbHeight);
                            if ($thumbUrl) {
                                $result['thumbnail'] = $thumbUrl;
                            }
                        }
                    }
                }
            }
            
            echo json_encode(['success' => true, 'results' => $results]);
        } else {
            echo json_encode(['success' => false, 'message' => 'No files uploaded']);
        }
    } elseif ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
        // Handle file deletion
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (isset($input['file'])) {
            $success = $fileUpload->deleteFile($input['file']);
            echo json_encode(['success' => $success]);
        } else {
            echo json_encode(['success' => false, 'message' => 'File path required']);
        }
    } elseif ($_SERVER['REQUEST_METHOD'] === 'GET') {
        // Handle file listing
        $type = isset($_GET['type']) ? $_GET['type'] : 'image';
        $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : null;
        
        $files = $fileUpload->listFiles($type, $limit);
        echo json_encode(['success' => true, 'files' => $files]);
    } else {
        http_response_code(405);
        echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Server error: ' . $e->getMessage()]);
}
?>
