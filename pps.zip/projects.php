<?php
// projects.php - ໜ້າໂຄງການ
// ໄຟລ໌ນີ້ສະແດງລາຍຊື່ໂຄງການພັດທະນາທັງໝົດ, ພ້ອມດ້ວຍຟັງຊັນຄົ້ນຫາ ແລະ ກັ່ນຕອງ.

// ລວມເອົາໄຟລ໌ການຕັ້ງຄ່າ ແລະ ຄລາສທີ່ຈຳເປັນ
require_once 'config/config.php'; // ໄຟລ໌ການຕັ້ງຄ່າລະບົບ (ເຊັ່ນ: ຂໍ້ມູນຖານຂໍ້ມູນ)
require_once 'includes/project.php'; // ຄລາສສຳລັບຈັດການໂຄງການ

// ເຊື່ອມຕໍ່ຖານຂໍ້ມູນ
// ຕົວແປ $pdo ຖືກສ້າງຂຶ້ນຈາກຟັງຊັນ getDBConnection() ທີ່ຢູ່ໃນ config/config.php
$pdo = getDBConnection();

// ສົ່ງ $pdo ເຂົ້າໄປຕອນສ້າງ Object
// ຕົວແປ $projectManager ຖືກໃຊ້ເພື່ອເຂົ້າເຖິງຟັງຊັນຕ່າງໆຂອງຄລາສ Project
$projectManager = new Project($pdo);

// ຕົວຢ່າງການດຶງຂໍ້ມູນໂຄງການທັງໝົດ (ອາດຈະບໍ່ໄດ້ໃຊ້ໂດຍກົງຖ້າມີການກັ່ນຕອງ)
$allProjects = $projectManager->getAllProjects();

// ດຶງພາລາມິເຕີການຄົ້ນຫາຈາກ URL
// $search: ຕົວແປນີ້ເກັບຄ່າຄົ້ນຫາທີ່ຜູ້ໃຊ້ປ້ອນເຂົ້າມາ (ຈາກ $_GET['search'])
$search = isset($_GET['search']) ? sanitizeInput($_GET['search']) : '';
// $status: ຕົວແປນີ້ເກັບຄ່າສະຖານະທີ່ຜູ້ໃຊ້ເລືອກ (ຈາກ $_GET['status'])
$status = isset($_GET['status']) ? sanitizeInput($_GET['status']) : '';
// $page: ຕົວແປນີ້ເກັບເລກໜ້າປັດຈຸບັນສຳລັບການແບ່ງໜ້າ (ຈາກ $_GET['page'])
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;

// ການຕັ້ງຄ່າການແບ່ງໜ້າ (Pagination)
// $limit: ຈຳນວນລາຍການຕໍ່ໜ້າ (ITEMS_PER_PAGE ຖືກກຳນົດໃນ config/config.php)
$limit = ITEMS_PER_PAGE;
// $offset: ຈຸດເລີ່ມຕົ້ນຂອງຂໍ້ມູນສຳລັບໜ້າປັດຈຸບັນ
$offset = ($page - 1) * $limit;

// ດຶງຂໍ້ມູນໂຄງການ ແລະ ຈຳນວນໂຄງການທັງໝົດຕາມເງື່ອນໄຂການຄົ້ນຫາ ແລະ ກັ່ນຕອງ
// $projects: ຕົວແປນີ້ເກັບລາຍຊື່ໂຄງການສຳລັບໜ້າປັດຈຸບັນ
$projects = $projectManager->getAllProjects($limit, $offset, $search, $status);
// $totalProjects: ຕົວແປນີ້ເກັບຈຳນວນໂຄງການທັງໝົດທີ່ກົງກັບເງື່ອນໄຂ
$totalProjects = $projectManager->getProjectCount($search, $status);
// $totalPages: ຕົວແປນີ້ເກັບຈຳນວນໜ້າທັງໝົດ
$totalPages = ceil($totalProjects / $limit);

// ດຶງຂໍ້ຄວາມແຈ້ງເຕືອນ (ຖ້າມີ)
// $alert: ຕົວແປນີ້ເກັບຂໍ້ຄວາມແຈ້ງເຕືອນທີ່ອາດຈະຖືກຕັ້ງໄວ້ໃນ session
$alert = getAlert();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ໂຄງການ - <?php echo SITE_NAME; ?></title>
    <meta name="description" content="ຊອກຫາໂຄງການພັດທະນາທັງໝົດໂດຍລະບົບການຄຸ້ມຄອງທີ່ດິນ PPS. ຊອກຫາໂອກາດການພັດທະນາທີ່ດິນລະດັບພຣີມຽມ.">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <!-- Header Section - ສ່ວນຫົວຂອງເວັບໄຊທ໌ -->
    <!-- ປະກອບມີໂລໂກ້ ແລະ ເມນູການນຳທາງ -->
    <header class="header">
        <nav class="nav container">
            <a href="index.php" class="logo">PPS Land</a>
            <ul class="nav-menu">
                <li><a href="index.php">ໜ້າຫຼັກ</a></li>
                <li><a href="projects.php" class="active">ໂຄງການ</a></li>
                <li><a href="plots.php">ແປງທີ່ດິນ</a></li>
                <li><a href="about.php">ກ່ຽວກັບ</a></li>
                <li><a href="contact.php">ຕິດຕໍ່</a></li>
                <?php 
                // ກວດສອບວ່າຜູ້ໃຊ້ໄດ້ເຂົ້າສູ່ລະບົບແລ້ວບໍ
                // isLoggedIn() ແມ່ນຟັງຊັນທີ່ຢູ່ໃນ includes/auth.php
                if (isLoggedIn()): 
                ?>
                    <li><a href="customer/dashboard.php">ແຜງຄວບຄຸມ</a></li>
                    <li><a href="logout.php">ອອກຈາກລະບົບ</a></li>
                <?php else: ?>
                    <li><a href="login.php">ເຂົ້າສູ່ລະບົບ</a></li>
                    <li><a href="register.php">ລົງທະບຽນ</a></li>
                <?php endif; ?>
            </ul>
            <button class="nav-toggle">☰</button>
        </nav>
    </header>

    <!-- Page Header - ສ່ວນຫົວຂໍ້ຂອງໜ້າ -->
    <section class="hero" style="height: 60vh; margin-top: 80px;">
        <div class="hero-content">
            <h1>ໂຄງການພັດທະນາຂອງພວກເຮົາ</h1>
            <p>ຄົ້ນພົບໂຄງການພັດທະນາທີ່ດິນລະດັບພຣີມຽມໃນສະຖານທີ່ສຳຄັນ</p>
        </div>
    </section>

    <!-- Alert Messages Section - ສ່ວນສະແດງຂໍ້ຄວາມແຈ້ງເຕືອນ -->
    <?php if ($alert): ?>
    <div class="container mt-4">
        <div class="alert alert-<?php echo $alert['type']; ?>">
            <?php echo htmlspecialchars($alert['message']); ?>
        </div>
    </div>
    <?php endif; ?>

    <!-- Search and Filter Section - ສ່ວນຄົ້ນຫາ ແລະ ກັ່ນຕອງ -->
    <!-- ໃຫ້ຜູ້ໃຊ້ສາມາດຄົ້ນຫາໂຄງການຕາມເງື່ອນໄຂຕ່າງໆ -->
    <section class="section">
        <div class="container">
            <div class="search-filter">
                <h2>ຊອກຫາໂຄງການ</h2>
                <form method="GET" action="projects.php">
                    <div class="filter-row">
                        <div class="form-group">
                            <label for="search" class="form-label">ຄົ້ນຫາ</label>
                            <!-- input search: ຕົວແປ $search ຖືກໃຊ້ເພື່ອເກັບຄ່າການຄົ້ນຫາ -->
                            <input type="text" id="search" name="search" class="form-control" 
                                   placeholder="ຄົ້ນຫາຕາມຊື່ ຫຼື ສະຖານທີ່..." 
                                   value="<?php echo htmlspecialchars($search); ?>">
                        </div>
                        <div class="form-group">
                            <label for="status" class="form-label">ສະຖານະ</label>
                            <!-- select status: ຕົວແປ $status ຖືກໃຊ້ເພື່ອເກັບຄ່າສະຖານະທີ່ເລືອກ -->
                            <select id="status" name="status" class="form-control">
                                <option value="">ທຸກສະຖານະ</option>
                                <option value="active" <?php echo $status === 'active' ? 'selected' : ''; ?>>ກຳລັງດຳເນີນ</option>
                                <option value="planning" <?php echo $status === 'planning' ? 'selected' : ''; ?>>ກຳລັງວາງແຜນ</option>
                                <option value="completed" <?php echo $status === 'completed' ? 'selected' : ''; ?>>ສຳເລັດແລ້ວ</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn" style="width: 100%; margin-top: 1.5rem;">ຄົ້ນຫາ</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </section>

    <!-- Projects Grid Section - ສ່ວນສະແດງລາຍຊື່ໂຄງການ -->
    <section class="section" style="background: white;">
        <div class="container">
            <div class="section-header">
                <h2 class="section-title">
                    <?php if ($search || $status): // ກວດສອບວ່າກຳລັງຄົ້ນຫາ ຫຼື ກັ່ນຕອງ ?>
                        ຜົນການຄົ້ນຫາ
                    <?php else: ?>
                        ໂຄງການທັງໝົດ
                    <?php endif ?>
                </h2>
                <p class="section-subtitle">
                    ສະແດງ <?php echo count($projects); ?> ຈາກທັງໝົດ <?php echo $totalProjects; ?> ໂຄງການ
                </p>
            </div>

            <?php if (!empty($projects)): // ກວດສອບວ່າ $projects ບໍ່ຫວ່າງເປົ່າ ?>
            <div class="grid grid-3">
                <?php foreach ($projects as $project): // ວົນລູບສະແດງແຕ່ລະໂຄງການ ?>
                <div class="card project-card fade-in">
                    <?php if ($project['video_url']): // ກວດສອບວ່າໂຄງການມີວິດີໂອ ?>
                        <video class="card-image" controls>
                            <source src="<?php echo htmlspecialchars($project['video_url']); ?>" type="video/mp4">
                            ບຣາວເຊີຂອງທ່ານບໍ່ຮອງຮັບແທັກວິດີໂອ.
                        </video>
                    <?php else: // ຖ້າບໍ່ມີວິດີໂອ, ສະແດງຮູບພາບແທນ ?>
                        <img src="<?php echo $project['master_plan_url'] ?: 'assets/images/default-project.jpg'; ?>" 
                             alt="<?php echo htmlspecialchars($project['name']); ?>" class="card-image">
                    <?php endif; ?>
                    
                    <!-- ສະຖານະຂອງໂຄງການ (ດຶງມາຈາກ $project['status']) -->
                    <div class="project-status"><?php echo ucfirst($project['status']); ?></div>
                    
                    <!-- ຊື່ໂຄງການ (ດຶງມາຈາກ $project['name']) -->
                    <h3 class="card-title"><?php echo htmlspecialchars($project['name']); ?></h3>
                    <!-- ສະຖານທີ່ໂຄງການ (ດຶງມາຈາກ $project['location']) -->
                    <p class="card-text">
                        <strong>ສະຖານທີ່:</strong> <?php echo htmlspecialchars($project["location"]); ?>
                    </p>
                    <!-- ຄຳອະທິບາຍໂຄງການ (ຕັດໃຫ້ສັ້ນລົງ) (ດຶງມາຈາກ $project['description']) -->
                    <p class="card-text">
                        <?php echo htmlspecialchars(substr($project['description'], 0, 120)) . '...'; ?>
                    </p>
                    
                    <div class="project-stats" style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 1rem; margin: 1rem 0; text-align: center;">
                        <!-- ສະແດງຈຳນວນແປງທັງໝົດ (ດຶງມາຈາກ $project['total_plots']) -->
                        <div class="stat">
                            <strong style="display: block; font-size: 1.2rem; color: #667eea;"><?php echo $project["total_plots"] ?: 0; ?></strong>
                            <span style="font-size: 0.8rem; color: #666;">ແປງທັງໝົດ</span>
                        </div>
                        <!-- ສະແດງຈຳນວນແປງທີ່ວ່າງ (ດຶງມາຈາກ $project['available_plots']) -->
                        <div class="stat">
                            <strong style="display: block; font-size: 1.2rem; color: #28a745;"><?php echo $project["available_plots"] ?: 0; ?></strong>
                            <span style="font-size: 0.8rem; color: #666;">ວ່າງ</span>
                        </div>
                        <!-- ສະແດງຈຳນວນແປງທີ່ຂາຍແລ້ວ (ດຶງມາຈາກ $project['sold_plots']) -->
                        <div class="stat">
                            <strong style="display: block; font-size: 1.2rem; color: #dc3545;"><?php echo $project["sold_plots"] ?: 0; ?></strong>
                            <span style="font-size: 0.8rem; color: #666;">ຂາຍແລ້ວ</span>
                        </div>
                    </div>
                    
                    <div class="card-actions" style="display: flex; gap: 0.5rem;">
                        <!-- ລິ້ງໄປໜ້າລາຍລະອຽດໂຄງການ -->
                        <a href="project-details.php?id=<?php echo $project["id"]; ?>" class="btn" style="flex: 1;">ເບິ່ງລາຍລະອຽດ</a>
                        <!-- ລິ້ງໄປໜ້າແປງທີ່ດິນຂອງໂຄງການນີ້ -->
                        <a href="plots.php?project_id=<?php echo $project["id"]; ?>" class="btn btn-secondary" style="flex: 1;">ເບິ່ງແປງທີ່ດິນ</a>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <!-- Pagination - ສ່ວນການແບ່ງໜ້າ -->
            <?php if ($totalPages > 1): // ກວດສອບວ່າຈຳນວນໜ້າຫຼາຍກວ່າ 1 ?>
            <div class="pagination" style="display: flex; justify-content: center; align-items: center; gap: 0.5rem; margin-top: 3rem;">
                <?php if ($page > 1): // ປຸ່ມໄປໜ້າກ່ອນໜ້າ ?>
                    <a href="?<?php echo http_build_query(array_merge($_GET, ["page" => $page - 1])); ?>" class="btn btn-secondary">← ກ່ອນໜ້າ</a>
                <?php endif; ?>
                
                <?php for ($i = max(1, $page - 2); $i <= min($totalPages, $page + 2); $i++): // ວົນລູບສະແດງເລກໜ້າ ?>
                    <?php if ($i == $page): // ໜ້າປັດຈຸບັນ ?>
                        <span class="btn" style="background: #667eea; color: white;"><?php echo $i; ?></span>
                    <?php else: // ໜ້າອື່ນໆ ?>
                        <a href="?<?php echo http_build_query(array_merge($_GET, ["page" => $i])); ?>" class="btn btn-secondary"><?php echo $i; ?></a>
                    <?php endif; ?>
                <?php endfor; ?>
                
                <?php if ($page < $totalPages): // ປຸ່ມໄປໜ້າຕໍ່ໄປ ?>
                    <a href="?<?php echo http_build_query(array_merge($_GET, ["page" => $page + 1])); ?>" class="btn btn-secondary">ຕໍ່ໄປ →</a>
                <?php endif; ?>
            </div>
            <?php endif; ?>

            <?php else: // ຖ້າບໍ່ພົບໂຄງການ ?>
            <div class="text-center" style="padding: 3rem;">
                <h3>ບໍ່ພົບໂຄງການ</h3>
                <p>ບໍ່ມີໂຄງການໃດກົງກັບເງື່ອນໄຂການຄົ້ນຫາຂອງທ່ານ. ລອງປັບຕົວກອງຂອງທ່ານ.</p>
                <a href="projects.php" class="btn">ເບິ່ງໂຄງການທັງໝົດ</a>
            </div>
            <?php endif; ?>
        </div>
    </section>

    <!-- Call to Action Section - ສ່ວນກະຕຸ້ນການກະທຳ -->
    <section class="section">
        <div class="container text-center">
            <h2 class="section-title">ສົນໃຈໂຄງການຂອງພວກເຮົາບໍ?</h2>
            <p class="section-subtitle">ຕິດຕໍ່ພວກເຮົາເພື່ອຮຽນຮູ້ເພີ່ມເຕີມກ່ຽວກັບໂອກາດການລົງທຶນ</p>
            <a href="contact.php" class="btn">ຕິດຕໍ່ພວກເຮົາ</a>
            <a href="plots.php" class="btn btn-secondary">ຊອກຫາແປງທີ່ດິນ</a>
        </div>
    </section>

    <!-- Footer Section - ສ່ວນທ້າຍຂອງເວັບໄຊທ໌ -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3>PPS Land Management</h3>
                    <p>Your trusted partner for premium land investments and development projects in Laos.</p>
                    <!-- ADMIN_EMAIL: ຕົວແປນີ້ຖືກກຳນົດໄວ້ໃນ config/config.php -->
                    <p>Email: <?php echo ADMIN_EMAIL; ?></p>
                    <p>Phone: +856 20 5555 5555</p>
                </div>
                <div class="footer-section">
                    <h4>Quick Links</h4>
                    <ul>
                        <li><a href="index.php">ໜ້າຫຼັກ</a></li>
                        <li><a href="projects.php">ໂຄງການ</a></li>
                        <li><a href="plots.php">ແປງທີ່ດິນ</a></li>
                        <li><a href="about.php">ກ່ຽວກັບພວກເຮົາ</a></li>
                        <li><a href="contact.php">ຕິດຕໍ່</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h4>Services</h4>
                    <ul>
                        <li><a href="#">ການພັດທະນາທີ່ດິນ</a></li>
                        <li><a href="#">ການລົງທຶນອະສັງຫາລິມະສັບ</a></li>
                        <li><a href="#">ການຄຸ້ມຄອງໂຄງການ</a></li>
                        <li><a href="#">ການໃຫ້ຄຳປຶກສາ</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h4>Follow Us</h4>
                    <div class="social-links">
                        <a href="#" aria-label="Facebook">📘</a>
                        <a href="#" aria-label="Twitter">🐦</a>
                        <a href="#" aria-label="LinkedIn">💼</a>
                        <a href="#" aria-label="Instagram">📷</a>
                    </div>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; <?php echo date('Y'); ?> PPS Land Management System. ສະຫງວນລິຂະສິດທັງໝົດ.</p>
            </div>
        </div>
    </footer>

    <!-- JavaScript Files -->
    <script src="assets/js/main.js"></script>
    <script>
        // Set user login status for JavaScript
        // window.userLoggedIn: ຕົວແປ JavaScript ນີ້ຖືກໃຊ້ເພື່ອກວດສອບສະຖານະການເຂົ້າສູ່ລະບົບຂອງຜູ້ໃຊ້
        // ຂໍ້ມູນຖືກດຶງມາຈາກຟັງຊັນ isLoggedIn() ທີ່ຢູ່ໃນ includes/auth.php
        window.userLoggedIn = <?php echo isLoggedIn() ? 'true' : 'false'; ?>;
    </script>
</body>
</html>


