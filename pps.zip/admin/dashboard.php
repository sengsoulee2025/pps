<?php
// admin/dashboard.php - Modern Admin Dashboard inspired by Manus.im
require_once '../config/config.php';
require_once '../includes/project.php';
require_once '../includes/plot.php';
require_once '../includes/customer.php';
require_once '../includes/employee.php';
require_once '../includes/lead.php';

// Require admin access
requireRole('admin');

$pdo = getDBConnection();

// Get dashboard statistics
try {
    // Project stats
    $stmt = $pdo->query("SELECT COUNT(*) as total, 
                                SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active,
                                SUM(CASE WHEN status = 'planning' THEN 1 ELSE 0 END) as planning,
                                SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed
                         FROM project");
    $projectStats = $stmt->fetch();
    
    // Plot stats
    $stmt = $pdo->query("SELECT COUNT(*) as total,
                                SUM(CASE WHEN status = 'available' THEN 1 ELSE 0 END) as available,
                                SUM(CASE WHEN status = 'reserved' THEN 1 ELSE 0 END) as reserved,
                                SUM(CASE WHEN status = 'sold' THEN 1 ELSE 0 END) as sold
                         FROM plot");
    $plotStats = $stmt->fetch();
    
    // Customer stats
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM customer");
    $customerStats = $stmt->fetch();
    
    // Lead stats
    $stmt = $pdo->query("SELECT COUNT(*) as total,
                                SUM(CASE WHEN status = 'new' THEN 1 ELSE 0 END) as new_leads,
                                SUM(CASE WHEN status = 'contacted' THEN 1 ELSE 0 END) as contacted,
                                SUM(CASE WHEN status = 'converted' THEN 1 ELSE 0 END) as converted
                         FROM lead");
    $leadStats = $stmt->fetch();
    
    // Sales stats
    $stmt = $pdo->query("SELECT COUNT(*) as total_sales,
                                COALESCE(SUM(sale_price), 0) as total_revenue,
                                COALESCE(AVG(sale_price), 0) as avg_sale_price
                         FROM sale");
    $salesStats = $stmt->fetch();
    
    // Recent activities
    $stmt = $pdo->query("SELECT 'customer' as type, first_name, last_name, created_at FROM customer 
                         UNION ALL
                         SELECT 'lead' as type, first_name, last_name, created_at FROM lead
                         ORDER BY created_at DESC LIMIT 10");
    $recentActivities = $stmt->fetchAll();
    
} catch (Exception $e) {
    error_log("Dashboard error: " . $e->getMessage());
    $projectStats = ['total' => 0, 'active' => 0, 'planning' => 0, 'completed' => 0];
    $plotStats = ['total' => 0, 'available' => 0, 'reserved' => 0, 'sold' => 0];
    $customerStats = ['total' => 0];
    $leadStats = ['total' => 0, 'new_leads' => 0, 'contacted' => 0, 'converted' => 0];
    $salesStats = ['total_sales' => 0, 'total_revenue' => 0, 'avg_sale_price' => 0];
    $recentActivities = [];
}
?>

<!DOCTYPE html>
<html lang="lo">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ແອັດມິນ - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="../assets/css/admin_style.css">
    <link rel="stylesheet" href="../assets/css/themes.css">
    <link rel="stylesheet" href="../assets/css/admin_themes.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
</head>
<body>
    <!-- Modern Admin Header -->
    <header class="admin-header">
        <div class="admin-header-container">
            <div class="admin-brand">
                <a href="dashboard.php" class="admin-logo">
                    <span style="font-weight: 700; font-size: 1.5rem; color: var(--text-primary);">PPS Admin</span>
                </a>
            </div>

            <nav class="admin-nav" id="admin-nav">
                <ul class="admin-nav-menu">
                    <li><a href="dashboard.php" class="admin-nav-link active">
                        <i class="fas fa-tachometer-alt"></i>
                        <span>ໜ້າຫຼັກ</span>
                    </a></li>
                    <li><a href="projects.php" class="admin-nav-link">
                        <i class="fas fa-project-diagram"></i>
                        <span>ໂຄງການ</span>
                    </a></li>
                    <li><a href="plots.php" class="admin-nav-link">
                        <i class="fas fa-map-marked-alt"></i>
                        <span>ແປງທີ່ດິນ</span>
                    </a></li>
                    <li><a href="zones.php" class="admin-nav-link">
                        <i class="fas fa-layer-group"></i>
                        <span>ໂຊນ</span>
                    </a></li>
                    <li><a href="customers.php" class="admin-nav-link">
                        <i class="fas fa-users"></i>
                        <span>ລູກຄ້າ</span>
                    </a></li>
                    <li><a href="leads.php" class="admin-nav-link">
                        <i class="fas fa-bullhorn"></i>
                        <span>ລູກຄ້າສົນໃຈ</span>
                    </a></li>
                    <li><a href="employees.php" class="admin-nav-link">
                        <i class="fas fa-user-tie"></i>
                        <span>ພະນັກງານ</span>
                    </a></li>
                    <li><a href="sales.php" class="admin-nav-link">
                        <i class="fas fa-dollar-sign"></i>
                        <span>ການຂາຍ</span>
                    </a></li>
                    <li><a href="reports.php" class="admin-nav-link">
                        <i class="fas fa-chart-bar"></i>
                        <span>ລາຍງານ</span>
                    </a></li>
                    <li><a href="settings.php" class="admin-nav-link">
                        <i class="fas fa-cog"></i>
                        <span>ຕັ້ງຄ່າ</span>
                    </a></li>
                </ul>
            </nav>

            <div class="admin-header-actions">
                <div class="admin-user-menu">
                    <button class="admin-user-btn" id="admin-user-btn">
                        <i class="fas fa-user-circle"></i>
                        <span><?php echo htmlspecialchars(getCurrentUser()['username'] ?? 'Admin'); ?></span>
                        <i class="fas fa-chevron-down"></i>
                    </button>
                    <div class="admin-user-dropdown" id="admin-user-dropdown">
                        <a href="../customer/dashboard.php" class="admin-dropdown-item">
                            <i class="fas fa-eye"></i>
                            ເບິ່ງໜ້າລູກຄ້າ
                        </a>
                        <a href="../index.php" class="admin-dropdown-item">
                            <i class="fas fa-home"></i>
                            ໜ້າຫຼັກເວັບໄຊທ໌
                        </a>
                        <div class="admin-dropdown-divider"></div>
                        <a href="../logout.php" class="admin-dropdown-item">
                            <i class="fas fa-sign-out-alt"></i>
                            ອອກຈາກລະບົບ
                        </a>
                    </div>
                </div>
                
                <button class="admin-menu-toggle" id="admin-menu-toggle">
                    <i class="fas fa-bars"></i>
                </button>
            </div>
        </div>
    </header>

    <!-- Admin Main Content -->
    <main class="admin-main">
        <div class="admin-container">
            <!-- Page Header -->
            <div class="admin-page-header admin-fade-in">
                <h1 class="admin-page-title">ແຜງຄວບຄຸມຫຼັກ</h1>
                <p class="admin-page-subtitle">ພາບລວມຂອງລະບົບການຄຸ້ມຄອງທີ່ດິນ PPS - ຕິດຕາມສະຖິຕິ, ການດຳເນີນງານ, ແລະຜົນງານຂອງທ່ານ</p>
            </div>

            <!-- Statistics Grid -->
            <div class="admin-stats-grid admin-slide-up">
                <!-- Projects Stats -->
                <div class="admin-stat-card">
                    <div class="admin-stat-icon">
                        <i class="fas fa-project-diagram"></i>
                    </div>
                    <div class="admin-stat-value"><?php echo number_format($projectStats['total']); ?></div>
                    <div class="admin-stat-label">ໂຄງການທັງໝົດ</div>
                    <div style="margin-top: 12px; display: flex; justify-content: space-between; font-size: 0.8rem; color: var(--text-secondary);">
                        <span>✅ ໃຊ້ງານ: <?php echo $projectStats['active']; ?></span>
                        <span>📋 ວາງແຜນ: <?php echo $projectStats['planning']; ?></span>
                    </div>
                </div>

                <!-- Plots Stats -->
                <div class="admin-stat-card">
                    <div class="admin-stat-icon">
                        <i class="fas fa-map-marked-alt"></i>
                    </div>
                    <div class="admin-stat-value"><?php echo number_format($plotStats['total']); ?></div>
                    <div class="admin-stat-label">ແປງທີ່ດິນທັງໝົດ</div>
                    <div style="margin-top: 12px; display: flex; justify-content: space-between; font-size: 0.8rem; color: var(--text-secondary);">
                        <span>🟢 ວ່າງ: <?php echo $plotStats['available']; ?></span>
                        <span>🔴 ຂາຍແລ້ວ: <?php echo $plotStats['sold']; ?></span>
                    </div>
                </div>

                <!-- Customers Stats -->
                <div class="admin-stat-card">
                    <div class="admin-stat-icon">
                        <i class="fas fa-users"></i>
                    </div>
                    <div class="admin-stat-value"><?php echo number_format($customerStats['total']); ?></div>
                    <div class="admin-stat-label">ລູກຄ້າທັງໝົດ</div>
                </div>

                <!-- Leads Stats -->
                <div class="admin-stat-card">
                    <div class="admin-stat-icon">
                        <i class="fas fa-bullhorn"></i>
                    </div>
                    <div class="admin-stat-value"><?php echo number_format($leadStats['total']); ?></div>
                    <div class="admin-stat-label">ລູກຄ້າສົນໃຈ</div>
                    <div style="margin-top: 12px; display: flex; justify-content: space-between; font-size: 0.8rem; color: var(--text-secondary);">
                        <span>🆕 ໃໝ່: <?php echo $leadStats['new_leads']; ?></span>
                        <span>✅ ແປງແລ້ວ: <?php echo $leadStats['converted']; ?></span>
                    </div>
                </div>

                <!-- Sales Stats -->
                <div class="admin-stat-card">
                    <div class="admin-stat-icon">
                        <i class="fas fa-dollar-sign"></i>
                    </div>
                    <div class="admin-stat-value"><?php echo number_format($salesStats['total_sales']); ?></div>
                    <div class="admin-stat-label">ການຂາຍທັງໝົດ</div>
                    <div style="margin-top: 12px; font-size: 0.8rem; color: var(--text-secondary);">
                        💰 ລາຍໄດ້: <?php echo number_format($salesStats['total_revenue']); ?> ກີບ
                    </div>
                </div>

                <!-- Revenue Stats -->
                <div class="admin-stat-card">
                    <div class="admin-stat-icon">
                        <i class="fas fa-chart-line"></i>
                    </div>
                    <div class="admin-stat-value"><?php echo number_format($salesStats['total_revenue']); ?></div>
                    <div class="admin-stat-label">ລາຍໄດ້ທັງໝົດ (ກີບ)</div>
                    <div style="margin-top: 12px; font-size: 0.8rem; color: var(--text-secondary);">
                        📊 ເຄື່ອງ: <?php echo number_format($salesStats['avg_sale_price']); ?> ກີບ
                    </div>
                </div>
            </div>

            <!-- Quick Actions -->
            <div class="admin-card admin-fade-in" style="margin-bottom: 32px;">
                <div class="admin-card-header">
                    <h2 class="admin-card-title">ການດຳເນີນການດ່ວນ</h2>
                </div>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px;">
                    <a href="projects.php?action=add" class="admin-btn admin-btn-primary">
                        <i class="fas fa-plus"></i>
                        ເພີ່ມໂຄງການໃໝ່
                    </a>
                    <a href="plots.php?action=add" class="admin-btn admin-btn-secondary">
                        <i class="fas fa-map-pin"></i>
                        ເພີ່ມແປງທີ່ດິນ
                    </a>
                    <a href="customers.php" class="admin-btn admin-btn-secondary">
                        <i class="fas fa-user-plus"></i>
                        ຈັດການລູກຄ້າ
                    </a>
                    <a href="reports.php" class="admin-btn admin-btn-secondary">
                        <i class="fas fa-chart-bar"></i>
                        ເບິ່ງລາຍງານ
                    </a>
                </div>
            </div>

            <!-- Recent Activities -->
            <div class="admin-card admin-slide-up">
                <div class="admin-card-header">
                    <h2 class="admin-card-title">ກິດຈະກຳຫຼ້າສຸດ</h2>
                    <a href="#" class="admin-btn admin-btn-sm admin-btn-secondary">ເບິ່ງທັງໝົດ</a>
                </div>
                
                <?php if (!empty($recentActivities)): ?>
                <div class="admin-table-container">
                    <table class="admin-table">
                        <thead>
                            <tr>
                                <th>ປະເພດ</th>
                                <th>ຊື່</th>
                                <th>ວັນທີ</th>
                                <th>ສະຖານະ</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($recentActivities as $activity): ?>
                            <tr>
                                <td>
                                    <?php if ($activity['type'] == 'customer'): ?>
                                        <span class="admin-badge admin-badge-success">
                                            <i class="fas fa-user"></i>
                                            ລູກຄ້າໃໝ່
                                        </span>
                                    <?php else: ?>
                                        <span class="admin-badge admin-badge-info">
                                            <i class="fas fa-bullhorn"></i>
                                            ລູກຄ້າສົນໃຈ
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo htmlspecialchars($activity['first_name'] . ' ' . $activity['last_name']); ?></td>
                                <td><?php echo date('d/m/Y H:i', strtotime($activity['created_at'])); ?></td>
                                <td>
                                    <span class="admin-badge admin-badge-success">
                                        <i class="fas fa-check"></i>
                                        ສຳເລັດ
                                    </span>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php else: ?>
                <div style="text-align: center; padding: 40px; color: var(--text-secondary);">
                    <i class="fas fa-inbox" style="font-size: 3rem; margin-bottom: 16px; opacity: 0.5;"></i>
                    <p>ຍັງບໍ່ມີກິດຈະກຳຫຼ້າສຸດ</p>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </main>

    <!-- JavaScript -->
    <script src="../assets/js/theme-switcher.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        // Admin Dashboard JavaScript
        document.addEventListener('DOMContentLoaded', function() {
            // User dropdown toggle
            const userBtn = document.getElementById('admin-user-btn');
            const userDropdown = document.getElementById('admin-user-dropdown');
            
            if (userBtn && userDropdown) {
                userBtn.addEventListener('click', function(e) {
                    e.stopPropagation();
                    userDropdown.classList.toggle('show');
                });
                
                // Close dropdown when clicking outside
                document.addEventListener('click', function() {
                    userDropdown.classList.remove('show');
                });
            }
            
            // Mobile menu toggle
            const menuToggle = document.getElementById('admin-menu-toggle');
            const adminNav = document.getElementById('admin-nav');
            
            if (menuToggle && adminNav) {
                menuToggle.addEventListener('click', function() {
                    adminNav.classList.toggle('show');
                });
            }
            
            // Add animation on scroll
            const observerOptions = {
                threshold: 0.1,
                rootMargin: '0px 0px -50px 0px'
            };
            
            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.style.opacity = '1';
                        entry.target.style.transform = 'translateY(0)';
                    }
                });
            }, observerOptions);
            
            document.querySelectorAll('.admin-fade-in, .admin-slide-up').forEach(el => {
                el.style.opacity = '0';
                el.style.transform = 'translateY(20px)';
                el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
                observer.observe(el);
            });
        });
    </script>
</body>
</html>

