<?php
require_once '../config/config.php';

// Require admin access
requireRole('admin');

$alert = getAlert();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Leads - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="admin-layout">
        <!-- Sidebar -->
        <aside class="admin-sidebar">
            <div class="sidebar-brand">
                <h2>PPS Admin</h2>
            </div>
            <ul class="sidebar-nav">
                <li><a href="dashboard.php"><span class="icon">📊</span> Dashboard</a></li>
                <li><a href="projects.php"><span class="icon">🏗️</span> Projects</a></li>
                <li><a href="plots.php"><span class="icon">🏞️</span> Land Plots</a></li>
                <li><a href="customers.php"><span class="icon">👥</span> Customers</a></li>
                <li><a href="leads.php"><span class="icon">🎯</span> Leads</a></li>
                <li><a href="employees.php"><span class="icon">👨‍💼</span> Employees</a></li>
                <li><a href="sales.php"><span class="icon">💰</span> Sales</a></li>
                <li><a href="media.php"><span class="icon">📁</span> Media</a></li>
                <li><a href="reports.php"><span class="icon">📈</span> Reports</a></li>
                <li><a href="settings.php"><span class="icon">⚙️</span> Settings</a></li>
                <li><a href="../logout.php"><span class="icon">🚪</span> Logout</a></li>
            </ul>
        </aside>

        <!-- Main Content -->
        <main class="admin-content">
            <div class="admin-header">
                <h1 class="admin-title">Leads</h1>
            </div>

            <?php if ($alert): ?>
            <div class="alert alert-<?php echo $alert['type']; ?>">
                <?php echo htmlspecialchars($alert['message']); ?>
            </div>
            <?php endif; ?>

            <div class="dashboard-card">
                <h3>Leads Management</h3>
                <p>This page is under construction.</p>
            </div>
        </main>
    </div>
</body>
</html>
