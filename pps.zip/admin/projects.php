<?php
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/../includes/project.php';

$pdo = getDBConnection();
$projectManager = new Project($pdo);
$projects = $projectManager->getAllProjects();
?>

<div class="page-header">
    <h1>ຈັດການໂຄງການ</h1>
    <button class="btn-primary" onclick="openAddModal()">+ ເພີ່ມໂຄງການ</button>
</div>

<div class="content-card">
    <div class="table-responsive-wrapper">
        <table>
            <thead>
                <tr>
                    <th>ຮູບພາບ</th>
                    <th>ຊື່ໂຄງການ</th>
                    <th>ສະຖານທີ່</th>
                    <th>ສະຖານະ</th>
                    <th>ການດຳເນີນການ</th>
                </tr>
            </thead>
            <tbody id="projects-table-body">
                <?php foreach ($projects as $project): ?>
                    <tr id="project-row-<?php echo $project['id']; ?>">
                        <td><img src="../<?php echo !empty($project['master_plan_url']) ? htmlspecialchars($project['master_plan_url']) : 'assets/images/default-project.jpg'; ?>" alt="Project Image" width="80" class="project-thumbnail"></td>
                        <td class="project-name"><?php echo htmlspecialchars($project['name']); ?></td>
                        <td class="project-location"><?php echo htmlspecialchars($project['location']); ?></td>
                        <td class="project-status"><?php echo ucfirst(htmlspecialchars($project['status'])); ?></td>
                        <td>
                            <button class="btn-edit" onclick="openEditModal(<?php echo $project['id']; ?>)">ແກ້ໄຂ</button>
                            <button class="btn-danger" onclick="deleteProject(<?php echo $project['id']; ?>)">ລົບ</button>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<div id="addProjectModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>ເພີ່ມໂຄງການໃໝ່</h2>
            <span class="close" onclick="closeModal('addProjectModal')">&times;</span>
        </div>
        <div class="modal-body">
            <form id="addProjectForm" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="add_name">ຊື່ໂຄງການ</label>
                    <input type="text" id="add_name" name="name" required>
                </div>
                <div class="form-group">
                    <label for="add_location">ສະຖານທີ່</label>
                    <input type="text" id="add_location" name="location" required>
                </div>
                <div class="form-group">
                    <label for="add_master_plan_image">ຮູບພາບໂຄງການ</label>
                    <input type="file" id="add_master_plan_image" name="master_plan_image" accept="image/*">
                </div>
                <div class="form-group">
                    <label for="add_description">ລາຍລະອຽດ</label>
                    <textarea id="add_description" name="description" rows="4"></textarea>
                </div>
                <button type="submit" class="btn-primary">ບັນທຶກໂຄງການ</button>
            </form>
        </div>
    </div>
</div>

<div id="editProjectModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>ແກ້ໄຂໂຄງການ</h2>
            <span class="close" onclick="closeModal('editProjectModal')">&times;</span>
        </div>
        <div class="modal-body">
            <form id="editProjectForm" enctype="multipart/form-data">
                <input type="hidden" id="edit_project_id" name="project_id">
                <div class="form-group">
                    <label for="edit_name">ຊື່ໂຄງການ</label>
                    <input type="text" id="edit_name" name="name" required>
                </div>
                <div class="form-group">
                    <label for="edit_location">ສະຖານທີ່</label>
                    <input type="text" id="edit_location" name="location" required>
                </div>
                
                <div class="form-group">
                    <label>ຮູບພາບປັດຈຸບັນ</label>
                    <img id="edit_image_preview" src="" alt="Current Project Image" style="max-width: 100px; height: auto; margin-top: 5px; border-radius: 5px; display: none;">
                    <span id="edit_no_image_text">ບໍ່ມີຮູບພາບ</span>
                </div>
                
                <div class="form-group">
                    <label for="edit_master_plan_image">ປ່ຽນຮູບພາບໂຄງການ</label>
                    <input type="file" id="edit_master_plan_image" name="master_plan_image" accept="image/*">
                    <small>ປະໄວ້ຫວ່າງ ຖ້າບໍ່ຕ້ອງການປ່ຽນຮູບປັດຈຸບັນ.</small>
                </div>
                <div class="form-group">
                    <label for="edit_description">ລາຍລະອຽດ</label>
                    <textarea id="edit_description" name="description" rows="4"></textarea>
                </div>
                <button type="submit" class="btn-primary">ອັບເດດໂຄງການ</button>
            </form>
        </div>
    </div>
</div>
<script>
// Modal Functions
function openAddModal() { document.getElementById('addProjectModal').style.display = 'flex'; }
function closeModal(modalId) { document.getElementById(modalId).style.display = 'none'; }
function openEditModal(id) {
    fetch(`../api/admin/projects_api.php?action=get&id=${id}`)
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            document.getElementById('edit_project_id').value = data.data.id;
            document.getElementById('edit_name').value = data.data.name;
            document.getElementById('edit_location').value = data.data.location;
            document.getElementById('edit_description').value = data.data.description;
            
            const imagePreview = document.getElementById('edit_image_preview');
            const noImageText = document.getElementById('edit_no_image_text');

            if (data.data.master_plan_url) {
                imagePreview.src = `../${data.data.master_plan_url}?t=${new Date().getTime()}`;
                imagePreview.style.display = 'block';
                noImageText.style.display = 'none';
            } else {
                imagePreview.style.display = 'none';
                noImageText.style.display = 'block';
            }
            document.getElementById('editProjectModal').style.display = 'flex';
        } else { 
            Swal.fire({ title: 'ຜິດພາດ!', text: data.message, icon: 'error' });
        }
    });
}

// === Event Listener สำหรับฟอร์มเพิ่มโปรเจกต์ ===
document.getElementById('addProjectForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const formData = new FormData(this);
    
    fetch('../api/admin/projects_api.php?action=create', { method: 'POST', body: formData })
    .then(response => response.text())
    .then(text => {
        try {
            const data = JSON.parse(text);
            if (data.success) {
                Swal.fire({
                    title: 'ສຳເລັດ!',
                    text: 'ເພີ່ມໂຄງການໃໝ່ສຳເລັດແລ້ວ.',
                    icon: 'success',
                    confirmButtonText: 'ຕົກລົງ'
                }).then(() => { window.location.reload(); });
            } else {
                Swal.fire({
                    title: 'ຜິດພາດ!',
                    text: data.message,
                    icon: 'error',
                    confirmButtonText: 'ຕົກລົງ'
                });
            }
        } catch (err) {
            Swal.fire({
                title: 'Server ມີບັນຫາ!',
                html: `<p>Server ບໍ່ໄດ້ຕອບກັບເປັນ JSON. ນີ້ຄື Error ທີ່ໄດ້ຮັບ:</p><pre style="text-align:left; background:#eee; padding:10px; border-radius:5px; color: red;">${text}</pre>`,
                icon: 'error'
            });
        }
    }).catch(error => {
        console.error('Network Error:', error);
        Swal.fire('Network ມີບັນຫາ!', 'ບໍ່ສາມາດເຊື່ອມຕໍ່ກັບ Server ໄດ້.', 'error');
    });
});

// === Event Listener สำหรับฟอร์มแก้ไขโปรเจกต์ ===
document.getElementById('editProjectForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const formData = new FormData(this);
    
    fetch('../api/admin/projects_api.php?action=update', { method: 'POST', body: formData })
    .then(response => response.text())
    .then(text => {
        try {
            const data = JSON.parse(text);
            if (data.success) {
                Swal.fire({
                    title: 'ອັບເດດສຳເລັດ!',
                    text: 'ຂໍ້ມູນໂຄງການໄດ້ຖືກອັບເດດແລ້ວ.',
                    icon: 'success',
                    confirmButtonText: 'ຕົກລົງ'
                }).then(() => { window.location.reload(); });
            } else {
                Swal.fire({
                    title: 'ຜິດພາດ!',
                    text: data.message,
                    icon: 'error',
                    confirmButtonText: 'ຕົກລົງ'
                });
            }
        } catch (err) {
            Swal.fire({
                title: 'Server ມີບັນຫາ!',
                html: `<p>Server ບໍ່ໄດ້ຕອບກັບເປັນ JSON. ນີ້ຄື Error ທີ່ໄດ້ຮັບ:</p><pre style="text-align:left; background:#eee; padding:10px; border-radius:5px; color: red;">${text}</pre>`,
                icon: 'error'
            });
        }
    }).catch(error => {
        console.error('Network Error:', error);
        Swal.fire('Network ມີບັນຫາ!', 'ບໍ່ສາມາດເຊື່ອມຕໍ່ກັບ Server ໄດ້.', 'error');
    });
});


// === ฟังก์ชันลบโปรเจกต์ ===
function deleteProject(id) {
    Swal.fire({
        title: 'ທ່ານແນ່ໃຈບໍ່?',
        text: "ທ່ານຕ້ອງການລົບໂຄງການນີ້ແທ້ບໍ?",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'ແມ່ນ, ລົບເລີຍ!',
        cancelButtonText: 'ຍົກເລີກ'
    }).then((result) => {
        if (result.isConfirmed) {
            const formData = new FormData();
            formData.append('project_id', id);
            fetch('../api/admin/projects_api.php?action=delete', { method: 'POST', body: formData })
            .then(response => response.json()) // ສົມມຸດວ່າ delete ສົ່ງ JSON ທີ່ຖືກຕ້ອງສະເໝີ
            .then(data => {
                if (data.success) {
                     Swal.fire('ລົບສຳເລັດ!', 'ໂຄງການໄດ້ຖືກລົບອອກຈາກລະບົບແລ້ວ.', 'success');
                     document.getElementById(`project-row-${id}`).remove();
                } else {
                    Swal.fire({ title: 'ຜິດພາດ!', text: data.message, icon: 'error' });
                }
            }).catch(error => {
                console.error('Network Error:', error);
                Swal.fire('Network ມີບັນຫາ!', 'ບໍ່ສາມາດເຊື່ອມຕໍ່ກັບ Server ໄດ້.', 'error');
            });
        }
    });
}
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>