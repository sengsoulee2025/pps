<?php
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/../includes/zone.php';
require_once __DIR__ . '/../includes/project.php';

$pdo = getDBConnection();
$zoneManager = new ProjectZone($pdo);
$projectManager = new Project($pdo);

$allZones = $zoneManager->getAllZones();
$allProjects = $projectManager->getAllProjects();
?>

<div class="page-header">
    <h1>ຈັດການໂຊນລາຄາ</h1>
    <button class="btn-primary" onclick="openAddModal()">+ ເພີ່ມໂຊນໃໝ່</button>
</div>

<div class="content-card">
    <div class="table-responsive-wrapper">
        <table>
            <thead>
                <tr>
                    <th>ຊື່ໂຊນ</th>
                    <th>ໂຄງການ</th>
                    <th>ລາຄາຕໍ່ຕາແມັດ</th>
                    <th>ສະກຸນເງິນ</th>
                    <th>ການດຳເນີນການ</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($allZones as $zone): ?>
                    <tr id="zone-row-<?php echo $zone['id']; ?>">
                        <td><?php echo htmlspecialchars($zone['zone_name']); ?></td>
                        <td><?php echo htmlspecialchars($zone['project_name']); ?></td>
                        <td><?php echo number_format($zone['price_per_sqm'], 2); ?></td>
                        <td><?php echo htmlspecialchars($zone['currency']); ?></td>
                        <td>
                            <button class="btn-edit" onclick="openEditModal(<?php echo $zone['id']; ?>)">ແກ້ໄຂ</button>
                            <button class="btn-danger" onclick="deleteZone(<?php echo $zone['id']; ?>)">ລົບ</button>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<div id="addZoneModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>ເພີ່ມໂຊນໃໝ່</h2>
            <span class="close" onclick="closeModal('addZoneModal')">&times;</span>
        </div>
        <div class="modal-body">
            <form id="addZoneForm">
                <div class="form-group">
                    <label>ໂຄງການ</label>
                    <select name="project_id" required>
                        <option value="">-- ເລືອກໂຄງການ --</option>
                        <?php foreach ($allProjects as $project): ?>
                            <option value="<?php echo $project['id']; ?>"><?php echo htmlspecialchars($project['name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>ຊື່ໂຊນ (ເຊັ່ນ: A, B, VIP)</label>
                    <input type="text" name="zone_name" required>
                </div>
                <div class="form-group">
                    <label>ລາຄາຕໍ່ຕາແມັດ</label>
                    <input type="number" step="0.01" name="price_per_sqm" required>
                </div>
                <div class="form-group">
                    <label>ສະກຸນເງິນ</label>
                    <select name="currency" required>
                        <option value="LAK">ກີບ (LAK)</option>
                        <option value="THB">ບາດ (THB)</option>
                    </select>
                </div>
                <button type="submit" class="btn-primary">ບັນທຶກໂຊນ</button>
            </form>
        </div>
    </div>
</div>

<div id="editZoneModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>ແກ້ໄຂໂຊນ</h2>
            <span class="close" onclick="closeModal('editZoneModal')">&times;</span>
        </div>
        <div class="modal-body">
            <form id="editZoneForm">
                <input type="hidden" id="edit_zone_id" name="zone_id">
                <input type="hidden" id="edit_project_id" name="project_id">
                <div class="form-group">
                    <label>ໂຄງການ</label>
                    <p id="edit_project_name" style="font-weight: bold;"></p>
                </div>
                <div class="form-group">
                    <label>ຊື່ໂຊນ</label>
                    <input type="text" id="edit_zone_name" name="zone_name" required>
                </div>
                <div class="form-group">
                    <label>ລາຄາຕໍ່ຕາແມັດ</label>
                    <input type="number" step="0.01" id="edit_price_per_sqm" name="price_per_sqm" required>
                </div>
                <div class="form-group">
                    <label>ສະກຸນເງິນ</label>
                    <select id="edit_currency" name="currency" required>
                        <option value="LAK">ກີບ (LAK)</option>
                        <option value="THB">ບາດ (THB)</option>
                    </select>
                </div>
                <button type="submit" class="btn-primary">ອັບເດດໂຊນ</button>
            </form>
        </div>
    </div>
</div>

<script>
// === ຟັງຊັນທີ່ເປັນ Global (onclick ສາມາດເອີ້ນໃຊ້ໄດ້) ===
function openAddModal() {
    document.getElementById('addZoneForm').reset();
    document.getElementById('addZoneModal').style.display = 'flex';
}
function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

function openEditModal(id) {
    fetch(`../api/admin/zones_api.php?action=get_one&id=${id}`)
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            const zone = data.data;
            document.getElementById('edit_zone_id').value = zone.id;
            document.getElementById('edit_project_id').value = zone.project_id;
            
            const projectName = document.querySelector(`#zone-row-${id} td:nth-child(2)`).textContent;
            document.getElementById('edit_project_name').textContent = projectName;

            document.getElementById('edit_zone_name').value = zone.zone_name;
            document.getElementById('edit_price_per_sqm').value = zone.price_per_sqm;
            document.getElementById('edit_currency').value = zone.currency;
            document.getElementById('editZoneModal').style.display = 'flex';
        } else {
            Swal.fire('ຜິດພາດ!', data.message, 'error');
        }
    }).catch(err => {
        console.error("Open Edit Modal Error:", err);
        Swal.fire('ຜິດພາດ!', 'ບໍ່ສາມາດດຶງຂໍ້ມູນໂຊນໄດ້.', 'error');
    });
}

function deleteZone(id) {
    Swal.fire({
        title: 'ທ່ານແນ່ໃຈບໍ່?',
        text: "ທ່ານຕ້ອງການລົບໂຊນນີ້ແທ້ບໍ?",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'ແມ່ນ, ລົບເລີຍ!',
        cancelButtonText: 'ຍົກເລີກ'
    }).then((result) => {
        if (result.isConfirmed) {
            const formData = new FormData();
            formData.append('zone_id', id);
            fetch('../api/admin/zones_api.php?action=delete', { method: 'POST', body: formData })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    Swal.fire('ລົບສຳເລັດ!', data.message, 'success').then(() => {
                        document.getElementById(`zone-row-${id}`).remove();
                    });
                } else {
                    Swal.fire('ຜິດພາດ!', data.message, 'error');
                }
            });
        }
    });
}

// === ໂຄດທີ່ຕັ້ງຄ່າ Event Listener (ເຮັດວຽກຫຼັງຈາກໜ້າໂຫຼດແລ້ວ) ===
document.addEventListener('DOMContentLoaded', function() {
    
    // ຟັງຊັນກາງສຳລັບຈັດການ Response ຂອງ Form
    function handleFormResponse(text, successMessage) {
        try {
            const data = JSON.parse(text);
            if (data.success) {
                Swal.fire({ title: 'ສຳເລັດ!', text: successMessage, icon: 'success' })
                .then(() => { window.location.reload(); });
            } else {
                Swal.fire({ title: 'ຜິດພາດ!', text: data.message, icon: 'error' });
            }
        } catch (e) {
            Swal.fire({
                title: 'Server ມີບັນຫາ!',
                html: `<p>Server ບໍ່ໄດ້ຕອບກັບເປັນ JSON. ນີ້ຄື Error ທີ່ໄດ້ຮັບ:</p><pre style="text-align:left; background:#eee; padding:10px; border-radius:5px; color: red; max-height: 200px; overflow-y: auto;">${text}</pre>`,
                icon: 'error'
            });
        }
    }
    
    document.getElementById('addZoneForm').addEventListener('submit', function(e) {
        e.preventDefault();
        fetch('../api/admin/zones_api.php?action=create', { method: 'POST', body: new FormData(this) })
        .then(response => response.text())
        .then(text => handleFormResponse(text, 'ເພີ່ມໂຊນໃໝ່ສຳເລັດ!'))
        .catch(err => console.error("Add Zone Error:", err));
    });

    document.getElementById('editZoneForm').addEventListener('submit', function(e) {
        e.preventDefault();
        fetch('../api/admin/zones_api.php?action=update', { method: 'POST', body: new FormData(this) })
        .then(response => response.text())
        .then(text => handleFormResponse(text, 'ອັບເດດໂຊນສຳເລັດ!'))
        .catch(err => console.error("Edit Zone Error:", err));
    });
});
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>