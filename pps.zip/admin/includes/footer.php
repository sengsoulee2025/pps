<?php
// admin/includes/footer.php
?>

        </div> </main> <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    
    <script src="../assets/js/admin.js"></script>

</body>
</html>