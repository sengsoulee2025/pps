<?php
// admin/includes/header.php - Modern Admin Header inspired by Manus.im
require_once __DIR__ . '/../../config/config.php';

// Protect admin pages
requireRole('admin');
?>
<!DOCTYPE html>
<html lang="lo">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ແອັດມິນ - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="../assets/css/admin_style.css">
    <link rel="stylesheet" href="../assets/css/themes.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
</head>
<body>
    <!-- Modern Admin Header -->
    <header class="admin-header">
        <div class="admin-header-container">
            <div class="admin-brand">
                <a href="dashboard.php" class="admin-logo">
                    <span style="font-weight: 700; font-size: 1.5rem; color: var(--text-primary);">PPS Admin</span>
                </a>
            </div>

            <nav class="admin-nav" id="admin-nav">
                <ul class="admin-nav-menu">
                    <li><a href="dashboard.php" class="admin-nav-link">
                        <i class="fas fa-tachometer-alt"></i>
                        <span>ໜ້າຫຼັກ</span>
                    </a></li>
                    <li><a href="projects.php" class="admin-nav-link">
                        <i class="fas fa-project-diagram"></i>
                        <span>ໂຄງການ</span>
                    </a></li>
                    <li><a href="plots.php" class="admin-nav-link">
                        <i class="fas fa-map-marked-alt"></i>
                        <span>ແປງທີ່ດິນ</span>
                    </a></li>
                    <li><a href="zones.php" class="admin-nav-link">
                        <i class="fas fa-layer-group"></i>
                        <span>ໂຊນ</span>
                    </a></li>
                    <li><a href="customers.php" class="admin-nav-link">
                        <i class="fas fa-users"></i>
                        <span>ລູກຄ້າ</span>
                    </a></li>
                    <li><a href="leads.php" class="admin-nav-link">
                        <i class="fas fa-bullhorn"></i>
                        <span>ລູກຄ້າສົນໃຈ</span>
                    </a></li>
                    <li><a href="employees.php" class="admin-nav-link">
                        <i class="fas fa-user-tie"></i>
                        <span>ພະນັກງານ</span>
                    </a></li>
                    <li><a href="sales.php" class="admin-nav-link">
                        <i class="fas fa-dollar-sign"></i>
                        <span>ການຂາຍ</span>
                    </a></li>
                    <li><a href="reports.php" class="admin-nav-link">
                        <i class="fas fa-chart-bar"></i>
                        <span>ລາຍງານ</span>
                    </a></li>
                    <li><a href="settings.php" class="admin-nav-link">
                        <i class="fas fa-cog"></i>
                        <span>ຕັ້ງຄ່າ</span>
                    </a></li>
                </ul>
            </nav>

            <div class="admin-header-actions">
                <div class="admin-user-menu">
                    <button class="admin-user-btn" id="admin-user-btn">
                        <i class="fas fa-user-circle"></i>
                        <span><?php echo htmlspecialchars(getCurrentUser()['username'] ?? 'Admin'); ?></span>
                        <i class="fas fa-chevron-down"></i>
                    </button>
                    <div class="admin-user-dropdown" id="admin-user-dropdown">
                        <a href="../customer/dashboard.php" class="admin-dropdown-item">
                            <i class="fas fa-eye"></i>
                            ເບິ່ງໜ້າລູກຄ້າ
                        </a>
                        <a href="../index.php" class="admin-dropdown-item">
                            <i class="fas fa-home"></i>
                            ໜ້າຫຼັກເວັບໄຊທ໌
                        </a>
                        <div class="admin-dropdown-divider"></div>
                        <a href="../logout.php" class="admin-dropdown-item">
                            <i class="fas fa-sign-out-alt"></i>
                            ອອກຈາກລະບົບ
                        </a>
                    </div>
                </div>
                
                <button class="admin-menu-toggle" id="admin-menu-toggle">
                    <i class="fas fa-bars"></i>
                </button>
            </div>
        </div>
    </header>

    <!-- Admin Main Content -->
    <main class="admin-main">
        <div class="admin-container">

