<?php
require_once '../config/config.php';
require_once '../includes/customer.php';

// Require admin access
requireRole('admin');

$pdo = getDBConnection();
$customer = new Customer($pdo);

// Get all customers
$customers = $customer->getAllCustomers();

$alert = getAlert();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customers - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="admin-layout">
        <!-- Sidebar -->
        <aside class="admin-sidebar">
            <div class="sidebar-brand">
                <h2>PPS Admin</h2>
            </div>
            <ul class="sidebar-nav">
                <li><a href="dashboard.php"><span class="icon">📊</span> Dashboard</a></li>
                <li><a href="projects.php"><span class="icon">🏗️</span> Projects</a></li>
                <li><a href="plots.php"><span class="icon">🏞️</span> Land Plots</a></li>
                <li><a href="customers.php" class="active"><span class="icon">👥</span> Customers</a></li>
                <li><a href="leads.php"><span class="icon">🎯</span> Leads</a></li>
                <li><a href="employees.php"><span class="icon">👨‍💼</span> Employees</a></li>
                <li><a href="sales.php"><span class="icon">💰</span> Sales</a></li>
                <li><a href="media.php"><span class="icon">📁</span> Media</a></li>
                <li><a href="reports.php"><span class="icon">📈</span> Reports</a></li>
                <li><a href="settings.php"><span class="icon">⚙️</span> Settings</a></li>
                <li><a href="../logout.php"><span class="icon">🚪</span> Logout</a></li>
            </ul>
        </aside>

        <!-- Main Content -->
        <main class="admin-content">
            <div class="admin-header">
                <h1 class="admin-title">Customers</h1>
            </div>

            <?php if ($alert): ?>
            <div class="alert alert-<?php echo $alert['type']; ?>">
                <?php echo htmlspecialchars($alert['message']); ?>
            </div>
            <?php endif; ?>

            <div class="dashboard-card">
                <h3>Customer List</h3>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Phone</th>
                                <th>Email</th>
                                <th>Created</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($customers as $cust): ?>
                            <tr>
                                <td><?php echo $cust['id']; ?></td>
                                <td><?php echo htmlspecialchars($cust['first_name'] . ' ' . $cust['last_name']); ?></td>
                                <td><?php echo htmlspecialchars($cust['phone']); ?></td>
                                <td><?php echo htmlspecialchars($cust['email'] ?: 'N/A'); ?></td>
                                <td><?php echo formatDate($cust['created_at']); ?></td>
                                <td>
                                    <a href="customer_detail.php?id=<?php echo $cust['id']; ?>" class="btn btn-sm btn-primary">View</a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
</body>
</html>
