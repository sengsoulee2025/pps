<?php
require_once '../config/config.php';
require_once '../includes/reports.php';

// Require admin access
requireRole('admin');

$reports = new Reports();

// Get report parameters
$report_type = isset($_GET['type']) ? $_GET['type'] : 'overview';
$start_date = isset($_GET['start_date']) ? $_GET['start_date'] : date('Y-m-01');
$end_date = isset($_GET['end_date']) ? $_GET['end_date'] : date('Y-m-d');
$project_id = isset($_GET['project_id']) ? intval($_GET['project_id']) : null;

// Handle export requests
if (isset($_GET['export'])) {
    $export_type = $_GET['export'];
    
    switch ($export_type) {
        case 'sales':
            $data = $reports->getSalesReport($start_date, $end_date, $project_id);
            $headers = ['ID', 'Sale Price', 'Commission', 'Date', 'Plot Number', 'Area', 'Project', 'Customer', 'Employee'];
            $reports->exportToCSV($data, 'sales_report_' . date('Y-m-d') . '.csv', $headers);
            break;
            
        case 'projects':
            $data = $reports->getProjectPerformance();
            $headers = ['ID', 'Name', 'Location', 'Total Plots', 'Status', 'Actual Plots', 'Available', 'Reserved', 'Sold', 'Total Sales', 'Revenue', 'Avg Price', 'Sales Rate'];
            $reports->exportToCSV($data, 'project_performance_' . date('Y-m-d') . '.csv', $headers);
            break;
            
        case 'customers':
            $customer_data = $reports->getCustomerAnalytics();
            $reports->exportToCSV($customer_data['top_customers'], 'top_customers_' . date('Y-m-d') . '.csv');
            break;
    }
}

// Get data based on report type
$data = [];
switch ($report_type) {
    case 'sales':
        $data['sales'] = $reports->getSalesReport($start_date, $end_date, $project_id);
        $data['summary'] = $reports->getSalesSummary($start_date, $end_date);
        $data['monthly'] = $reports->getMonthlySalesData(date('Y', strtotime($start_date)));
        break;
        
    case 'projects':
        $data['projects'] = $reports->getProjectPerformance();
        $data['inventory'] = $reports->getInventoryReport();
        break;
        
    case 'customers':
        $data['customers'] = $reports->getCustomerAnalytics();
        break;
        
    case 'leads':
        $data['leads'] = $reports->getLeadConversionReport();
        break;
        
    case 'employees':
        $data['employees'] = $reports->getEmployeePerformance($start_date, $end_date);
        break;
        
    case 'financial':
        $data['financial'] = $reports->getFinancialSummary($start_date, $end_date);
        $data['monthly'] = $reports->getMonthlySalesData(date('Y', strtotime($start_date)));
        break;
        
    default: // overview
        $data['sales_summary'] = $reports->getSalesSummary($start_date, $end_date);
        $data['financial'] = $reports->getFinancialSummary($start_date, $end_date);
        $data['customers'] = $reports->getCustomerAnalytics();
        $data['leads'] = $reports->getLeadConversionReport();
        $data['projects'] = $reports->getProjectPerformance();
        break;
}

// Get projects for filter dropdown
try {
    $pdo = getDBConnection();
    $stmt = $pdo->query("SELECT id, name FROM project ORDER BY name");
    $projects = $stmt->fetchAll();
} catch (Exception $e) {
    $projects = [];
}

// Get alert message if any
$alert = getAlert();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports & Analytics - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .admin-layout {
            display: flex;
            min-height: 100vh;
            background: #f8f9fa;
        }
        
        .admin-sidebar {
            width: 280px;
            background: linear-gradient(135deg, #2c3e50 0%, #34495e 100%);
            color: white;
            padding: 2rem 0;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
        }
        
        .admin-content {
            flex: 1;
            margin-left: 280px;
            padding: 2rem;
        }
        
        .admin-header {
            background: white;
            padding: 1.5rem 2rem;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            margin-bottom: 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .sidebar-brand {
            padding: 0 2rem;
            margin-bottom: 2rem;
            text-align: center;
        }
        
        .sidebar-brand h2 {
            color: white;
            margin: 0;
            font-size: 1.5rem;
        }
        
        .sidebar-nav {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        
        .sidebar-nav li {
            margin-bottom: 0.5rem;
        }
        
        .sidebar-nav a {
            display: flex;
            align-items: center;
            padding: 1rem 2rem;
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            transition: all 0.3s ease;
        }
        
        .sidebar-nav a:hover,
        .sidebar-nav a.active {
            background: rgba(255,255,255,0.1);
            color: white;
            border-right: 4px solid #3498db;
        }
        
        .sidebar-nav .icon {
            margin-right: 1rem;
            font-size: 1.2rem;
        }
        
        .report-tabs {
            display: flex;
            gap: 1rem;
            margin-bottom: 2rem;
            overflow-x: auto;
            padding-bottom: 0.5rem;
        }
        
        .report-tab {
            padding: 1rem 2rem;
            background: white;
            border: none;
            border-radius: 10px;
            color: #666;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            white-space: nowrap;
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
        }
        
        .report-tab.active {
            background: #3498db;
            color: white;
        }
        
        .report-filters {
            background: white;
            padding: 2rem;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            margin-bottom: 2rem;
        }
        
        .filter-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            align-items: end;
        }
        
        .form-group {
            margin-bottom: 0;
        }
        
        .form-label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 600;
            color: #333;
        }
        
        .form-control {
            width: 100%;
            padding: 0.8rem;
            border: 2px solid #e9ecef;
            border-radius: 8px;
            font-size: 1rem;
            transition: border-color 0.3s ease;
        }
        
        .form-control:focus {
            outline: none;
            border-color: #3498db;
            box-shadow: 0 0 0 3px rgba(52,152,219,0.1);
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 2rem;
            margin-bottom: 3rem;
        }
        
        .stat-card {
            background: white;
            padding: 2rem;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            text-align: center;
            position: relative;
            overflow: hidden;
        }
        
        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: var(--accent-color, #3498db);
        }
        
        .stat-card.revenue::before { background: #27ae60; }
        .stat-card.sales::before { background: #3498db; }
        .stat-card.customers::before { background: #e74c3c; }
        .stat-card.leads::before { background: #f39c12; }
        .stat-card.commission::before { background: #9b59b6; }
        
        .stat-number {
            font-size: 2.5rem;
            font-weight: bold;
            color: #2c3e50;
            margin-bottom: 0.5rem;
        }
        
        .stat-label {
            color: #666;
            font-size: 1.1rem;
            margin-bottom: 1rem;
        }
        
        .stat-change {
            font-size: 0.9rem;
            padding: 0.3rem 0.8rem;
            border-radius: 20px;
            font-weight: 600;
        }
        
        .stat-change.positive {
            background: #d4edda;
            color: #155724;
        }
        
        .stat-change.negative {
            background: #f8d7da;
            color: #721c24;
        }
        
        .chart-container {
            background: white;
            padding: 2rem;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            margin-bottom: 2rem;
        }
        
        .chart-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
        }
        
        .chart-title {
            font-size: 1.3rem;
            font-weight: 600;
            color: #2c3e50;
            margin: 0;
        }
        
        .chart-canvas {
            position: relative;
            height: 400px;
        }
        
        .data-table {
            background: white;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        
        .table-header {
            padding: 2rem;
            border-bottom: 1px solid #e9ecef;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .table-title {
            font-size: 1.3rem;
            font-weight: 600;
            color: #2c3e50;
            margin: 0;
        }
        
        .table-actions {
            display: flex;
            gap: 1rem;
        }
        
        .table-container {
            overflow-x: auto;
        }
        
        .admin-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .admin-table th,
        .admin-table td {
            padding: 1rem;
            text-align: left;
            border-bottom: 1px solid #e9ecef;
        }
        
        .admin-table th {
            background: #f8f9fa;
            font-weight: 600;
            color: #2c3e50;
        }
        
        .admin-table tr:hover {
            background: #f8f9fa;
        }
        
        .export-buttons {
            display: flex;
            gap: 1rem;
            margin-bottom: 2rem;
        }
        
        .btn-export {
            padding: 0.8rem 1.5rem;
            background: #27ae60;
            color: white;
            border: none;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        
        .btn-export:hover {
            background: #219a52;
            transform: translateY(-2px);
        }
        
        .report-grid {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 2rem;
            margin-bottom: 2rem;
        }
        
        @media (max-width: 768px) {
            .admin-sidebar {
                transform: translateX(-100%);
                transition: transform 0.3s ease;
            }
            
            .admin-sidebar.active {
                transform: translateX(0);
            }
            
            .admin-content {
                margin-left: 0;
            }
            
            .report-grid {
                grid-template-columns: 1fr;
            }
            
            .filter-row {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="admin-layout">
        <!-- Sidebar -->
        <aside class="admin-sidebar">
            <div class="sidebar-brand">
                <h2>PPS Admin</h2>
            </div>
            <ul class="sidebar-nav">
                <li><a href="dashboard.php"><span class="icon">📊</span> Dashboard</a></li>
                <li><a href="projects.php"><span class="icon">🏗️</span> Projects</a></li>
                <li><a href="plots.php"><span class="icon">🏞️</span> Land Plots</a></li>
                <li><a href="customers.php"><span class="icon">👥</span> Customers</a></li>
                <li><a href="leads.php"><span class="icon">🎯</span> Leads</a></li>
                <li><a href="employees.php"><span class="icon">👨‍💼</span> Employees</a></li>
                <li><a href="sales.php"><span class="icon">💰</span> Sales</a></li>
                <li><a href="media.php"><span class="icon">📁</span> Media</a></li>
                <li><a href="reports.php" class="active"><span class="icon">📈</span> Reports</a></li>
                <li><a href="settings.php"><span class="icon">⚙️</span> Settings</a></li>
                <li><a href="../logout.php"><span class="icon">🚪</span> Logout</a></li>
            </ul>
        </aside>

        <!-- Main Content -->
        <main class="admin-content">
            <!-- Header -->
            <div class="admin-header">
                <h1>Reports & Analytics</h1>
                <div>
                    <button onclick="window.print()" class="btn btn-secondary">Print Report</button>
                </div>
            </div>

            <!-- Alert Messages -->
            <?php if ($alert): ?>
            <div class="alert alert-<?php echo $alert['type']; ?>">
                <?php echo htmlspecialchars($alert['message']); ?>
            </div>
            <?php endif; ?>

            <!-- Report Tabs -->
            <div class="report-tabs">
                <button class="report-tab <?php echo $report_type === 'overview' ? 'active' : ''; ?>" onclick="switchReport('overview')">
                    📊 Overview
                </button>
                <button class="report-tab <?php echo $report_type === 'sales' ? 'active' : ''; ?>" onclick="switchReport('sales')">
                    💰 Sales
                </button>
                <button class="report-tab <?php echo $report_type === 'projects' ? 'active' : ''; ?>" onclick="switchReport('projects')">
                    🏗️ Projects
                </button>
                <button class="report-tab <?php echo $report_type === 'customers' ? 'active' : ''; ?>" onclick="switchReport('customers')">
                    👥 Customers
                </button>
                <button class="report-tab <?php echo $report_type === 'leads' ? 'active' : ''; ?>" onclick="switchReport('leads')">
                    🎯 Leads
                </button>
                <button class="report-tab <?php echo $report_type === 'employees' ? 'active' : ''; ?>" onclick="switchReport('employees')">
                    👨‍💼 Employees
                </button>
                <button class="report-tab <?php echo $report_type === 'financial' ? 'active' : ''; ?>" onclick="switchReport('financial')">
                    💳 Financial
                </button>
            </div>

            <!-- Report Filters -->
            <div class="report-filters">
                <form method="GET" action="reports.php">
                    <input type="hidden" name="type" value="<?php echo $report_type; ?>">
                    <div class="filter-row">
                        <div class="form-group">
                            <label for="start_date" class="form-label">Start Date</label>
                            <input type="date" id="start_date" name="start_date" class="form-control" value="<?php echo $start_date; ?>">
                        </div>
                        <div class="form-group">
                            <label for="end_date" class="form-label">End Date</label>
                            <input type="date" id="end_date" name="end_date" class="form-control" value="<?php echo $end_date; ?>">
                        </div>
                        <?php if (in_array($report_type, ['sales', 'employees'])): ?>
                        <div class="form-group">
                            <label for="project_id" class="form-label">Project</label>
                            <select id="project_id" name="project_id" class="form-control">
                                <option value="">All Projects</option>
                                <?php foreach ($projects as $project): ?>
                                <option value="<?php echo $project['id']; ?>" <?php echo $project_id == $project['id'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($project['name']); ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <?php endif; ?>
                        <div class="form-group">
                            <button type="submit" class="btn">Apply Filters</button>
                        </div>
                    </div>
                </form>
            </div>

            <!-- Report Content -->
            <?php if ($report_type === 'overview'): ?>
                <!-- Overview Dashboard -->
                <div class="stats-grid">
                    <div class="stat-card revenue">
                        <div class="stat-number"><?php echo formatPrice($data['financial']['total_revenue']); ?></div>
                        <div class="stat-label">Total Revenue</div>
                    </div>
                    <div class="stat-card sales">
                        <div class="stat-number"><?php echo $data['sales_summary']['total_sales']; ?></div>
                        <div class="stat-label">Total Sales</div>
                    </div>
                    <div class="stat-card customers">
                        <div class="stat-number"><?php echo $data['customers']['stats']['total_customers']; ?></div>
                        <div class="stat-label">Total Customers</div>
                    </div>
                    <div class="stat-card leads">
                        <div class="stat-number"><?php echo $data['leads']['stats']['total_leads']; ?></div>
                        <div class="stat-label">Total Leads</div>
                    </div>
                </div>

                <div class="report-grid">
                    <!-- Top Projects -->
                    <div class="data-table">
                        <div class="table-header">
                            <h3 class="table-title">Top Performing Projects</h3>
                        </div>
                        <div class="table-container">
                            <table class="admin-table">
                                <thead>
                                    <tr>
                                        <th>Project</th>
                                        <th>Sales</th>
                                        <th>Revenue</th>
                                        <th>Sales Rate</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach (array_slice($data['projects'], 0, 5) as $project): ?>
                                    <tr>
                                        <td><strong><?php echo htmlspecialchars($project['name']); ?></strong></td>
                                        <td><?php echo $project['total_sales']; ?></td>
                                        <td><?php echo formatPrice($project['total_revenue']); ?></td>
                                        <td><?php echo number_format($project['sales_rate'], 1); ?>%</td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <!-- Lead Sources -->
                    <div class="chart-container">
                        <div class="chart-header">
                            <h3 class="chart-title">Lead Sources</h3>
                        </div>
                        <div class="chart-canvas">
                            <canvas id="leadSourcesChart"></canvas>
                        </div>
                    </div>
                </div>

            <?php elseif ($report_type === 'sales'): ?>
                <!-- Sales Report -->
                <div class="stats-grid">
                    <div class="stat-card revenue">
                        <div class="stat-number"><?php echo formatPrice($data['summary']['total_revenue']); ?></div>
                        <div class="stat-label">Total Revenue</div>
                    </div>
                    <div class="stat-card sales">
                        <div class="stat-number"><?php echo $data['summary']['total_sales']; ?></div>
                        <div class="stat-label">Total Sales</div>
                    </div>
                    <div class="stat-card commission">
                        <div class="stat-number"><?php echo formatPrice($data['summary']['total_commission']); ?></div>
                        <div class="stat-label">Total Commission</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-number"><?php echo formatPrice($data['summary']['avg_sale_price']); ?></div>
                        <div class="stat-label">Average Sale Price</div>
                    </div>
                </div>

                <div class="export-buttons">
                    <a href="?type=sales&export=sales&start_date=<?php echo $start_date; ?>&end_date=<?php echo $end_date; ?>&project_id=<?php echo $project_id; ?>" class="btn-export">
                        📊 Export Sales Data
                    </a>
                </div>

                <div class="chart-container">
                    <div class="chart-header">
                        <h3 class="chart-title">Monthly Sales Trend</h3>
                    </div>
                    <div class="chart-canvas">
                        <canvas id="monthlySalesChart"></canvas>
                    </div>
                </div>

                <div class="data-table">
                    <div class="table-header">
                        <h3 class="table-title">Recent Sales</h3>
                    </div>
                    <div class="table-container">
                        <table class="admin-table">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Plot</th>
                                    <th>Project</th>
                                    <th>Customer</th>
                                    <th>Employee</th>
                                    <th>Price</th>
                                    <th>Commission</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach (array_slice($data['sales'], 0, 20) as $sale): ?>
                                <tr>
                                    <td><?php echo formatDate($sale['created_at']); ?></td>
                                    <td><?php echo htmlspecialchars($sale['plot_number']); ?></td>
                                    <td><?php echo htmlspecialchars($sale['project_name']); ?></td>
                                    <td><?php echo htmlspecialchars($sale['customer_name']); ?></td>
                                    <td><?php echo htmlspecialchars($sale['employee_name'] ?: 'N/A'); ?></td>
                                    <td><?php echo formatPrice($sale['sale_price']); ?></td>
                                    <td><?php echo formatPrice($sale['commission']); ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

            <?php elseif ($report_type === 'projects'): ?>
                <!-- Project Performance Report -->
                <div class="export-buttons">
                    <a href="?type=projects&export=projects" class="btn-export">
                        📊 Export Project Data
                    </a>
                </div>

                <div class="chart-container">
                    <div class="chart-header">
                        <h3 class="chart-title">Project Sales Performance</h3>
                    </div>
                    <div class="chart-canvas">
                        <canvas id="projectPerformanceChart"></canvas>
                    </div>
                </div>

                <div class="data-table">
                    <div class="table-header">
                        <h3 class="table-title">Project Performance Details</h3>
                    </div>
                    <div class="table-container">
                        <table class="admin-table">
                            <thead>
                                <tr>
                                    <th>Project</th>
                                    <th>Location</th>
                                    <th>Status</th>
                                    <th>Total Plots</th>
                                    <th>Available</th>
                                    <th>Sold</th>
                                    <th>Sales Rate</th>
                                    <th>Revenue</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($data['projects'] as $project): ?>
                                <tr>
                                    <td><strong><?php echo htmlspecialchars($project['name']); ?></strong></td>
                                    <td><?php echo htmlspecialchars($project['location']); ?></td>
                                    <td><span class="status-badge status-<?php echo $project['status']; ?>"><?php echo ucfirst($project['status']); ?></span></td>
                                    <td><?php echo $project['actual_plots']; ?></td>
                                    <td><?php echo $project['available_plots']; ?></td>
                                    <td><?php echo $project['sold_plots']; ?></td>
                                    <td><?php echo number_format($project['sales_rate'], 1); ?>%</td>
                                    <td><?php echo formatPrice($project['total_revenue']); ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

            <?php elseif ($report_type === 'customers'): ?>
                <!-- Customer Analytics -->
                <div class="stats-grid">
                    <div class="stat-card customers">
                        <div class="stat-number"><?php echo $data['customers']['stats']['total_customers']; ?></div>
                        <div class="stat-label">Total Customers</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-number"><?php echo $data['customers']['stats']['new_customers_30d']; ?></div>
                        <div class="stat-label">New (30 days)</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-number"><?php echo $data['customers']['stats']['new_customers_7d']; ?></div>
                        <div class="stat-label">New (7 days)</div>
                    </div>
                </div>

                <div class="export-buttons">
                    <a href="?type=customers&export=customers" class="btn-export">
                        📊 Export Customer Data
                    </a>
                </div>

                <div class="data-table">
                    <div class="table-header">
                        <h3 class="table-title">Top Customers</h3>
                    </div>
                    <div class="table-container">
                        <table class="admin-table">
                            <thead>
                                <tr>
                                    <th>Customer</th>
                                    <th>Email</th>
                                    <th>Phone</th>
                                    <th>Purchases</th>
                                    <th>Total Spent</th>
                                    <th>Avg Purchase</th>
                                    <th>Last Purchase</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($data['customers']['top_customers'] as $customer): ?>
                                <tr>
                                    <td><strong><?php echo htmlspecialchars($customer['name']); ?></strong></td>
                                    <td><?php echo htmlspecialchars($customer['email']); ?></td>
                                    <td><?php echo htmlspecialchars($customer['phone']); ?></td>
                                    <td><?php echo $customer['total_purchases']; ?></td>
                                    <td><?php echo formatPrice($customer['total_spent']); ?></td>
                                    <td><?php echo formatPrice($customer['avg_purchase']); ?></td>
                                    <td><?php echo formatDate($customer['last_purchase']); ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

            <?php elseif ($report_type === 'leads'): ?>
                <!-- Lead Conversion Report -->
                <div class="stats-grid">
                    <div class="stat-card leads">
                        <div class="stat-number"><?php echo $data['leads']['stats']['total_leads']; ?></div>
                        <div class="stat-label">Total Leads</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-number"><?php echo $data['leads']['stats']['new_leads']; ?></div>
                        <div class="stat-label">New Leads</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-number"><?php echo $data['leads']['stats']['converted_leads']; ?></div>
                        <div class="stat-label">Converted</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-number"><?php echo number_format($data['leads']['stats']['conversion_rate'], 1); ?>%</div>
                        <div class="stat-label">Conversion Rate</div>
                    </div>
                </div>

                <div class="report-grid">
                    <div class="chart-container">
                        <div class="chart-header">
                            <h3 class="chart-title">Lead Sources</h3>
                        </div>
                        <div class="chart-canvas">
                            <canvas id="leadSourcesChart"></canvas>
                        </div>
                    </div>

                    <div class="data-table">
                        <div class="table-header">
                            <h3 class="table-title">Source Performance</h3>
                        </div>
                        <div class="table-container">
                            <table class="admin-table">
                                <thead>
                                    <tr>
                                        <th>Source</th>
                                        <th>Leads</th>
                                        <th>Converted</th>
                                        <th>Rate</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($data['leads']['sources'] as $source): ?>
                                    <tr>
                                        <td><strong><?php echo htmlspecialchars($source['source']); ?></strong></td>
                                        <td><?php echo $source['count']; ?></td>
                                        <td><?php echo $source['converted']; ?></td>
                                        <td><?php echo number_format($source['conversion_rate'], 1); ?>%</td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            <?php elseif ($report_type === 'employees'): ?>
                <!-- Employee Performance Report -->
                <div class="data-table">
                    <div class="table-header">
                        <h3 class="table-title">Employee Performance</h3>
                    </div>
                    <div class="table-container">
                        <table class="admin-table">
                            <thead>
                                <tr>
                                    <th>Employee</th>
                                    <th>Position</th>
                                    <th>Department</th>
                                    <th>Sales</th>
                                    <th>Revenue</th>
                                    <th>Commission</th>
                                    <th>Avg Sale</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($data['employees'] as $employee): ?>
                                <tr>
                                    <td><strong><?php echo htmlspecialchars($employee['name']); ?></strong></td>
                                    <td><?php echo htmlspecialchars($employee['position']); ?></td>
                                    <td><?php echo htmlspecialchars($employee['department']); ?></td>
                                    <td><?php echo $employee['total_sales']; ?></td>
                                    <td><?php echo formatPrice($employee['total_revenue']); ?></td>
                                    <td><?php echo formatPrice($employee['total_commission']); ?></td>
                                    <td><?php echo formatPrice($employee['avg_sale_price']); ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

            <?php elseif ($report_type === 'financial'): ?>
                <!-- Financial Report -->
                <div class="stats-grid">
                    <div class="stat-card revenue">
                        <div class="stat-number"><?php echo formatPrice($data['financial']['total_revenue']); ?></div>
                        <div class="stat-label">Total Revenue</div>
                    </div>
                    <div class="stat-card commission">
                        <div class="stat-number"><?php echo formatPrice($data['financial']['total_commission']); ?></div>
                        <div class="stat-label">Total Commission</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-number"><?php echo formatPrice($data['financial']['net_revenue']); ?></div>
                        <div class="stat-label">Net Revenue</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-number"><?php echo formatPrice($data['financial']['avg_transaction']); ?></div>
                        <div class="stat-label">Avg Transaction</div>
                    </div>
                </div>

                <div class="chart-container">
                    <div class="chart-header">
                        <h3 class="chart-title">Monthly Revenue Trend</h3>
                    </div>
                    <div class="chart-canvas">
                        <canvas id="monthlyRevenueChart"></canvas>
                    </div>
                </div>
            <?php endif; ?>
        </main>
    </div>

    <script src="../assets/js/main.js"></script>
    <script>
        function switchReport(type) {
            const params = new URLSearchParams(window.location.search);
            params.set('type', type);
            window.location.href = 'reports.php?' + params.toString();
        }
        
        // Chart configurations
        const chartOptions = {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                },
                title: {
                    display: false
                }
            }
        };
        
        // Initialize charts based on report type
        document.addEventListener('DOMContentLoaded', function() {
            const reportType = '<?php echo $report_type; ?>';
            
            if (reportType === 'overview' || reportType === 'leads') {
                // Lead Sources Chart
                const leadSourcesCtx = document.getElementById('leadSourcesChart');
                if (leadSourcesCtx) {
                    new Chart(leadSourcesCtx, {
                        type: 'doughnut',
                        data: {
                            labels: <?php echo json_encode(array_column($data['leads']['sources'] ?? [], 'source')); ?>,
                            datasets: [{
                                data: <?php echo json_encode(array_column($data['leads']['sources'] ?? [], 'count')); ?>,
                                backgroundColor: [
                                    'rgba(231, 76, 60, 0.8)',
                                    'rgba(52, 152, 219, 0.8)',
                                    'rgba(46, 204, 113, 0.8)',
                                    'rgba(241, 196, 15, 0.8)',
                                    'rgba(155, 89, 182, 0.8)'
                                ]
                            }]
                        },
                        options: chartOptions
                    });
                }
            }
            
            if (reportType === 'sales') {
                // Monthly Sales Chart
                const monthlySalesCtx = document.getElementById('monthlySalesChart');
                if (monthlySalesCtx) {
                    const monthlyData = <?php echo json_encode($data['monthly'] ?? []); ?>;
                    new Chart(monthlySalesCtx, {
                        type: 'line',
                        data: {
                            labels: monthlyData.map(item => {
                                const date = new Date(2023, item.month - 1, 1);
                                return date.toLocaleDateString('en-US', { month: 'short' });
                            }),
                            datasets: [{
                                label: 'Sales Count',
                                data: monthlyData.map(item => item.sales_count),
                                borderColor: 'rgba(52, 152, 219, 1)',
                                backgroundColor: 'rgba(52, 152, 219, 0.1)',
                                tension: 0.4
                            }, {
                                label: 'Revenue',
                                data: monthlyData.map(item => item.revenue),
                                borderColor: 'rgba(46, 204, 113, 1)',
                                backgroundColor: 'rgba(46, 204, 113, 0.1)',
                                tension: 0.4,
                                yAxisID: 'y1'
                            }]
                        },
                        options: {
                            ...chartOptions,
                            scales: {
                                y: {
                                    type: 'linear',
                                    display: true,
                                    position: 'left',
                                },
                                y1: {
                                    type: 'linear',
                                    display: true,
                                    position: 'right',
                                    grid: {
                                        drawOnChartArea: false,
                                    },
                                }
                            }
                        }
                    });
                }
            }
            
            if (reportType === 'projects') {
                // Project Performance Chart
                const projectPerformanceCtx = document.getElementById('projectPerformanceChart');
                if (projectPerformanceCtx) {
                    const projectData = <?php echo json_encode($data['projects'] ?? []); ?>;
                    new Chart(projectPerformanceCtx, {
                        type: 'bar',
                        data: {
                            labels: projectData.map(item => item.name),
                            datasets: [{
                                label: 'Sales Rate (%)',
                                data: projectData.map(item => item.sales_rate),
                                backgroundColor: 'rgba(155, 89, 182, 0.8)',
                                borderColor: 'rgba(155, 89, 182, 1)',
                                borderWidth: 1
                            }]
                        },
                        options: {
                            ...chartOptions,
                            scales: {
                                y: {
                                    beginAtZero: true,
                                    max: 100
                                }
                            }
                        }
                    });
                }
            }
            
            if (reportType === 'financial') {
                // Monthly Revenue Chart
                const monthlyRevenueCtx = document.getElementById('monthlyRevenueChart');
                if (monthlyRevenueCtx) {
                    const monthlyData = <?php echo json_encode($data['monthly'] ?? []); ?>;
                    new Chart(monthlyRevenueCtx, {
                        type: 'bar',
                        data: {
                            labels: monthlyData.map(item => {
                                const date = new Date(2023, item.month - 1, 1);
                                return date.toLocaleDateString('en-US', { month: 'short' });
                            }),
                            datasets: [{
                                label: 'Revenue',
                                data: monthlyData.map(item => item.revenue),
                                backgroundColor: 'rgba(46, 204, 113, 0.8)',
                                borderColor: 'rgba(46, 204, 113, 1)',
                                borderWidth: 1
                            }]
                        },
                        options: {
                            ...chartOptions,
                            scales: {
                                y: {
                                    beginAtZero: true
                                }
                            }
                        }
                    });
                }
            }
        });
    </script>
</body>
</html>

