<?php
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/../includes/plot.php';
require_once __DIR__ . '/../includes/project.php';

$pdo = getDBConnection();
$plotManager = new Plot($pdo);
$projectManager = new Project($pdo);
$plots = $plotManager->getAllPlots();
$projects = $projectManager->getAllProjects();

if (!function_exists('formatPrice')) {
    function formatPrice($price, $currency = 'LAK') {
        $symbol = ($currency == 'THB') ? '฿' : '₭';
        return number_format($price) . ' ' . $symbol;
    }
}
?>

<div class="page-header">
    <h1>ຈັດການຕອນດິນ</h1>
    <button class="btn-primary" onclick="openAddModal()">+ ເພີ່ມຕອນດິນ</button>
</div>

<div class="content-card">
    <div class="table-responsive-wrapper">
        <table>
            <thead><tr><th>ລຳດັບ</th><th>ເລກຕອນດິນ</th><th>ໂຄງການ</th><th>ລາຄາຄຳນວນ</th><th>ສະຖານະ</th><th>ການດຳເນີນການ</th></tr></thead>
            <tbody id="plots-table-body">
                <?php foreach ($plots as $plot): ?>
                    <tr id="plot-row-<?php echo $plot['id']; ?>">
                        <td><?php echo $plot['id']; ?></td>
                        <td><?php echo htmlspecialchars($plot['plot_number']); ?></td>
                        <td><?php echo htmlspecialchars($plot['project_name']); ?></td>
                        <td><?php echo (isset($plot['calculated_price']) && $plot['currency']) ? formatPrice($plot['calculated_price'], $plot['currency']) : 'N/A'; ?></td>
                        <td><?php echo ucfirst(htmlspecialchars($plot['status'])); ?></td>
                        <td>
                            <button class="btn-edit" onclick="openEditModal(<?php echo $plot['id']; ?>)">ແກ້ໄຂ</button>
                            <button class="btn-danger" onclick="deletePlot(<?php echo $plot['id']; ?>)">ລົບ</button>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<div id="addPlotModal" class="modal">
    <div class="modal-content">
        <div class="modal-header"><h2>ເພີ່ມຕອນດິນໃໝ່</h2><span class="close" onclick="closeModal('addPlotModal')">&times;</span></div>
        <div class="modal-body"><form id="addPlotForm">
            <div class="form-group"><label for="add_project_id">ໂຄງການ</label><select id="add_project_id" name="project_id" required><option value="">-- ເລືອກໂຄງການ --</option><?php foreach ($projects as $project): ?><option value="<?php echo $project['id']; ?>"><?php echo htmlspecialchars($project['name']); ?></option><?php endforeach; ?></select></div>
            <div class="form-group"><label for="add_zone_id">ໂຊນລາຄາ</label><select id="add_zone_id" name="zone_id" required disabled><option value="">-- ກະລຸນາເລືອກໂຄງການກ່ອນ --</option></select></div>
            <div class="form-group"><label for="add_plot_number">ເລກຕອນດິນ</label><input type="text" id="add_plot_number" name="plot_number" required></div>
            <div class="form-group"><label for="add_area">ເນື້ອທີ່ (ຕາແມັດ)</label><input type="number" step="0.01" id="add_area" name="area" required></div>
            <button type="submit" class="btn-primary">ບັນທຶກຕອນດິນ</button>
        </form></div>
    </div>
</div>

<div id="editPlotModal" class="modal">
    <div class="modal-content">
        <div class="modal-header"><h2>ແກ້ໄຂຕອນດິນ</h2><span class="close" onclick="closeModal('editPlotModal')">&times;</span></div>
        <div class="modal-body"><form id="editPlotForm">
            <input type="hidden" id="edit_plot_id" name="plot_id">
            <div class="form-group"><label for="edit_project_id">ໂຄງການ</label><select id="edit_project_id" name="project_id" required><?php foreach ($projects as $project): ?><option value="<?php echo $project['id']; ?>"><?php echo htmlspecialchars($project['name']); ?></option><?php endforeach; ?></select></div>
            <div class="form-group"><label for="edit_zone_id">ໂຊນລາຄາ</label><select id="edit_zone_id" name="zone_id" required><option value="">-- ກະລຸນາເລືອກໂຄງການກ່ອນ --</option></select></div>
            <div class="form-group"><label for="edit_plot_number">ເລກຕອນດິນ</label><input type="text" id="edit_plot_number" name="plot_number" required></div>
            <div class="form-group"><label for="edit_area">ເນື້ອທີ່ (ຕາແມັດ)</label><input type="number" step="0.01" id="edit_area" name="area" required></div>
            <div class="form-group"><label for="edit_status">ສະຖານະ</label><select id="edit_status" name="status" required><option value="available">ວ່າງ</option><option value="reserved">ຈອງແລ້ວ</option><option value="sold">ຂາຍແລ້ວ</option></select></div>
            <button type="submit" class="btn-primary">ອັບເດດຕອນດິນ</button>
        </form></div>
    </div>
</div>

<script>
// =================================================================
// SCRIPT ສະບັບແກ້ໄຂໂຄງສ້າງ Scope ທີ່ຖືກຕ້ອງ
// =================================================================

// --- ພາກສ່ວນຟັງຊັນທີ່ເປັນ Global (ເພື່ອໃຫ້ onclick ແລະ ຟັງຊັນອື່ນເອີ້ນໃຊ້ໄດ້) ---

function formatPrice(price, currency = 'LAK') {
    const symbols = { LAK: '₭', THB: '฿' };
    const symbol = symbols[currency] || currency;
    return new Intl.NumberFormat('en-US').format(price) + ' ' + symbol;
}

function fetchZonesForProject(projectId, zoneSelectElement, selectedZoneId = null) {
    zoneSelectElement.innerHTML = '<option>ກຳລັງໂຫຼດ...</option>';
    zoneSelectElement.disabled = true;
    if (!projectId) {
        zoneSelectElement.innerHTML = '<option value="">-- ກະລຸນາເລືອກໂຄງການກ່ອນ --</option>';
        return;
    }
    fetch(`../api/admin/zones_api.php?action=get_by_project&project_id=${projectId}`)
        .then(response => response.json())
        .then(data => {
            zoneSelectElement.innerHTML = '';
            if (data.success && data.data.length > 0) {
                zoneSelectElement.disabled = false;
                zoneSelectElement.innerHTML = '<option value="">-- ເລືອກໂຊນ --</option>';
                data.data.forEach(zone => {
                    const option = document.createElement('option');
                    option.value = zone.id;
                    option.textContent = `${zone.zone_name} (${formatPrice(zone.price_per_sqm, zone.currency)} / ຕາແມັດ)`;
                    if (selectedZoneId && selectedZoneId == zone.id) {
                        option.selected = true;
                    }
                    zoneSelectElement.appendChild(option);
                });
            } else {
                zoneSelectElement.innerHTML = '<option value="">-- ໂຄງການນີ້ຍັງບໍ່ມີໂຊນ --</option>';
            }
        })
        .catch(error => {
            console.error("Error fetching zones:", error);
            zoneSelectElement.innerHTML = '<option value="">-- ເກີດຂໍ້ຜິດພາດໃນການໂຫຼດໂຊນ --</option>';
        });
}

function openAddModal() {
    document.getElementById('addPlotForm').reset();
    document.getElementById('add_zone_id').innerHTML = '<option value="">-- ກະລຸນາເລືອກໂຄງການກ່ອນ --</option>';
    document.getElementById('add_zone_id').disabled = true;
    document.getElementById('addPlotModal').style.display = 'flex';
}

function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

function openEditModal(id) {
    fetch(`../api/admin/plots_api.php?action=get&id=${id}`)
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            const plot = data.data;
            document.getElementById('edit_plot_id').value = plot.id;
            document.getElementById('edit_project_id').value = plot.project_id;
            document.getElementById('edit_plot_number').value = plot.plot_number;
            document.getElementById('edit_area').value = plot.area;
            document.getElementById('edit_status').value = plot.status;
            
            const zoneSelect = document.getElementById('edit_zone_id');
            fetchZonesForProject(plot.project_id, zoneSelect, plot.zone_id);
            
            document.getElementById('editPlotModal').style.display = 'flex';
        } else {
            Swal.fire({ title: 'ຜິດພາດ!', text: data.message, icon: 'error' });
        }
    });
}

function deletePlot(id) {
    Swal.fire({
        title: 'ທ່ານແນ່ໃຈບໍ່?', text: "ທ່ານຕ້ອງການລົບຕອນດິນນີ້ແທ້ບໍ?", icon: 'warning',
        showCancelButton: true, confirmButtonText: 'ແມ່ນ, ລົບເລີຍ!', cancelButtonText: 'ຍົກເລີກ'
    }).then((result) => {
        if (result.isConfirmed) {
            const formData = new FormData();
            formData.append('plot_id', id);
            fetch('../api/admin/plots_api.php?action=delete', { method: 'POST', body: formData })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                     Swal.fire('ລົບສຳເລັດ!', data.message, 'success');
                     document.getElementById(`plot-row-${id}`).remove();
                } else { Swal.fire({ title: 'ຜິດພາດ!', text: data.message, icon: 'error' }); }
            }).catch(err => {
                console.error('Delete Error:', err);
                Swal.fire('ຜິດພາດ!', 'ເກີດບັນຫາໃນການລົບ.', 'error');
            });
        }
    });
}

// --- ພາກສ່ວນທີ່ຕ້ອງເຮັດວຽກຫຼັງຈາກໜ້າเว็บໂຫຼດແລ້ວ ---
document.addEventListener('DOMContentLoaded', function() {
    
    document.getElementById('add_project_id').addEventListener('change', function() {
        fetchZonesForProject(this.value, document.getElementById('add_zone_id'));
    });

    document.getElementById('edit_project_id').addEventListener('change', function() {
        fetchZonesForProject(this.value, document.getElementById('edit_zone_id'));
    });

    function handleFormResponse(form, url, successMessage) {
        const formData = new FormData(form);
        fetch(url, { method: 'POST', body: formData })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                Swal.fire({ title: 'ສຳເລັດ!', text: successMessage, icon: 'success' })
                .then(() => { window.location.reload(); });
            } else {
                Swal.fire({ title: 'ຜິດພາດ!', text: data.message, icon: 'error' });
            }
        }).catch(err => {
            console.error("Submit Error:", err);
            Swal.fire('ຜິດພາດ!', 'ການສົ່ງຂໍ້ມູນລົ້ມເຫຼວ.', 'error');
        });
    }

    document.getElementById('addPlotForm').addEventListener('submit', function(e) {
        e.preventDefault();
        handleFormResponse(this, '../api/admin/plots_api.php?action=create', 'ເພີ່ມຕອນດິນສຳເລັດ!');
    });

    document.getElementById('editPlotForm').addEventListener('submit', function(e) {
        e.preventDefault();
        handleFormResponse(this, '../api/admin/plots_api.php?action=update', 'ອັບເດດຕອນດິນສຳເລັດ!');
    });
});
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>