<?php
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/../includes/employee.php';

$employee_id = $_GET['id'] ?? 0;
if (!$employee_id) {
    // Redirect or show error if no ID is provided
    redirect('employees.php');
}

$pdo = getDBConnection();
$employeeManager = new Employee($pdo);
$employee = $employeeManager->getEmployeeById($employee_id);

if (!$employee) {
    // Redirect or show error if employee not found
    redirect('employees.php');
}
?>

<div class="page-header">
    <h1>Employee Details: <?php echo htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name']); ?></h1>
    <a href="employees.php" class="btn-secondary">Back to List</a>
</div>

<div class="content-card">
    <form id="personalInfoForm">
        <h3>Personal Information</h3>
        <input type="hidden" name="employee_id" value="<?php echo $employee['id']; ?>">
        <div class="form-row">
            <div class="form-group"><label>First Name</label><input type="text" name="first_name" value="<?php echo htmlspecialchars($employee['first_name']); ?>" required></div>
            <div class="form-group"><label>Last Name</label><input type="text" name="last_name" value="<?php echo htmlspecialchars($employee['last_name']); ?>" required></div>
        </div>
        <div class="form-row">
            <div class="form-group"><label>Phone</label><input type="tel" name="phone" value="<?php echo htmlspecialchars($employee['phone']); ?>"></div>
            <div class="form-group"><label>Email</label><input type="email" name="email" value="<?php echo htmlspecialchars($employee['user_email']); ?>" required></div>
        </div>
        <button type="submit" class="btn-primary">Save Personal Info</button>
    </form>
</div>

<?php if (hasRole('admin')): ?>
<div class="content-card" style="margin-top: 20px;">
    <form id="payrollInfoForm">
        <h3>Employment & Payroll (Admin Only)</h3>
        <input type="hidden" name="employee_id" value="<?php echo $employee['id']; ?>">
        <div class="form-row">
            <div class="form-group"><label>Hire Date</label><input type="date" name="hire_date" value="<?php echo htmlspecialchars($employee['hire_date']); ?>"></div>
            <div class="form-group"><label>Salary</label><input type="number" step="0.01" name="salary" value="<?php echo htmlspecialchars($employee['salary']); ?>"></div>
        </div>
        <div class="form-row">
             <div class="form-group"><label>Department</label><input type="text" name="department" value="<?php echo htmlspecialchars($employee['department']); ?>"></div>
             <div class="form-group"><label>Position</label><input type="text" name="position" value="<?php echo htmlspecialchars($employee['position']); ?>"></div>
        </div>
        <div class="form-group">
            <label>Role</label>
            <select name="role">
                <option value="sales" <?php if($employee['role'] == 'sales') echo 'selected'; ?>>Sales</option>
                <option value="manager" <?php if($employee['role'] == 'manager') echo 'selected'; ?>>Manager</option>
                <option value="content" <?php if($employee['role'] == 'content') echo 'selected'; ?>>Content</option>
                <option value="admin" <?php if($employee['role'] == 'admin') echo 'selected'; ?>>Admin</option>
            </select>
        </div>
        <button type="submit" class="btn-primary">Save Employment Info</button>
    </form>
</div>
<?php endif; ?>

<script>
// Handle Personal Info Form
document.getElementById('personalInfoForm').addEventListener('submit', function(e){
    e.preventDefault();
    const formData = new FormData(this);
    fetch('../api/admin/employees_api.php?action=update', { method: 'POST', body: formData })
    .then(response => response.json())
    .then(data => {
        if(data.success){
            alert(data.message);
        } else {
            alert('Error: ' + data.message);
        }
    });
});

// Handle Payroll Info Form (if it exists)
const payrollForm = document.getElementById('payrollInfoForm');
if (payrollForm) {
    payrollForm.addEventListener('submit', function(e){
        e.preventDefault();
        const formData = new FormData(this);
        fetch('../api/admin/employees_api.php?action=update', { method: 'POST', body: formData })
        .then(response => response.json())
        .then(data => {
            if(data.success){
                alert(data.message);
            } else {
                alert('Error: ' + data.message);
            }
        });
    });
}
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>