<?php
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/../includes/employee.php';

$pdo = getDBConnection();
$employeeManager = new Employee($pdo);
$employees = $employeeManager->getAllEmployees();
?>

<div class="page-header">
    <h1>ຈັດການຂໍ້ມູນພະນັກງານ</h1>
    <button class="btn-primary" onclick="openAddModal()">+ ເພີ່ມພະນັກງານ</button>
</div>

<div class="content-card">
    <table>
        <thead>
            <tr>
                <th>ລະຫັດພະນັກງານ</th>
                <th>ຊື່ ແລະ ນາມສະກຸນ</th>
                <th>ຕຳແໜ່ງ</th>
                <th>ເບີໂທ</th>
                <th>ອີເມວ</th>
                <th>ການດຳເນີນການ</th>
            </tr>
        </thead>
        <tbody id="employee-table-body">
            <?php foreach ($employees as $employee): ?>
                <tr id="employee-row-<?php echo $employee['id']; ?>">
                    <td class="employee-id"><?php echo htmlspecialchars($employee['employee_id']); ?></td>
                    <td class="employee-name"><?php echo htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name']); ?></td>
                    <td class="employee-position"><?php echo htmlspecialchars($employee['position']); ?></td>
                    <td class="employee-phone"><?php echo htmlspecialchars($employee['phone']); ?></td>
                    <td class="employee-email"><?php echo htmlspecialchars($employee['user_email']); ?></td>
                    <td>
                        <a href="employee_details.php?id=<?php echo $employee['id']; ?>" class="btn-edit">ເບິ່ງລາຍລະອຽດ</a>
                        <button class="btn-danger">ລົບ</button>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<div id="addEmployeeModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>ເພີ່ມພະນັກງານໃໝ່</h2>
            <span class="close" onclick="closeModal('addEmployeeModal')">&times;</span>
        </div>
        <div class="modal-body">
            <form id="addEmployeeForm">
                <div class="form-group">
                    <label>ລະຫັດພະນັກງານ</label>
                    <div class="input-group">
                        <span class="input-group-text">PPS</span>
                        <input type="text" name="employee_id_suffix" placeholder="ຕົວຢ່າງ, 036" required>
                    </div>
                </div>
                <div class="form-group"><label>ຊື່</label><input type="text" name="first_name" required></div>
                <div class="form-group"><label>ນາມສະກຸນ</label><input type="text" name="last_name" required></div>
                <div class="form-group"><label>ອີເມວ (ສຳລັບເຂົ້າລະບົບ)</label><input type="email" name="email" required></div>
                <div class="form-group"><label>ເບີໂທ</label><input type="tel" name="phone"></div>
                <div class="form-group"><label>ພະແນກ</label><input type="text" name="department"></div>
                <div class="form-group"><label>ຕຳແໜ່ງ</label><input type="text" name="position"></div>
                <div class="form-group">
                    <label>ສິດທິການໃຊ້ງານ</label>
                    <select name="role">
                        <option value="sales">ພະນັກງານຂາຍ</option>
                        <option value="manager">ຜູ້ຈັດການ</option>
                        <option value="content">ພະນັກງານເນື້ອຫາ</option>
                        <option value="admin">ຜູ້ດູແລລະບົບ</option>
                    </select>
                </div>
                <div class="form-group"><label>ລະຫັດຜ່ານ (ຄ່າເລີ່ມຕົ້ນ: password123)</label><input type="password" name="password" placeholder="ປະໄວ້ຫວ່າງຖ້າຕ້ອງການใช้ค่าເລີ່ມຕົ້ນ"></div>
                <button type="submit" class="btn-primary">ບັນທຶກຂໍ້ມູນພະນັກງານ</button>
            </form>
        </div>
    </div>
</div>

<div id="editEmployeeModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>ແກ້ໄຂຂໍ້ມູນພະນັກງານ</h2>
            <span class="close" onclick="closeModal('editEmployeeModal')">&times;</span>
        </div>
        <div class="modal-body">
            <form id="editEmployeeForm">
                <input type="hidden" name="employee_id" id="edit_employee_id">
                <div class="form-group"><label>ຊື່</label><input type="text" id="edit_first_name" name="first_name" required></div>
                <div class="form-group"><label>ນາມສະກຸນ</label><input type="text" id="edit_last_name" name="last_name" required></div>
                <div class="form-group"><label>ອີເມວ (ສຳລັບເຂົ້າລະບົບ)</label><input type="email" id="edit_email" name="email" required></div>
                <div class="form-group"><label>ເບີໂທ</label><input type="tel" id="edit_phone" name="phone"></div>
                <div class="form-group"><label>ພະແນກ</label><input type="text" id="edit_department" name="department"></div>
                <div class="form-group"><label>ຕຳແໜ່ງ</label><input type="text" id="edit_position" name="position"></div>
                <div class="form-group">
                    <label>ສິດທິການໃຊ້ງານ</label>
                    <select id="edit_role" name="role">
                        <option value="sales">ພະນັກງານຂາຍ</option>
                        <option value="manager">ຜູ້ຈັດການ</option>
                        <option value="content">ພະນັກງານເນື້ອຫາ</option>
                        <option value="admin">ຜູ້ດູແລລະບົບ</option>
                    </select>
                </div>
                <button type="submit" class="btn-primary">ອັບເດດຂໍ້ມູນພະນັກງານ</button>
            </form>
        </div>
    </div>
</div>

<script>
function openAddModal() { document.getElementById('addEmployeeModal').style.display = 'flex'; }
function closeModal(modalId) { document.getElementById(modalId).style.display = 'none'; }

function openEditModal(id) {
    fetch(`../api/admin/employees_api.php?action=get&id=${id}`)
    .then(response => response.json())
    .then(data => {
        if(data.success) {
            document.getElementById('edit_employee_id').value = data.data.id;
            document.getElementById('edit_first_name').value = data.data.first_name;
            document.getElementById('edit_last_name').value = data.data.last_name;
            document.getElementById('edit_email').value = data.data.user_email;
            document.getElementById('edit_phone').value = data.data.phone;
            document.getElementById('edit_department').value = data.data.department;
            document.getElementById('edit_position').value = data.data.position;
            document.getElementById('edit_role').value = data.data.role;
            document.getElementById('editEmployeeModal').style.display = 'flex';
        } else {
            alert('ຜິດພາດ: ' + data.message);
        }
    });
}

document.getElementById('addEmployeeForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const formData = new FormData(this);
    fetch('../api/admin/employees_api.php?action=create', { method: 'POST', body: formData })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert(data.message);
            window.location.reload();
        } else {
            alert('ຜິດພາດ: ' + data.message);
        }
    });
});

document.getElementById('editEmployeeForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const formData = new FormData(this);
    fetch('../api/admin/employees_api.php?action=update', { method: 'POST', body: formData })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert(data.message);
            const row = document.getElementById(`employee-row-${data.data.id}`);
            row.querySelector('.employee-name').textContent = data.data.first_name + ' ' + data.data.last_name;
            row.querySelector('.employee-position').textContent = data.data.position;
            row.querySelector('.employee-phone').textContent = data.data.phone;
            row.querySelector('.employee-email').textContent = data.data.user_email;
            closeModal('editEmployeeModal');
        } else {
            alert('ຜິດພາດ: ' + data.message);
        }
    });
});
</script>
<style>.input-group{display:flex;}.input-group-text{padding:0 10px;background:#eee;border:1px solid #ccc;border-right:none;border-radius:5px 0 0 5px;display:flex;align-items:center;}</style>
<?php require_once __DIR__ . '/includes/footer.php'; ?>