<?php
require_once '../config/config.php';
require_once '../includes/upload.php';

// Require admin access
requireRole('admin');

$fileUpload = new FileUpload();
$type = isset($_GET['type']) ? $_GET['type'] : 'image';
$validTypes = ['image', 'video', 'document'];

if (!in_array($type, $validTypes)) {
    $type = 'image';
}

// Get files
$files = $fileUpload->listFiles($type);

// Get alert message if any
$alert = getAlert();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Media Management - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .admin-layout {
            display: flex;
            min-height: 100vh;
            background: #f8f9fa;
        }
        
        .admin-sidebar {
            width: 280px;
            background: linear-gradient(135deg, #2c3e50 0%, #34495e 100%);
            color: white;
            padding: 2rem 0;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
        }
        
        .admin-content {
            flex: 1;
            margin-left: 280px;
            padding: 2rem;
        }
        
        .admin-header {
            background: white;
            padding: 1.5rem 2rem;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            margin-bottom: 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .sidebar-brand {
            padding: 0 2rem;
            margin-bottom: 2rem;
            text-align: center;
        }
        
        .sidebar-brand h2 {
            color: white;
            margin: 0;
            font-size: 1.5rem;
        }
        
        .sidebar-nav {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        
        .sidebar-nav li {
            margin-bottom: 0.5rem;
        }
        
        .sidebar-nav a {
            display: flex;
            align-items: center;
            padding: 1rem 2rem;
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            transition: all 0.3s ease;
        }
        
        .sidebar-nav a:hover,
        .sidebar-nav a.active {
            background: rgba(255,255,255,0.1);
            color: white;
            border-right: 4px solid #3498db;
        }
        
        .sidebar-nav .icon {
            margin-right: 1rem;
            font-size: 1.2rem;
        }
        
        .content-card {
            background: white;
            padding: 2rem;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        }
        
        .media-tabs {
            display: flex;
            gap: 1rem;
            margin-bottom: 2rem;
            border-bottom: 2px solid #e9ecef;
        }
        
        .media-tab {
            padding: 1rem 2rem;
            background: none;
            border: none;
            color: #666;
            font-weight: 600;
            cursor: pointer;
            border-bottom: 3px solid transparent;
            transition: all 0.3s ease;
        }
        
        .media-tab.active {
            color: #2c3e50;
            border-bottom-color: #3498db;
        }
        
        .upload-area {
            border: 2px dashed #ddd;
            border-radius: 15px;
            padding: 3rem;
            text-align: center;
            margin-bottom: 2rem;
            transition: all 0.3s ease;
            cursor: pointer;
        }
        
        .upload-area:hover,
        .upload-area.dragover {
            border-color: #3498db;
            background: #f8f9fa;
        }
        
        .upload-area.uploading {
            border-color: #28a745;
            background: #d4edda;
        }
        
        .upload-icon {
            font-size: 3rem;
            color: #666;
            margin-bottom: 1rem;
        }
        
        .upload-text {
            font-size: 1.2rem;
            color: #666;
            margin-bottom: 1rem;
        }
        
        .upload-hint {
            font-size: 0.9rem;
            color: #999;
        }
        
        .media-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 1.5rem;
            margin-top: 2rem;
        }
        
        .media-item {
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            position: relative;
        }
        
        .media-item:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.15);
        }
        
        .media-preview {
            width: 100%;
            height: 150px;
            object-fit: cover;
            background: #f8f9fa;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #666;
            font-size: 2rem;
        }
        
        .media-info {
            padding: 1rem;
        }
        
        .media-name {
            font-weight: 600;
            margin-bottom: 0.5rem;
            font-size: 0.9rem;
            word-break: break-all;
        }
        
        .media-meta {
            font-size: 0.8rem;
            color: #666;
            margin-bottom: 1rem;
        }
        
        .media-actions {
            display: flex;
            gap: 0.5rem;
        }
        
        .btn-sm {
            padding: 0.5rem 1rem;
            font-size: 0.8rem;
        }
        
        .media-overlay {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.8);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            opacity: 0;
            transition: opacity 0.3s ease;
        }
        
        .media-item:hover .media-overlay {
            opacity: 1;
        }
        
        .upload-progress {
            width: 100%;
            height: 4px;
            background: #e9ecef;
            border-radius: 2px;
            overflow: hidden;
            margin-top: 1rem;
            display: none;
        }
        
        .upload-progress-bar {
            height: 100%;
            background: #28a745;
            width: 0%;
            transition: width 0.3s ease;
        }
        
        .upload-options {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-bottom: 2rem;
            padding: 1rem;
            background: #f8f9fa;
            border-radius: 10px;
        }
        
        .upload-option {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .upload-option input[type="checkbox"] {
            margin: 0;
        }
        
        .upload-option label {
            margin: 0;
            font-size: 0.9rem;
        }
        
        .upload-option input[type="number"] {
            width: 80px;
            padding: 0.3rem;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
    </style>
</head>
<body>
    <div class="admin-layout">
        <!-- Sidebar -->
        <aside class="admin-sidebar">
            <div class="sidebar-brand">
                <h2>PPS Admin</h2>
            </div>
            <ul class="sidebar-nav">
                <li><a href="dashboard.php"><span class="icon">📊</span> Dashboard</a></li>
                <li><a href="projects.php"><span class="icon">🏗️</span> Projects</a></li>
                <li><a href="plots.php"><span class="icon">🏞️</span> Land Plots</a></li>
                <li><a href="customers.php"><span class="icon">👥</span> Customers</a></li>
                <li><a href="leads.php"><span class="icon">🎯</span> Leads</a></li>
                <li><a href="employees.php"><span class="icon">👨‍💼</span> Employees</a></li>
                <li><a href="sales.php"><span class="icon">💰</span> Sales</a></li>
                <li><a href="media.php" class="active"><span class="icon">📁</span> Media</a></li>
                <li><a href="reports.php"><span class="icon">📈</span> Reports</a></li>
                <li><a href="settings.php"><span class="icon">⚙️</span> Settings</a></li>
                <li><a href="../logout.php"><span class="icon">🚪</span> Logout</a></li>
            </ul>
        </aside>

        <!-- Main Content -->
        <main class="admin-content">
            <!-- Header -->
            <div class="admin-header">
                <h1>Media Management</h1>
                <div>
                    <button onclick="clearAll()" class="btn btn-secondary">Clear All</button>
                </div>
            </div>

            <!-- Alert Messages -->
            <?php if ($alert): ?>
            <div class="alert alert-<?php echo $alert['type']; ?>">
                <?php echo htmlspecialchars($alert['message']); ?>
            </div>
            <?php endif; ?>

            <div class="content-card">
                <!-- Media Type Tabs -->
                <div class="media-tabs">
                    <button class="media-tab <?php echo $type === 'image' ? 'active' : ''; ?>" onclick="switchType('image')">
                        📷 Images
                    </button>
                    <button class="media-tab <?php echo $type === 'video' ? 'active' : ''; ?>" onclick="switchType('video')">
                        🎥 Videos
                    </button>
                    <button class="media-tab <?php echo $type === 'document' ? 'active' : ''; ?>" onclick="switchType('document')">
                        📄 Documents
                    </button>
                </div>

                <!-- Upload Area -->
                <div class="upload-area" id="uploadArea" onclick="document.getElementById('fileInput').click()">
                    <div class="upload-icon">📁</div>
                    <div class="upload-text">Click to upload or drag and drop files here</div>
                    <div class="upload-hint">
                        <?php 
                        switch($type) {
                            case 'image':
                                echo 'Supported formats: ' . implode(', ', ALLOWED_IMAGE_TYPES) . ' (Max: ' . (MAX_FILE_SIZE / 1024 / 1024) . 'MB)';
                                break;
                            case 'video':
                                echo 'Supported formats: ' . implode(', ', ALLOWED_VIDEO_TYPES) . ' (Max: ' . (MAX_FILE_SIZE / 1024 / 1024) . 'MB)';
                                break;
                            case 'document':
                                echo 'Supported formats: ' . implode(', ', ALLOWED_DOC_TYPES) . ' (Max: ' . (MAX_FILE_SIZE / 1024 / 1024) . 'MB)';
                                break;
                        }
                        ?>
                    </div>
                    <div class="upload-progress" id="uploadProgress">
                        <div class="upload-progress-bar" id="uploadProgressBar"></div>
                    </div>
                </div>

                <!-- Upload Options (for images) -->
                <?php if ($type === 'image'): ?>
                <div class="upload-options">
                    <div class="upload-option">
                        <input type="checkbox" id="resizeImage" checked>
                        <label for="resizeImage">Resize image</label>
                        <input type="number" id="maxWidth" value="1200" placeholder="Width">
                        <span>×</span>
                        <input type="number" id="maxHeight" value="800" placeholder="Height">
                    </div>
                    <div class="upload-option">
                        <input type="checkbox" id="createThumbnail" checked>
                        <label for="createThumbnail">Create thumbnail</label>
                        <input type="number" id="thumbWidth" value="200" placeholder="Width">
                        <span>×</span>
                        <input type="number" id="thumbHeight" value="200" placeholder="Height">
                    </div>
                    <div class="upload-option">
                        <label for="quality">Quality:</label>
                        <input type="number" id="quality" value="85" min="1" max="100">
                        <span>%</span>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Hidden File Input -->
                <input type="file" id="fileInput" multiple style="display: none;" 
                       accept="<?php 
                       switch($type) {
                           case 'image': echo 'image/*'; break;
                           case 'video': echo 'video/*'; break;
                           case 'document': echo '.pdf,.doc,.docx,.txt'; break;
                       }
                       ?>">

                <!-- Media Grid -->
                <div class="media-grid" id="mediaGrid">
                    <?php if (!empty($files)): ?>
                        <?php foreach ($files as $file): ?>
                        <div class="media-item" data-file="<?php echo htmlspecialchars($file['name']); ?>">
                            <div class="media-preview">
                                <?php if ($type === 'image'): ?>
                                    <img src="../<?php echo htmlspecialchars($file['url']); ?>" alt="<?php echo htmlspecialchars($file['name']); ?>" style="width: 100%; height: 100%; object-fit: cover;">
                                <?php elseif ($type === 'video'): ?>
                                    🎥
                                <?php else: ?>
                                    📄
                                <?php endif; ?>
                            </div>
                            <div class="media-overlay">
                                <div style="text-align: center;">
                                    <button onclick="viewFile('<?php echo htmlspecialchars($file['url']); ?>')" class="btn btn-sm">View</button>
                                    <button onclick="copyUrl('<?php echo htmlspecialchars($file['url']); ?>')" class="btn btn-sm btn-secondary">Copy URL</button>
                                    <button onclick="deleteFile('<?php echo $type; ?>s/<?php echo htmlspecialchars($file['name']); ?>')" class="btn btn-sm" style="background: #e74c3c;">Delete</button>
                                </div>
                            </div>
                            <div class="media-info">
                                <div class="media-name"><?php echo htmlspecialchars($file['name']); ?></div>
                                <div class="media-meta">
                                    Size: <?php echo number_format($file['size'] / 1024, 1); ?> KB<br>
                                    Modified: <?php echo date('M j, Y', $file['modified']); ?>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div style="grid-column: 1 / -1; text-align: center; padding: 3rem; color: #666;">
                            <div style="font-size: 3rem; margin-bottom: 1rem;">📁</div>
                            <h3>No <?php echo $type; ?>s uploaded yet</h3>
                            <p>Upload your first <?php echo $type; ?> to get started</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </main>
    </div>

    <!-- File Viewer Modal -->
    <div id="fileViewerModal" class="modal">
        <div class="modal-content" style="max-width: 90%; max-height: 90%;">
            <button class="modal-close" onclick="hideModal('fileViewerModal')">&times;</button>
            <div id="fileViewerContent"></div>
        </div>
    </div>

    <script src="../assets/js/main.js"></script>
    <script>
        const currentType = '<?php echo $type; ?>';
        
        function switchType(type) {
            window.location.href = 'media.php?type=' + type;
        }
        
        // File upload handling
        const fileInput = document.getElementById('fileInput');
        const uploadArea = document.getElementById('uploadArea');
        const uploadProgress = document.getElementById('uploadProgress');
        const uploadProgressBar = document.getElementById('uploadProgressBar');
        
        fileInput.addEventListener('change', handleFileUpload);
        
        // Drag and drop
        uploadArea.addEventListener('dragover', (e) => {
            e.preventDefault();
            uploadArea.classList.add('dragover');
        });
        
        uploadArea.addEventListener('dragleave', () => {
            uploadArea.classList.remove('dragover');
        });
        
        uploadArea.addEventListener('drop', (e) => {
            e.preventDefault();
            uploadArea.classList.remove('dragover');
            
            const files = e.dataTransfer.files;
            if (files.length > 0) {
                fileInput.files = files;
                handleFileUpload();
            }
        });
        
        function handleFileUpload() {
            const files = fileInput.files;
            if (files.length === 0) return;
            
            uploadArea.classList.add('uploading');
            uploadProgress.style.display = 'block';
            
            const formData = new FormData();
            
            if (files.length === 1) {
                formData.append('file', files[0]);
                formData.append('action', 'upload');
            } else {
                for (let i = 0; i < files.length; i++) {
                    formData.append('files[]', files[i]);
                }
                formData.append('action', 'upload_multiple');
            }
            
            formData.append('type', currentType);
            
            // Add image options if applicable
            if (currentType === 'image') {
                if (document.getElementById('resizeImage').checked) {
                    formData.append('resize', 'true');
                    formData.append('max_width', document.getElementById('maxWidth').value);
                    formData.append('max_height', document.getElementById('maxHeight').value);
                    formData.append('quality', document.getElementById('quality').value);
                }
                
                if (document.getElementById('createThumbnail').checked) {
                    formData.append('create_thumb', 'true');
                    formData.append('thumb_width', document.getElementById('thumbWidth').value);
                    formData.append('thumb_height', document.getElementById('thumbHeight').value);
                }
            }
            
            const xhr = new XMLHttpRequest();
            
            xhr.upload.addEventListener('progress', (e) => {
                if (e.lengthComputable) {
                    const percentComplete = (e.loaded / e.total) * 100;
                    uploadProgressBar.style.width = percentComplete + '%';
                }
            });
            
            xhr.addEventListener('load', () => {
                uploadArea.classList.remove('uploading');
                uploadProgress.style.display = 'none';
                uploadProgressBar.style.width = '0%';
                
                try {
                    const response = JSON.parse(xhr.responseText);
                    if (response.success) {
                        showAlert('File(s) uploaded successfully!', 'success');
                        setTimeout(() => {
                            window.location.reload();
                        }, 1000);
                    } else {
                        showAlert(response.message || 'Upload failed', 'error');
                    }
                } catch (e) {
                    showAlert('Upload failed', 'error');
                }
                
                fileInput.value = '';
            });
            
            xhr.addEventListener('error', () => {
                uploadArea.classList.remove('uploading');
                uploadProgress.style.display = 'none';
                uploadProgressBar.style.width = '0%';
                showAlert('Upload failed', 'error');
                fileInput.value = '';
            });
            
            xhr.open('POST', '../api/upload.php');
            xhr.send(formData);
        }
        
        function viewFile(url) {
            const content = document.getElementById('fileViewerContent');
            
            if (currentType === 'image') {
                content.innerHTML = `<img src="../${url}" style="max-width: 100%; max-height: 80vh; object-fit: contain;">`;
            } else if (currentType === 'video') {
                content.innerHTML = `<video controls style="max-width: 100%; max-height: 80vh;"><source src="../${url}"></video>`;
            } else {
                content.innerHTML = `<iframe src="../${url}" style="width: 100%; height: 80vh; border: none;"></iframe>`;
            }
            
            showModal('fileViewerModal');
        }
        
        function copyUrl(url) {
            const fullUrl = window.location.origin + '/' + url;
            navigator.clipboard.writeText(fullUrl).then(() => {
                showAlert('URL copied to clipboard!', 'success');
            }).catch(() => {
                showAlert('Failed to copy URL', 'error');
            });
        }
        
        function deleteFile(filePath) {
            if (!confirm('Are you sure you want to delete this file?')) {
                return;
            }
            
            const formData = new FormData();
            formData.append('action', 'delete');
            formData.append('file_path', filePath);
            
            fetch('../api/upload.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showAlert('File deleted successfully!', 'success');
                    document.querySelector(`[data-file="${filePath.split('/').pop()}"]`).remove();
                } else {
                    showAlert('Failed to delete file', 'error');
                }
            })
            .catch(() => {
                showAlert('Failed to delete file', 'error');
            });
        }
        
        function clearAll() {
            if (!confirm('Are you sure you want to delete all ' + currentType + 's? This action cannot be undone.')) {
                return;
            }
            
            const mediaItems = document.querySelectorAll('.media-item');
            let deleteCount = 0;
            
            mediaItems.forEach(item => {
                const fileName = item.dataset.file;
                const filePath = currentType + 's/' + fileName;
                
                const formData = new FormData();
                formData.append('action', 'delete');
                formData.append('file_path', filePath);
                
                fetch('../api/upload.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        item.remove();
                        deleteCount++;
                    }
                });
            });
            
            setTimeout(() => {
                showAlert(`${deleteCount} files deleted`, 'success');
                if (deleteCount === mediaItems.length) {
                    window.location.reload();
                }
            }, 2000);
        }
    </script>
</body>
</html>

