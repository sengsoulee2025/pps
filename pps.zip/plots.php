<?php
// plots.php - ໜ້າແປງທີ່ດິນ
// ໄຟລ໌ນີ້ສະແດງລາຍຊື່ແປງທີ່ດິນທັງໝົດ, ພ້ອມດ້ວຍຟັງຊັນຄົ້ນຫາ ແລະ ກັ່ນຕອງ.

// ລວມເອົາໄຟລ໌ການຕັ້ງຄ່າ ແລະ ຄລາສທີ່ຈຳເປັນ
require_once 'config/config.php'; // ໄຟລ໌ການຕັ້ງຄ່າລະບົບ (ເຊັ່ນ: ຂໍ້ມູນຖານຂໍ້ມູນ)
require_once 'includes/plot.php'; // ຄລາສສຳລັບຈັດການແປງທີ່ດິນ
require_once 'includes/project.php'; // ຄລາສສຳລັບຈັດການໂຄງການ

// ເຊື່ອມຕໍ່ຖານຂໍ້ມູນ
// ຕົວແປ $pdo ຖືກສ້າງຂຶ້ນຈາກຟັງຊັນ getDBConnection() ທີ່ຢູ່ໃນ config/config.php
$pdo = getDBConnection();
// ສ້າງ Object ຂອງ Plot ໂດຍສົ່ງການເຊື່ອມຕໍ່ຖານຂໍ້ມູນເຂົ້າໄປ
// ຕົວແປ $plot ຖືກໃຊ້ເພື່ອເຂົ້າເຖິງຟັງຊັນຕ່າງໆຂອງຄລາສ Plot
$plot = new Plot($pdo);
// ສ້າງ Object ຂອງ Project ໂດຍສົ່ງການເຊື່ອມຕໍ່ຖານຂໍ້ມູນເຂົ້າໄປ
// ຕົວແປ $project ຖືກໃຊ້ເພື່ອເຂົ້າເຖິງຟັງຊັນຕ່າງໆຂອງຄລາສ Project
$project = new Project($pdo);

// ດຶງພາລາມິເຕີການຄົ້ນຫາຈາກ URL
// $search: ຕົວແປນີ້ເກັບຄ່າຄົ້ນຫາທີ່ຜູ້ໃຊ້ປ້ອນເຂົ້າມາ (ຈາກ $_GET['search'])
$search = isset($_GET['search']) ? sanitizeInput($_GET['search']) : '';
// $status: ຕົວແປນີ້ເກັບຄ່າສະຖານະທີ່ຜູ້ໃຊ້ເລືອກ (ຈາກ $_GET['status'])
$status = isset($_GET['status']) ? sanitizeInput($_GET['status']) : '';
// $project_id: ຕົວແປນີ້ເກັບ ID ຂອງໂຄງການທີ່ເລືອກ (ຈາກ $_GET['project_id'])
$project_id = isset($_GET['project_id']) ? (int)$_GET['project_id'] : null;

// ດຶງຂໍ້ມູນແປງທີ່ດິນ ແລະ ໂຄງການ
// $plots: ຕົວແປນີ້ເກັບລາຍຊື່ແປງທີ່ດິນທີ່ກົງກັບເງື່ອນໄຂການຄົ້ນຫາ
$plots = $plot->getAllPlots(null, 0, $search, $status, $project_id);
// $projects: ຕົວແປນີ້ເກັບລາຍຊື່ໂຄງການທັງໝົດ (ໃຊ້ສຳລັບ dropdown filter)
$projects = $project->getAllProjects();

// ດຶງຂໍ້ຄວາມແຈ້ງເຕືອນ (ຖ້າມີ)
// $alert: ຕົວແປນີ້ເກັບຂໍ້ຄວາມແຈ້ງເຕືອນທີ່ອາດຈະຖືກຕັ້ງໄວ້ໃນ session
$alert = getAlert();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ແປງທີ່ດິນ - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .plots-hero {
            background: linear-gradient(135deg, rgba(102,126,234,0.9) 0%, rgba(118,75,162,0.9) 100%), url('assets/images/default-plot.jpg');
            background-size: cover;
            background-position: center;
            color: white;
            padding: 6rem 0 4rem;
            text-align: center;
        }
        
        .plots-hero h1 {
            font-size: 3rem;
            margin-bottom: 1rem;
        }
        
        .plots-hero p {
            font-size: 1.2rem;
            max-width: 600px;
            margin: 0 auto;
        }
        
        .plots-filters {
            background: white;
            padding: 2rem 0;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 3rem;
        }
        
        .filter-form {
            display: grid;
            grid-template-columns: 1fr 200px 200px 150px;
            gap: 1rem;
            align-items: end;
        }
        
        .filter-group {
            display: flex;
            flex-direction: column;
        }
        
        .filter-group label {
            font-weight: 600;
            margin-bottom: 0.5rem;
            color: #2c3e50;
        }
        
        .filter-group input,
        .filter-group select {
            padding: 0.75rem;
            border: 2px solid #e9ecef;
            border-radius: 8px;
            font-size: 1rem;
        }
        
        .filter-group input:focus,
        .filter-group select:focus {
            outline: none;
            border-color: #667eea;
        }
        
        .plots-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: 2rem;
            margin-bottom: 3rem;
        }
        
        .plot-card {
            background: white;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            position: relative;
        }
        
        .plot-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 20px 40px rgba(0,0,0,0.15);
        }
        
        .plot-image {
            width: 100%;
            height: 250px;
            object-fit: cover;
            background: linear-gradient(45deg, #f8f9fa, #e9ecef);
            display: flex;
            align-items: center;
            justify-content: center;
            color: #666;
            font-size: 3rem;
        }
        
        .plot-status {
            position: absolute;
            top: 1rem;
            right: 1rem;
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
            text-transform: uppercase;
        }
        
        .plot-status.available {
            background: #d4edda;
            color: #155724;
        }
        
        .plot-status.reserved {
            background: #fff3cd;
            color: #856404;
        }
        
        .plot-status.sold {
            background: #f8d7da;
            color: #721c24;
        }
        
        .plot-info {
            padding: 2rem;
        }
        
        .plot-title {
            font-size: 1.4rem;
            font-weight: 700;
            color: #2c3e50;
            margin-bottom: 0.5rem;
        }
        
        .plot-project {
            color: #667eea;
            font-weight: 600;
            margin-bottom: 1rem;
        }
        
        .plot-details {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
            margin-bottom: 1.5rem;
        }
        
        .plot-detail {
            text-align: center;
            padding: 1rem;
            background: #f8f9fa;
            border-radius: 10px;
        }
        
        .plot-detail-value {
            font-size: 1.2rem;
            font-weight: 700;
            color: #2c3e50;
            margin-bottom: 0.25rem;
        }
        
        .plot-detail-label {
            font-size: 0.9rem;
            color: #666;
        }
        
        .plot-price {
            font-size: 1.8rem;
            font-weight: 700;
            color: #27ae60;
            text-align: center;
            margin-bottom: 1.5rem;
        }
        
        .plot-actions {
            display: flex;
            gap: 1rem;
        }
        
        .btn-plot {
            flex: 1;
            padding: 1rem;
            border: none;
            border-radius: 10px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            text-align: center;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        
        .btn-secondary {
            background: #f8f9fa;
            color: #2c3e50;
            border: 2px solid #e9ecef;
        }
        
        .btn-plot:hover {
            transform: translateY(-2px);
        }
        
        .no-plots {
            text-align: center;
            padding: 4rem 2rem;
            color: #666;
        }
        
        .no-plots-icon {
            font-size: 4rem;
            margin-bottom: 1rem;
        }
        
        @media (max-width: 768px) {
            .filter-form {
                grid-template-columns: 1fr;
            }
            
            .plots-grid {
                grid-template-columns: 1fr;
            }
            
            .plots-hero h1 {
                font-size: 2rem;
            }
        }
    </style>
</head>
<body>
    <!-- Navigation - ສ່ວນເມນູການນຳທາງ -->
    <nav class="navbar">
        <div class="container">
            <div class="nav-brand">
                <a href="index.php"><?php echo SITE_NAME; ?></a>
            </div>
            <ul class="nav-menu">
                <li><a href="index.php">ໜ້າຫຼັກ</a></li>
                <li><a href="projects.php">ໂຄງການ</a></li>
                <li><a href="plots.php" class="active">ແປງທີ່ດິນ</a></li>
                <li><a href="about.php">ກ່ຽວກັບ</a></li>
                <li><a href="contact.php">ຕິດຕໍ່</a></li>
                <?php 
                // ກວດສອບວ່າຜູ້ໃຊ້ໄດ້ເຂົ້າສູ່ລະບົບແລ້ວບໍ
                // isLoggedIn() ແມ່ນຟັງຊັນທີ່ຢູ່ໃນ includes/auth.php
                if (isLoggedIn()): 
                ?>
                    <?php 
                    // ກວດສອບບົດບາດຂອງຜູ້ໃຊ້
                    // hasRole() ແມ່ນຟັງຊັນທີ່ຢູ່ໃນ includes/auth.php
                    if (hasRole("admin") || hasRole("manager") || hasRole("sales")): 
                    ?>
                        <li><a href="admin/dashboard.php">ຜູ້ດູແລລະບົບ</a></li>
                    <?php else: ?>
                        <li><a href="customer/dashboard.php">ແຜງຄວບຄຸມ</a></li>
                    <?php endif; ?>
                    <li><a href="logout.php">ອອກຈາກລະບົບ</a></li>
                <?php else: ?>
                    <li><a href="login.php">ເຂົ້າສູ່ລະບົບ</a></li>
                    <li><a href="register.php">ລົງທະບຽນ</a></li>
                <?php endif; ?>
            </ul>
            <div class="nav-toggle">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>
    </nav>

    <!-- Hero Section - ສ່ວນຫົວຂໍ້ຫຼັກຂອງໜ້າ -->
    <section class="plots-hero">
        <div class="container">
            <h1>ແປງທີ່ດິນທີ່ມີຢູ່</h1>
            <p>ຄົ້ນພົບທີ່ດິນທີ່ສົມບູນແບບຂອງທ່ານຈາກການລວບລວມແປງທີ່ດິນພຣີມຽມທີ່ພ້ອມພັດທະນາຂອງພວກເຮົາ</p>
        </div>
    </section>

    <!-- Filters Section - ສ່ວນຄົ້ນຫາ ແລະ ກັ່ນຕອງ -->
    <!-- ໃຫ້ຜູ້ໃຊ້ສາມາດຄົ້ນຫາແປງທີ່ດິນຕາມເງື່ອນໄຂຕ່າງໆ -->
    <section class="plots-filters">
        <div class="container">
            <form method="GET" class="filter-form">
                <div class="filter-group">
                    <label for="search">ຄົ້ນຫາ</label>
                    <!-- input search: ຕົວແປ $search ຖືກໃຊ້ເພື່ອເກັບຄ່າການຄົ້ນຫາ -->
                    <input type="text" id="search" name="search" placeholder="ຄົ້ນຫາແປງທີ່ດິນ..." value="<?php echo htmlspecialchars($search); ?>">
                </div>
                <div class="filter-group">
                    <label for="project_id">ໂຄງການ</label>
                    <!-- select project_id: ຕົວແປ $project_id ຖືກໃຊ້ເພື່ອເກັບ ID ໂຄງການທີ່ເລືອກ -->
                    <select id="project_id" name="project_id">
                        <option value="">ທຸກໂຄງການ</option>
                        <?php foreach ($projects as $proj): // ວົນລູບສະແດງລາຍຊື່ໂຄງການສຳລັບ dropdown ?>
                            <option value="<?php echo $proj["id"]; ?>" <?php echo $project_id == $proj["id"] ? "selected" : ""; ?>>
                                <?php echo htmlspecialchars($proj["name"]); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="filter-group">
                    <label for="status">ສະຖານະ</label>
                    <!-- select status: ຕົວແປ $status ຖືກໃຊ້ເພື່ອເກັບຄ່າສະຖານະທີ່ເລືອກ -->
                    <select id="status" name="status">
                        <option value="">ທຸກສະຖານະ</option>
                        <option value="available" <?php echo $status === "available" ? "selected" : ""; ?>>ວ່າງ</option>
                        <option value="reserved" <?php echo $status === "reserved" ? "selected" : ""; ?>>ຈອງແລ້ວ</option>
                        <option value="sold" <?php echo $status === "sold" ? "selected" : ""; ?>>ຂາຍແລ້ວ</option>
                    </select>
                </div>
                <div class="filter-group">
                    <button type="submit" class="btn btn-primary">ກັ່ນຕອງ</button>
                </div>
            </form>
        </div>
    </section>

    <!-- Plots Grid Section - ສ່ວນສະແດງລາຍຊື່ແປງທີ່ດິນ -->
    <section class="plots-section">
        <div class="container">
            <?php if ($alert): // ສະແດງຂໍ້ຄວາມແຈ້ງເຕືອນຖ້າມີ ?>
            <div class="alert alert-<?php echo $alert['type']; ?>">
                <?php echo htmlspecialchars($alert['message']); ?>
            </div>
            <?php endif; ?>

            <?php if (!empty($plots)): // ກວດສອບວ່າ $plots ບໍ່ຫວ່າງເປົ່າ ?>
            <div class="plots-grid">
                <?php foreach ($plots as $plotItem): // ວົນລູບສະແດງແຕ່ລະແປງທີ່ດິນ ?>
                <div class="plot-card">
                    <div class="plot-image">
                        <?php if ($plotItem['image_url']): // ກວດສອບວ່າແປງທີ່ດິນມີຮູບພາບ ?>
                            <img src="<?php echo htmlspecialchars($plotItem['image_url']); ?>" alt="Plot <?php echo htmlspecialchars($plotItem['plot_number']); ?>" class="plot-image">
                        <?php else: // ຖ້າບໍ່ມີຮູບພາບ, ສະແດງໄອຄອນແທນ ?>
                            🏞️
                        <?php endif; ?>
                    </div>
                    <!-- ສະຖານະຂອງແປງທີ່ດິນ (ດຶງມາຈາກ $plotItem['status']) -->
                    <div class="plot-status <?php echo $plotItem['status']; ?>">
                        <?php echo ucfirst($plotItem['status']); ?>
                    </div>
                    <div class="plot-info">
                        <!-- ເລກແປງທີ່ດິນ (ດຶງມາຈາກ $plotItem['plot_number']) -->
                        <h3 class="plot-title">ແປງທີ່ດິນ #<?php echo htmlspecialchars($plotItem["plot_number"]); ?></h3>
                        <!-- ຊື່ໂຄງການ (ດຶງມາຈາກ $plotItem['project_name']) -->
                        <div class="plot-project"><?php echo htmlspecialchars($plotItem["project_name"]); ?></div>
                        
                        <div class="plot-details">
                            <div class="plot-detail">
                                <!-- ພື້ນທີ່ແປງທີ່ດິນ (ດຶງມາຈາກ $plotItem['area']) -->
                                <div class="plot-detail-value"><?php echo number_format($plotItem["area"]); ?></div>
                                <div class="plot-detail-label">ຕາແມັດ</div>
                            </div>
                            <div class="plot-detail">
                                <!-- ສະຖານະແປງທີ່ດິນ (ດຶງມາຈາກ $plotItem['status']) -->
                                <div class="plot-detail-value"><?php echo ucfirst($plotItem["status"]); ?></div>
                                <div class="plot-detail-label">ສະຖານະ</div>
                            </div>
                        </div>
                        
                        <!-- ລາຄາແປງທີ່ດິນ (ດຶງມາຈາກ $plotItem['price']) -->
                        <div class="plot-price"><?php echo formatPrice($plotItem["price"]); ?></div>
                        
                        <div class="plot-actions">
                            <!-- ລິ້ງໄປໜ້າລາຍລະອຽດແປງທີ່ດິນ -->
                            <a href="plot_detail.php?id=<?php echo $plotItem["id"]; ?>" class="btn-plot btn-primary">ເບິ່ງລາຍລະອຽດ</a>
                            <?php 
                            // ກວດສອບວ່າຜູ້ໃຊ້ເຂົ້າສູ່ລະບົບ ແລະ ມີບົດບາດເປັນລູກຄ້າ
                            // isLoggedIn() ແລະ hasRole() ແມ່ນຟັງຊັນທີ່ຢູ່ໃນ includes/auth.php
                            if (isLoggedIn() && hasRole("customer")): 
                            ?>
                                <!-- ປຸ່ມບັນທຶກລາຍການທີ່ມັກ -->
                                <button onclick="toggleFavorite(<?php echo $plotItem["id"]; ?>)" class="btn-plot btn-secondary">❤️ ບັນທຶກ</button>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php else: // ຖ້າບໍ່ພົບແປງທີ່ດິນ ?>
            <div class="no-plots">
                <div class="no-plots-icon">🏞️</div>
                <h3>ບໍ່ພົບແປງທີ່ດິນ</h3>
                <p>ລອງປັບປ່ຽນເງື່ອນໄຂການຄົ້ນຫາຂອງທ່ານ ຫຼື ຊອກຫາແປງທີ່ດິນທີ່ມີຢູ່ທັງໝົດ.</p>
                <a href="plots.php" class="btn btn-primary">ເບິ່ງແປງທີ່ດິນທັງໝົດ</a>
            </div>
            <?php endif; ?>
        </div>
    </section>

    <!-- Footer Section - ສ່ວນທ້າຍຂອງເວັບໄຊທ໌ -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3><?php echo SITE_NAME; ?></h3>
                    <p>Leading the way in sustainable land development and real estate excellence.</p>
                    <div class="social-links">
                        <a href="#" aria-label="Facebook">📘</a>
                        <a href="#" aria-label="Twitter">🐦</a>
                        <a href="#" aria-label="LinkedIn">💼</a>
                        <a href="#" aria-label="Instagram">📷</a>
                    </div>
                </div>
                <div class="footer-section">
                    <h4>Quick Links</h4>
                    <ul>
                        <li><a href="index.php">Home</a></li>
                        <li><a href="projects.php">Projects</a></li>
                        <li><a href="plots.php">Land Plots</a></li>
                        <li><a href="about.php">About</a></li>
                        <li><a href="contact.php">Contact</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h4>Services</h4>
                    <ul>
                        <li><a href="#">Land Development</a></li>
                        <li><a href="#">Property Management</a></li>
                        <li><a href="#">Real Estate Consulting</a></li>
                        <li><a href="#">Investment Advisory</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h4>Contact Info</h4>
                    <div class="contact-info">
                        <p>📍 123 Business District, City Center</p>
                        <p>📞 +1 (555) 123-4567</p>
                        <p>✉️ info@ppsland.com</p>
                    </div>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; <?php echo date('Y'); ?> <?php echo SITE_NAME; ?>. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <!-- JavaScript Files -->
    <script src="assets/js/main.js"></script>
    <script>
        // toggleFavorite(plotId): ຟັງຊັນ JavaScript ສຳລັບການເພີ່ມ/ລຶບແປງທີ່ດິນເຂົ້າ/ອອກຈາກລາຍການທີ່ມັກ
        function toggleFavorite(plotId) {
            // ສົ່ງຄຳຮ້ອງຂໍ POST ໄປຍັງ API
            fetch('api/favorites.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    plot_id: plotId,
                    action: 'toggle'
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Plot ' + (data.added ? 'added to' : 'removed from') + ' favorites!');
                } else {
                    alert('Error: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred. Please try again.');
            });
        }
    </script>
</body>
</html>


