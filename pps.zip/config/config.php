<?php
// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Site configuration
define('SITE_NAME', 'PPS Land Management System');
define('SITE_URL', 'http://localhost');
define('ADMIN_EMAIL', 'admin@ppsland.com');

// File upload settings
define('MAX_FILE_SIZE', 10 * 1024 * 1024); // 10MB
define('UPLOAD_PATH', __DIR__ . '/../uploads/');
define('ALLOWED_IMAGE_TYPES', ['jpg', 'jpeg', 'png', 'gif', 'webp']);
define('ALLOWED_VIDEO_TYPES', ['mp4', 'avi', 'mov', 'wmv']);
define('ALLOWED_DOC_TYPES', ['pdf', 'doc', 'docx', 'txt']);

// Pagination settings
define('ITEMS_PER_PAGE', 12);

// Security settings
define('PASSWORD_MIN_LENGTH', 6);
define('SESSION_TIMEOUT', 3600); // 1 hour

// Include database configuration
require_once 'database.php';

// Utility functions
function sanitizeInput($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}

function formatPrice($price) {
    return number_format($price, 0, '.', ',') . ' ₭';
}

function formatDate($date) {
    return date('d/m/Y', strtotime($date));
}

function formatDateTime($datetime) {
    return date('d/m/Y H:i', strtotime($datetime));
}

function generateRandomString($length = 10) {
    return substr(str_shuffle(str_repeat($x='0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', ceil($length/strlen($x)) )),1,$length);
}

function isLoggedIn() {
    return isset($_SESSION['user_id']) && isset($_SESSION['username']);
}

function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: /login.php');
        exit();
    }
}

function hasRole($role) {
    return isset($_SESSION['role']) && $_SESSION['role'] === $role;
}

function requireRole($role) {
    requireLogin();
    if (!hasRole($role)) {
        header('Location: /unauthorized.php');
        exit();
    }
}

function isAdmin() {
    return hasRole('admin') || hasRole('manager');
}

function redirect($url) {
    header("Location: $url");
    exit();
}

function showAlert($message, $type = 'info') {
    $_SESSION['alert'] = ['message' => $message, 'type' => $type];
}

function getAlert() {
    if (isset($_SESSION['alert'])) {
        $alert = $_SESSION['alert'];
        unset($_SESSION['alert']);
        return $alert;
    }
    return null;
}
function handleFileUpload($file_input_name, $upload_subdirectory = '') {
    // Check if a file was uploaded without errors
    if (isset($_FILES[$file_input_name]) && $_FILES[$file_input_name]['error'] === UPLOAD_ERR_OK) {
        $file_tmp_path = $_FILES[$file_input_name]['tmp_name'];
        $file_name = basename($_FILES[$file_input_name]['name']);
        $file_extension = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

        // Create a unique file name to prevent overwriting
        $new_file_name = uniqid() . '-' . time() . '.' . $file_extension;

        // Define the destination path
        $dest_path = UPLOAD_PATH . $upload_subdirectory . $new_file_name;
        
        // Ensure the directory exists
        if (!is_dir(UPLOAD_PATH . $upload_subdirectory)) {
            mkdir(UPLOAD_PATH . $upload_subdirectory, 0755, true);
        }

        // Move the file to the destination
        if (move_uploaded_file($file_tmp_path, $dest_path)) {
            // Return the web-accessible path to store in the database
            return 'uploads/' . $upload_subdirectory . $new_file_name;
        }
    }
    return null; // Return null if no file was uploaded or an error occurred
}
?>

