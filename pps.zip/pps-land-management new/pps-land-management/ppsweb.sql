-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 03, 2025 at 02:16 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ppsweb`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `appointment_date` datetime NOT NULL,
  `purpose` text DEFAULT NULL,
  `status` varchar(20) DEFAULT 'scheduled',
  `notes` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`id`, `customer_id`, `employee_id`, `appointment_date`, `purpose`, `status`, `notes`, `created_at`, `updated_at`) VALUES
(1, 4, 1, '2025-07-30 09:20:57', 'gdsgdgdg', 'scheduled', 'gfdgdgfgdfg', '2025-07-30 14:21:14', '2025-07-30 14:21:14');

-- --------------------------------------------------------

--
-- Table structure for table `contact_history`
--

CREATE TABLE `contact_history` (
  `id` int(11) NOT NULL,
  `lead_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `contact_type` varchar(50) DEFAULT NULL,
  `contact_date` datetime DEFAULT current_timestamp(),
  `duration_minutes` int(11) DEFAULT NULL,
  `outcome` text DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `next_action` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` int(11) NOT NULL,
  `username_id` int(11) DEFAULT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(120) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `username_id`, `first_name`, `last_name`, `phone`, `email`, `address`, `created_at`, `updated_at`) VALUES
(4, 7, 'test2', 'seng', '96207507', 'merfffffyf@gmail.com', 'ນະຄອນຫຼວງ', '2025-07-30 11:49:45', '2025-07-30 13:18:09'),
(7, 11, 'seng', 'phimmasone', '22222222', 'userdddd@demo.com', NULL, '2025-07-30 14:28:02', '2025-07-30 14:28:02');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `id` int(11) NOT NULL,
  `employee_id` varchar(20) NOT NULL,
  `username_id` int(11) DEFAULT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `department` varchar(50) DEFAULT NULL,
  `position` varchar(50) DEFAULT NULL,
  `hire_date` date DEFAULT NULL,
  `salary` decimal(12,2) DEFAULT NULL,
  `annual_leave_days` int(11) DEFAULT 15,
  `used_leave_days` int(11) DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`id`, `employee_id`, `username_id`, `first_name`, `last_name`, `phone`, `department`, `position`, `hire_date`, `salary`, `annual_leave_days`, `used_leave_days`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'pps026', 7, 'sengsoulee', 'phimmasone', '02092942276', 'marketing', 'Craphic', '2025-07-23', 200000.00, 15, 5, 1, '2025-07-30 14:20:50', '2025-07-30 14:20:50');

-- --------------------------------------------------------

--
-- Table structure for table `favorite_plot`
--

CREATE TABLE `favorite_plot` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `plot_id` int(11) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lead`
--

CREATE TABLE `lead` (
  `id` int(11) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(120) DEFAULT NULL,
  `phone` varchar(20) NOT NULL,
  `source` varchar(100) DEFAULT NULL,
  `status` varchar(20) DEFAULT 'new',
  `priority` varchar(20) DEFAULT 'medium',
  `interested_project_id` int(11) DEFAULT NULL,
  `interested_plot_id` int(11) DEFAULT NULL,
  `budget_min` double DEFAULT NULL,
  `budget_max` double DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `assigned_to` int(11) DEFAULT NULL,
  `last_contact_date` datetime DEFAULT NULL,
  `next_follow_up` datetime DEFAULT NULL,
  `converted_to_customer_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `leave_request`
--

CREATE TABLE `leave_request` (
  `id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `leave_type` varchar(50) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `days_requested` int(11) NOT NULL,
  `reason` text DEFAULT NULL,
  `status` varchar(20) DEFAULT 'pending',
  `approved_by` int(11) DEFAULT NULL,
  `approved_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `plot`
--

CREATE TABLE `plot` (
  `id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `zone_id` int(11) DEFAULT NULL,
  `plot_number` varchar(50) NOT NULL,
  `area` double NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'available',
  `description` text DEFAULT NULL,
  `image_url` text DEFAULT NULL,
  `virtual_tour_url` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `plot`
--

INSERT INTO `plot` (`id`, `project_id`, `zone_id`, `plot_number`, `area`, `status`, `description`, `image_url`, `virtual_tour_url`, `created_at`, `updated_at`) VALUES
(21, 13, 20, 'A03', 343, 'sold', NULL, NULL, NULL, '2025-08-03 01:33:22', '2025-08-03 02:33:57'),
(22, 14, 14, 'A03', 343, 'available', NULL, NULL, NULL, '2025-08-03 01:33:23', '2025-08-03 02:32:05'),
(25, 14, 16, 'A07', 222, 'available', NULL, NULL, NULL, '2025-08-03 02:04:30', '2025-08-03 02:04:30'),
(26, 15, 18, 'A03', 5555, 'available', NULL, NULL, NULL, '2025-08-03 02:05:53', '2025-08-03 02:05:53'),
(27, 14, 14, 'A22', 200, 'available', NULL, NULL, NULL, '2025-08-03 02:07:11', '2025-08-03 02:07:11'),
(28, 14, 16, 'A04', 1, 'available', NULL, NULL, NULL, '2025-08-03 02:07:56', '2025-08-03 02:07:56');

-- --------------------------------------------------------

--
-- Table structure for table `project`
--

CREATE TABLE `project` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `location` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `total_plots` int(11) DEFAULT 0,
  `available_plots` int(11) DEFAULT 0,
  `reserved_plots` int(11) DEFAULT 0,
  `sold_plots` int(11) DEFAULT 0,
  `master_plan_url` text DEFAULT NULL,
  `video_url` text DEFAULT NULL,
  `status` varchar(50) DEFAULT 'active',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `project`
--

INSERT INTO `project` (`id`, `name`, `location`, `description`, `total_plots`, `available_plots`, `reserved_plots`, `sold_plots`, `master_plan_url`, `video_url`, `status`, `created_at`, `updated_at`) VALUES
(13, 'ນາສ່າງໄຜ່', 'tftດດ', 'hgfິິິ', 0, 0, 0, 0, 'uploads/images/fdf_1753846450_1754155183.jpeg', NULL, 'active', '2025-08-03 00:19:43', '2025-08-03 02:08:53'),
(14, 'ນາສາລາ', 'ໄຊທານີ5', 'ີິີ້່ືທຶືທຶື', 0, 0, 0, 0, 'uploads/images/Screenshot_2025-06-28_084348_1753846383_1754159454.png', NULL, 'active', '2025-08-03 01:30:54', '2025-08-03 02:09:06'),
(15, 'ນາສ່າງໄຜ່3', 'ເມືອງຫາດຊາຍຟອງ', 'ຫກ', 0, 0, 0, 0, 'uploads/images/Screenshot_2025-07-05_090221_1753848236_1754163253.png', NULL, 'active', '2025-08-03 01:46:48', '2025-08-03 02:34:13');

-- --------------------------------------------------------

--
-- Table structure for table `project_zones`
--

CREATE TABLE `project_zones` (
  `id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `zone_name` varchar(100) NOT NULL,
  `price_per_sqm` decimal(15,2) NOT NULL,
  `currency` varchar(3) NOT NULL COMMENT 'เช่น LAK หรือ THB',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `project_zones`
--

INSERT INTO `project_zones` (`id`, `project_id`, `zone_name`, `price_per_sqm`, `currency`, `created_at`, `updated_at`) VALUES
(14, 14, 'B1', 330000.00, 'LAK', '2025-08-02 18:31:26', '2025-08-02 19:18:38'),
(16, 14, 'C', 560000.00, 'LAK', '2025-08-02 18:31:59', '2025-08-02 18:31:59'),
(18, 15, 'A', 433.00, 'THB', '2025-08-02 19:05:16', '2025-08-02 19:05:16'),
(20, 13, 'A', 322.00, 'THB', '2025-08-02 19:32:57', '2025-08-02 19:32:57');

-- --------------------------------------------------------

--
-- Table structure for table `sale`
--

CREATE TABLE `sale` (
  `id` int(11) NOT NULL,
  `plot_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `sale_price` double NOT NULL,
  `commission_rate` double DEFAULT 0.05,
  `commission_amount` double DEFAULT NULL,
  `payment_method` varchar(50) DEFAULT NULL,
  `down_payment` double DEFAULT NULL,
  `loan_amount` double DEFAULT NULL,
  `monthly_payment` double DEFAULT NULL,
  `loan_term_months` int(11) DEFAULT NULL,
  `sale_date` datetime DEFAULT current_timestamp(),
  `status` varchar(20) DEFAULT 'completed',
  `notes` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `time_record`
--

CREATE TABLE `time_record` (
  `id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `clock_in` datetime NOT NULL,
  `clock_out` datetime DEFAULT NULL,
  `total_hours` double DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `username`
--

CREATE TABLE `username` (
  `id` int(11) NOT NULL,
  `username` varchar(80) NOT NULL,
  `email` varchar(120) NOT NULL,
  `password_hash` varchar(128) NOT NULL,
  `role` enum('admin','manager','sales','content','customer') NOT NULL DEFAULT 'customer',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `username`
--

INSERT INTO `username` (`id`, `username`, `email`, `password_hash`, `role`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'customer', 'customer@example.com', '$2y$10$zKpJEhK0IZ5Vzwv2yVRnre1Dwv0dppcS3iNInmlmAFmP1Sk5hJ0cK', 'customer', 1, '2025-07-30 10:47:24', '2025-07-30 10:47:24'),
(2, 'employee', 'employee@example.com', '$2y$10$vmThppiaH.IwnUWqkpQQR.iJNLSww7Egql9GPXoHdOIfNgYk8K.yq', 'sales', 1, '2025-07-30 10:47:35', '2025-07-30 10:51:42'),
(3, 'admin', 'admin@example.com', '$2y$10$tA44lYN0TDedIUTYxBLp7uTCotBSqutFtGgp/kUw6T0oTk5XaMxwa', 'admin', 1, '2025-07-30 10:47:46', '2025-07-30 10:47:46'),
(7, 'test2', 'meryf@gmail.com', '$2y$10$enrZZnz4fZewHGlfzXLnpezZvK64pbPGpzO.ZOxWI2LCSIt0aymyK', 'customer', 1, '2025-07-30 11:49:45', '2025-07-30 11:49:45'),
(11, 'sengsoulee', 'userdddd@demo.com', '$2y$10$5DB6n/06tnW.s2fLQWqLzumMlIYxlOQJtk9igFGQhPWMHuqDkUMZS', 'admin', 1, '2025-07-30 14:28:02', '2025-07-30 14:28:34');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`id`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `employee_id` (`employee_id`);

--
-- Indexes for table `contact_history`
--
ALTER TABLE `contact_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `lead_id` (`lead_id`),
  ADD KEY `employee_id` (`employee_id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `phone` (`phone`),
  ADD UNIQUE KEY `username_id` (`username_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `employee_id` (`employee_id`),
  ADD UNIQUE KEY `username_id` (`username_id`);

--
-- Indexes for table `favorite_plot`
--
ALTER TABLE `favorite_plot`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `customer_id` (`customer_id`,`plot_id`),
  ADD KEY `plot_id` (`plot_id`);

--
-- Indexes for table `lead`
--
ALTER TABLE `lead`
  ADD PRIMARY KEY (`id`),
  ADD KEY `interested_project_id` (`interested_project_id`),
  ADD KEY `interested_plot_id` (`interested_plot_id`),
  ADD KEY `assigned_to` (`assigned_to`),
  ADD KEY `converted_to_customer_id` (`converted_to_customer_id`);

--
-- Indexes for table `leave_request`
--
ALTER TABLE `leave_request`
  ADD PRIMARY KEY (`id`),
  ADD KEY `employee_id` (`employee_id`),
  ADD KEY `approved_by` (`approved_by`);

--
-- Indexes for table `plot`
--
ALTER TABLE `plot`
  ADD PRIMARY KEY (`id`),
  ADD KEY `project_id` (`project_id`);

--
-- Indexes for table `project`
--
ALTER TABLE `project`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `project_zones`
--
ALTER TABLE `project_zones`
  ADD PRIMARY KEY (`id`),
  ADD KEY `project_id` (`project_id`);

--
-- Indexes for table `sale`
--
ALTER TABLE `sale`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `plot_id` (`plot_id`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `employee_id` (`employee_id`);

--
-- Indexes for table `time_record`
--
ALTER TABLE `time_record`
  ADD PRIMARY KEY (`id`),
  ADD KEY `employee_id` (`employee_id`);

--
-- Indexes for table `username`
--
ALTER TABLE `username`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `contact_history`
--
ALTER TABLE `contact_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `favorite_plot`
--
ALTER TABLE `favorite_plot`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lead`
--
ALTER TABLE `lead`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `leave_request`
--
ALTER TABLE `leave_request`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `plot`
--
ALTER TABLE `plot`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `project`
--
ALTER TABLE `project`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `project_zones`
--
ALTER TABLE `project_zones`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `sale`
--
ALTER TABLE `sale`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `time_record`
--
ALTER TABLE `time_record`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `username`
--
ALTER TABLE `username`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `appointment`
--
ALTER TABLE `appointment`
  ADD CONSTRAINT `appointment_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `appointment_ibfk_2` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `contact_history`
--
ALTER TABLE `contact_history`
  ADD CONSTRAINT `contact_history_ibfk_1` FOREIGN KEY (`lead_id`) REFERENCES `lead` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `contact_history_ibfk_2` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `customer`
--
ALTER TABLE `customer`
  ADD CONSTRAINT `customer_ibfk_1` FOREIGN KEY (`username_id`) REFERENCES `username` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `employee`
--
ALTER TABLE `employee`
  ADD CONSTRAINT `employee_ibfk_1` FOREIGN KEY (`username_id`) REFERENCES `username` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `favorite_plot`
--
ALTER TABLE `favorite_plot`
  ADD CONSTRAINT `favorite_plot_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `favorite_plot_ibfk_2` FOREIGN KEY (`plot_id`) REFERENCES `plot` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `lead`
--
ALTER TABLE `lead`
  ADD CONSTRAINT `lead_ibfk_1` FOREIGN KEY (`interested_project_id`) REFERENCES `project` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `lead_ibfk_2` FOREIGN KEY (`interested_plot_id`) REFERENCES `plot` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `lead_ibfk_3` FOREIGN KEY (`assigned_to`) REFERENCES `employee` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `lead_ibfk_4` FOREIGN KEY (`converted_to_customer_id`) REFERENCES `customer` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `leave_request`
--
ALTER TABLE `leave_request`
  ADD CONSTRAINT `leave_request_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `leave_request_ibfk_2` FOREIGN KEY (`approved_by`) REFERENCES `employee` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `plot`
--
ALTER TABLE `plot`
  ADD CONSTRAINT `plot_ibfk_1` FOREIGN KEY (`project_id`) REFERENCES `project` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `project_zones`
--
ALTER TABLE `project_zones`
  ADD CONSTRAINT `project_zones_ibfk_1` FOREIGN KEY (`project_id`) REFERENCES `project` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `sale`
--
ALTER TABLE `sale`
  ADD CONSTRAINT `sale_ibfk_1` FOREIGN KEY (`plot_id`) REFERENCES `plot` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `sale_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `sale_ibfk_3` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `time_record`
--
ALTER TABLE `time_record`
  ADD CONSTRAINT `time_record_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
