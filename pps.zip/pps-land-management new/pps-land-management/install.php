<?php
require_once 'config/config.php';

// SQL script content from the provided file
$sql_script = file_get_contents('ppsapp.sql');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Initialize database
        if (initializeDatabase()) {
            // Get connection to the database
            $pdo = getDBConnection();
            
            // Execute the SQL script
            $pdo->exec($sql_script);
            
            // Create default admin user
            $admin_password = password_hash('admin123', PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO username (username, email, password_hash, role) VALUES (?, ?, ?, ?)");
            $stmt->execute(['admin', 'admin@ppsland.com', $admin_password, 'admin']);
            
            $admin_user_id = $pdo->lastInsertId();
            
            // Create admin employee record
            $stmt = $pdo->prepare("INSERT INTO employee (employee_id, username_id, first_name, last_name, department, position, hire_date, salary) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute(['EMP001', $admin_user_id, 'System', 'Administrator', 'IT', 'Administrator', date('Y-m-d'), 50000]);
            
            $success = "Database installed successfully! Default admin login: admin / admin123";
        } else {
            $error = "Failed to create database connection.";
        }
    } catch (Exception $e) {
        $error = "Installation failed: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Install PPS Land Management System</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 600px; margin: 50px auto; padding: 20px; }
        .container { background: #f9f9f9; padding: 30px; border-radius: 10px; }
        .btn { background: #007bff; color: white; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer; }
        .btn:hover { background: #0056b3; }
        .success { color: green; padding: 10px; background: #d4edda; border-radius: 5px; margin: 10px 0; }
        .error { color: red; padding: 10px; background: #f8d7da; border-radius: 5px; margin: 10px 0; }
    </style>
</head>
<body>
    <div class="container">
        <h1>PPS Land Management System Installation</h1>
        
        <?php if (isset($success)): ?>
            <div class="success"><?php echo $success; ?></div>
            <p><a href="index.php" class="btn">Go to Website</a> <a href="admin/login.php" class="btn">Admin Login</a></p>
        <?php elseif (isset($error)): ?>
            <div class="error"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <p>This will install the PPS Land Management System database and create a default admin user.</p>
        
        <h3>Database Requirements:</h3>
        <ul>
            <li>MySQL/MariaDB server running</li>
            <li>Database user with CREATE privileges</li>
            <li>PHP PDO MySQL extension enabled</li>
        </ul>
        
        <h3>Default Admin Credentials:</h3>
        <ul>
            <li>Username: admin</li>
            <li>Password: admin123</li>
        </ul>
        
        <form method="POST">
            <button type="submit" class="btn">Install Database</button>
        </form>
    </div>
</body>
</html>

