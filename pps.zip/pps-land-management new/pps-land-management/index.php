<?php
// index.php - ໜ້າຫຼັກຂອງເວັບໄຊທ໌ (ອັບເດດໃໝ່ຕາມແບບ Manus.im)
require_once 'config/config.php';
require_once 'includes/project.php';
require_once 'includes/plot.php';

$pdo = getDBConnection();
$projectManager = new Project($pdo);
$plotManager = new Plot($pdo);

$featuredProjects = $projectManager->getFeaturedProjects(6);
$featuredPlots = $plotManager->getFeaturedPlots(8);
$alert = getAlert();
?>
<!DOCTYPE html>
<html lang="lo">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo SITE_NAME; ?> - ການພັດທະນາທີ່ດິນລະດັບພຣີມຽມ</title>
    <meta name="description" content="ຄົ້ນພົບແປງທີ່ດິນລະດັບພຣີມຽມ ແລະ ໂຄງການພັດທະນາດ້ວຍລະບົບການຄຸ້ມຄອງທີ່ດິນ PPS">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/themes.css">
    <link rel="icon" type="image/x-icon" href="assets/images/favicon.ico">
</head>
<body>
    <!-- Modern Header inspired by Manus.im -->
    <header class="header">
        <nav class="nav container">
            <a href="index.php" class="logo">
                <span style="font-weight: 700; font-size: 1.8rem;">PPS Land</span>
            </a>
            <ul class="nav-menu">
                <li><a href="index.php">ໜ້າຫຼັກ</a></li>
                <li><a href="projects.php">ໂຄງການ</a></li>
                <li><a href="plots.php">ແປງທີ່ດິນ</a></li>
                <li><a href="about.php">ກ່ຽວກັບ</a></li>
                <li><a href="contact.php">ຕິດຕໍ່</a></li>
                <?php if (isLoggedIn()): ?>
                    <li><a href="customer/dashboard.php">ແຜງຄວບຄຸມ</a></li>
                    <li><a href="logout.php">ອອກຈາກລະບົບ</a></li>
                <?php else: ?>
                    <li><a href="login.php">ເຂົ້າສູ່ລະບົບ</a></li>
                <?php endif; ?>
            </ul>
            <?php if (!isLoggedIn()): ?>
                <a href="register.php" class="btn-primary" style="margin-left: 20px;">ເລີ່ມຕົ້ນ</a>
            <?php endif; ?>
            <button class="nav-toggle">☰</button>
        </nav>
    </header>

    <!-- Hero Section inspired by Manus.im -->
    <section class="hero">
        <div class="container">
            <div class="hero-content fade-in">
                <h1>ມອບໝາຍໃຫ້ PPS Land</h1>
                <p>PPS Land ແມ່ນລະບົບການຄຸ້ມຄອງທີ່ດິນທີ່ເຊື່ອມຕໍ່ຄວາມຄິດແລະການປະຕິບັດ: ມັນບໍ່ພຽງແຕ່ຄິດ, ມັນສົ່ງມອບຜົນໄດ້ຮັບ. PPS Land ເກັ່ງໃນວຽກງານຕ່າງໆໃນການຄຸ້ມຄອງທີ່ດິນແລະການລົງທຶນ, ເຮັດໃຫ້ທຸກຢ່າງສຳເລັດໃນຂະນະທີ່ທ່ານພັກຜ່ອນ.</p>
                <div class="hero-buttons">
                    <a href="plots.php" class="btn-primary">ທົດລອງ PPS Land</a>
                    <a href="projects.php" class="btn-secondary">ເບິ່ງໂຄງການ</a>
                </div>
            </div>
        </div>
    </section>

    <!-- Alert Messages -->
    <?php if ($alert): ?>
    <div class="container">
        <div class="alert alert-<?php echo $alert['type']; ?> fade-in">
            <?php echo htmlspecialchars($alert['message']); ?>
        </div>
    </div>
    <?php endif; ?>

    <!-- Use Cases Section inspired by Manus.im -->
    <section class="section">
        <div class="container">
            <div class="text-center slide-up">
                <p style="color: var(--text-secondary); margin-bottom: 1rem;">ໂຄງການເດັ່ນ</p>
                <h2 style="font-size: 2.5rem; font-weight: 700; margin-bottom: 1rem;">ສຳຫຼວດໂຄງການຈາກຄໍເລັກຊັນທາງການຂອງພວກເຮົາ</h2>
                <p style="color: var(--text-secondary); margin-bottom: 3rem; max-width: 600px; margin-left: auto; margin-right: auto;">ຮຽນຮູ້ວິທີທີ່ PPS Land ຈັດການໂຄງການທີ່ດິນໃນໂລກແທ້ຜ່ານການສະແດງແບບຂັ້ນຕອນ</p>
            </div>

            <!-- Featured Projects Grid -->
            <div class="grid grid-3">
                <?php foreach ($featuredProjects as $project): ?>
                <div class="card fade-in">
                    <div class="project-image">
                        <?php if ($project['master_plan_url']): ?>
                            <img src="<?php echo htmlspecialchars($project['master_plan_url']); ?>" 
                                 alt="<?php echo htmlspecialchars($project['name']); ?>"
                                 style="width: 100%; height: 200px; object-fit: cover; border-radius: 8px;">
                        <?php else: ?>
                            <div style="width: 100%; height: 200px; background: var(--gradient-secondary); border-radius: 8px; display: flex; align-items: center; justify-content: center; color: var(--text-secondary);">
                                📍 ໂຄງການທີ່ດິນ
                            </div>
                        <?php endif; ?>
                    </div>
                    <div style="padding: 20px 0;">
                        <h3 style="font-size: 1.25rem; font-weight: 600; margin-bottom: 0.5rem;">
                            <?php echo htmlspecialchars($project['name']); ?>
                        </h3>
                        <p style="color: var(--text-secondary); margin-bottom: 1rem; font-size: 0.9rem;">
                            📍 <?php echo htmlspecialchars($project['location']); ?>
                        </p>
                        <p style="color: var(--text-secondary); margin-bottom: 1.5rem; line-height: 1.5;">
                            <?php echo htmlspecialchars(substr($project['description'], 0, 100)) . '...'; ?>
                        </p>
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            <span style="font-size: 0.85rem; color: var(--text-secondary);">
                                📊 <?php echo $project['total_plots']; ?> ແປງ
                            </span>
                            <a href="projects.php?id=<?php echo $project['id']; ?>" class="btn-secondary" style="padding: 8px 16px; font-size: 0.85rem;">
                                ເບິ່ງລາຍລະອຽດ
                            </a>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <div class="text-center" style="margin-top: 3rem;">
                <a href="projects.php" class="btn-primary">ສຳຫຼວດໂຄງການເພີ່ມເຕີມ</a>
            </div>
        </div>
    </section>

    <!-- Featured Plots Section -->
    <section class="section" style="background: var(--surface-color);">
        <div class="container">
            <div class="text-center slide-up">
                <h2 style="font-size: 2.5rem; font-weight: 700; margin-bottom: 1rem;">ສຳຫຼວດແປງທີ່ດິນທີ່ໂດດເດັ່ນຈາກຜູ້ໃຊ້ PPS Land</h2>
                <p style="color: var(--text-secondary); margin-bottom: 3rem;">ແປງທີ່ດິນແລະໂຄງການທັງໝົດທີ່ສະແດງໃນຊຸມຊົນແມ່ນຖືກແບ່ງປັນໂດຍສະໝັກໃຈໂດຍຜູ້ໃຊ້</p>
            </div>

            <!-- Featured Plots Grid -->
            <div class="grid grid-4">
                <?php foreach ($featuredPlots as $plot): ?>
                <div class="card fade-in">
                    <div class="plot-image">
                        <?php if ($plot['image_url']): ?>
                            <img src="<?php echo htmlspecialchars($plot['image_url']); ?>" 
                                 alt="ແປງ <?php echo htmlspecialchars($plot['plot_number']); ?>"
                                 style="width: 100%; height: 150px; object-fit: cover; border-radius: 8px;">
                        <?php else: ?>
                            <div style="width: 100%; height: 150px; background: var(--gradient-secondary); border-radius: 8px; display: flex; align-items: center; justify-content: center; color: var(--text-secondary);">
                                🏞️ ແປງທີ່ດິນ
                            </div>
                        <?php endif; ?>
                    </div>
                    <div style="padding: 16px 0;">
                        <h4 style="font-size: 1.1rem; font-weight: 600; margin-bottom: 0.5rem;">
                            ແປງ <?php echo htmlspecialchars($plot['plot_number']); ?>
                        </h4>
                        <p style="color: var(--text-secondary); margin-bottom: 0.5rem; font-size: 0.85rem;">
                            📐 <?php echo number_format($plot['area']); ?> ຕ.ມ.
                        </p>
                        <p style="color: var(--text-secondary); margin-bottom: 1rem; font-size: 0.85rem;">
                            📊 ສະຖານະ: <?php echo $plot['status'] == 'available' ? 'ວ່າງ' : ($plot['status'] == 'sold' ? 'ຂາຍແລ້ວ' : 'ຈອງແລ້ວ'); ?>
                        </p>
                        <a href="plots.php?id=<?php echo $plot['id']; ?>" class="btn-secondary" style="padding: 6px 12px; font-size: 0.8rem; width: 100%; text-align: center; display: block;">
                            ເບິ່ງລາຍລະອຽດ
                        </a>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- Search Section -->
    <section class="section">
        <div class="container">
            <div class="card" style="max-width: 800px; margin: 0 auto; padding: 40px;">
                <h2 style="text-align: center; margin-bottom: 2rem; font-size: 2rem; font-weight: 700;">ຊອກຫາອະສັງຫາລິມະສັບທີ່ເໝາະສົມຂອງທ່ານ</h2>
                <form id="searchForm" action="search.php" method="GET">
                    <div class="grid grid-2" style="margin-bottom: 1.5rem;">
                        <div class="form-group">
                            <label class="form-label">ປະເພດ</label>
                            <select name="type" class="form-input">
                                <option value="">ທັງໝົດ</option>
                                <option value="residential">ທີ່ຢູ່ອາໄສ</option>
                                <option value="commercial">ການຄ້າ</option>
                                <option value="industrial">ອຸດສາຫະກຳ</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="form-label">ສະຖານທີ່</label>
                            <input type="text" name="location" class="form-input" placeholder="ປ້ອນສະຖານທີ່...">
                        </div>
                    </div>
                    <div class="grid grid-2" style="margin-bottom: 2rem;">
                        <div class="form-group">
                            <label class="form-label">ຂະໜາດຕໍ່າສຸດ (ຕ.ມ.)</label>
                            <input type="number" name="min_area" class="form-input" placeholder="0">
                        </div>
                        <div class="form-group">
                            <label class="form-label">ຂະໜາດສູງສຸດ (ຕ.ມ.)</label>
                            <input type="number" name="max_area" class="form-input" placeholder="ບໍ່ຈຳກັດ">
                        </div>
                    </div>
                    <div class="text-center">
                        <button type="submit" class="btn-primary" style="padding: 12px 32px;">🔍 ຄົ້ນຫາ</button>
                    </div>
                </form>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer style="background: var(--surface-color); padding: 60px 0 20px; border-top: 1px solid var(--border-color);">
        <div class="container">
            <div class="grid grid-4" style="margin-bottom: 40px;">
                <div>
                    <h3 style="margin-bottom: 1rem; font-weight: 600;">PPS Land</h3>
                    <p style="color: var(--text-secondary); line-height: 1.6;">ລະບົບການຄຸ້ມຄອງທີ່ດິນທີ່ທັນສະໄໝ ສຳລັບການລົງທຶນແລະການພັດທະນາທີ່ດິນ</p>
                </div>
                <div>
                    <h4 style="margin-bottom: 1rem; font-weight: 600;">ໂຄງການ</h4>
                    <ul style="list-style: none;">
                        <li style="margin-bottom: 0.5rem;"><a href="projects.php" style="color: var(--text-secondary); text-decoration: none;">ໂຄງການທັງໝົດ</a></li>
                        <li style="margin-bottom: 0.5rem;"><a href="#" style="color: var(--text-secondary); text-decoration: none;">ທີ່ຢູ່ອາໄສ</a></li>
                        <li style="margin-bottom: 0.5rem;"><a href="#" style="color: var(--text-secondary); text-decoration: none;">ການຄ້າ</a></li>
                    </ul>
                </div>
                <div>
                    <h4 style="margin-bottom: 1rem; font-weight: 600;">ບໍລິການ</h4>
                    <ul style="list-style: none;">
                        <li style="margin-bottom: 0.5rem;"><a href="#" style="color: var(--text-secondary); text-decoration: none;">ການພັດທະນາທີ່ດິນ</a></li>
                        <li style="margin-bottom: 0.5rem;"><a href="#" style="color: var(--text-secondary); text-decoration: none;">ການລົງທຶນ</a></li>
                        <li style="margin-bottom: 0.5rem;"><a href="#" style="color: var(--text-secondary); text-decoration: none;">ການປຶກສາ</a></li>
                    </ul>
                </div>
                <div>
                    <h4 style="margin-bottom: 1rem; font-weight: 600;">ຕິດຕາມພວກເຮົາ</h4>
                    <div style="display: flex; gap: 1rem;">
                        <a href="#" style="color: var(--text-secondary); font-size: 1.5rem;">📘</a>
                        <a href="#" style="color: var(--text-secondary); font-size: 1.5rem;">🐦</a>
                        <a href="#" style="color: var(--text-secondary); font-size: 1.5rem;">💼</a>
                        <a href="#" style="color: var(--text-secondary); font-size: 1.5rem;">📷</a>
                    </div>
                </div>
            </div>
            <div style="text-align: center; padding-top: 20px; border-top: 1px solid var(--border-color); color: var(--text-secondary);">
                <p>&copy; <?php echo date("Y"); ?> PPS Land Management System. ສະຫງວນລິຂະສິດທັງໝົດ.</p>
            </div>
        </div>
    </footer>

    <!-- JavaScript Files -->
    <script src="assets/js/main.js"></script>
    <script src="assets/js/theme-switcher.js"></script>
    <script>
        // Set user login status for JavaScript
        var PPS = window.PPS || {};
        PPS.userLoggedIn = <?php echo isLoggedIn() ? 'true' : 'false'; ?>;
        
        // Initialize with projects data
        document.addEventListener('DOMContentLoaded', function() {
            const projects = <?php echo json_encode($featuredProjects); ?>;
            
            // Add smooth scrolling
            document.querySelectorAll('a[href^="#"]').forEach(anchor => {
                anchor.addEventListener('click', function (e) {
                    e.preventDefault();
                    document.querySelector(this.getAttribute('href')).scrollIntoView({
                        behavior: 'smooth'
                    });
                });
            });
            
            // Add animation on scroll
            const observerOptions = {
                threshold: 0.1,
                rootMargin: '0px 0px -50px 0px'
            };
            
            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.style.opacity = '1';
                        entry.target.style.transform = 'translateY(0)';
                    }
                });
            }, observerOptions);
            
            document.querySelectorAll('.fade-in, .slide-up').forEach(el => {
                el.style.opacity = '0';
                el.style.transform = 'translateY(20px)';
                el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
                observer.observe(el);
            });
        });
    </script>
</body>
</html>

