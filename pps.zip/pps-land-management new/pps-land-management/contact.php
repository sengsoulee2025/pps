<?php
// contact.php - Modern Contact Page inspired by Manus.im
require_once 'config/config.php';
require_once 'includes/contact.php';

// Get alert messages
$alert = getAlert();

// Handle contact form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_contact'])) {
    $contact = new Contact();
    
    // Validate required fields
    $errors = [];
    if (empty($_POST['name'])) $errors[] = 'ກະລຸນາປ້ອນຊື່ຂອງທ່ານ';
    if (empty($_POST['email'])) $errors[] = 'ກະລຸນາປ້ອນອີເມວຂອງທ່ານ';
    if (empty($_POST['message'])) $errors[] = 'ກະລຸນາປ້ອນຂໍ້ຄວາມຂອງທ່ານ';
    
    if (empty($errors)) {
        $contact_data = [
            'name' => trim($_POST['name']),
            'email' => trim($_POST['email']),
            'phone' => trim($_POST['phone']) ?: null,
            'subject' => trim($_POST['subject']) ?: 'ຂໍ້ຄວາມທົ່ວໄປ',
            'message' => trim($_POST['message'])
        ];
        
        if ($contact->addContact($contact_data)) {
            setAlert('success', 'ຂໍຂອບໃຈສຳລັບຂໍ້ຄວາມຂອງທ່ານ! ພວກເຮົາຈະຕິດຕໍ່ກັບທ່ານໃນໄວໆນີ້.');
            header('Location: contact.php');
            exit();
        } else {
            setAlert('error', 'ຂໍອະໄພ, ມີຂໍ້ຜິດພາດໃນການສົ່ງຂໍ້ຄວາມຂອງທ່ານ. ກະລຸນາລອງໃໝ່ອີກຄັ້ງ.');
        }
    } else {
        setAlert('error', implode('<br>', $errors));
    }
}
?>
<!DOCTYPE html>
<html lang="lo">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ຕິດຕໍ່ພວກເຮົາ - <?php echo SITE_NAME; ?></title>
    <meta name="description" content="ຕິດຕໍ່ທີມງານ PPS Land ເພື່ອສອບຖາມຂໍ້ມູນກ່ຽວກັບການລົງທຶນທີ່ດິນ ແລະ ໂຄງການພັດທະນາ">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/themes.css">
    <link rel="icon" type="image/x-icon" href="assets/images/favicon.ico">
</head>
<body>
    <!-- Modern Header -->
    <header class="header">
        <nav class="nav container">
            <a href="index.php" class="logo">
                <span style="font-weight: 700; font-size: 1.8rem;">PPS Land</span>
            </a>
            <ul class="nav-menu">
                <li><a href="index.php">ໜ້າຫຼັກ</a></li>
                <li><a href="projects.php">ໂຄງການ</a></li>
                <li><a href="plots.php">ແປງທີ່ດິນ</a></li>
                <li><a href="about.php">ກ່ຽວກັບ</a></li>
                <li><a href="contact.php" style="color: var(--accent-color);">ຕິດຕໍ່</a></li>
                <?php if (isLoggedIn()): ?>
                    <li><a href="customer/dashboard.php">ແຜງຄວບຄຸມ</a></li>
                    <li><a href="logout.php">ອອກຈາກລະບົບ</a></li>
                <?php else: ?>
                    <li><a href="login.php">ເຂົ້າສູ່ລະບົບ</a></li>
                <?php endif; ?>
            </ul>
            <?php if (!isLoggedIn()): ?>
                <a href="register.php" class="btn-primary" style="margin-left: 20px;">ເລີ່ມຕົ້ນ</a>
            <?php endif; ?>
            <button class="nav-toggle">☰</button>
        </nav>
    </header>

    <!-- Hero Section -->
    <section class="hero" style="padding: 120px 0 80px; background: var(--gradient-primary);">
        <div class="container">
            <div class="hero-content fade-in" style="text-align: center; max-width: 800px; margin: 0 auto;">
                <h1 style="font-size: 3rem; font-weight: 700; margin-bottom: 1.5rem; color: white;">ຕິດຕໍ່ພວກເຮົາ</h1>
                <p style="font-size: 1.2rem; color: rgba(255,255,255,0.9); line-height: 1.6;">
                    ພວກເຮົາພ້ອມໃຫ້ຄຳປຶກສາແລະຕອບຄຳຖາມກ່ຽວກັບການລົງທຶນທີ່ດິນ ແລະ ໂຄງການພັດທະນາຂອງພວກເຮົາ
                </p>
            </div>
        </div>
    </section>

    <!-- Alert Messages -->
    <?php if ($alert): ?>
    <div class="container" style="margin-top: -40px; position: relative; z-index: 10;">
        <div class="alert alert-<?php echo $alert['type']; ?> fade-in">
            <?php echo $alert['message']; ?>
        </div>
    </div>
    <?php endif; ?>

    <!-- Contact Section -->
    <section class="section">
        <div class="container">
            <div class="grid grid-2" style="gap: 60px; align-items: start;">
                
                <!-- Contact Form -->
                <div class="slide-up">
                    <div class="card" style="padding: 40px;">
                        <h2 style="font-size: 2rem; font-weight: 700; margin-bottom: 1rem; color: var(--text-primary);">ສົ່ງຂໍ້ຄວາມຫາພວກເຮົາ</h2>
                        <p style="color: var(--text-secondary); margin-bottom: 2rem; line-height: 1.6;">
                            ຖ້າທ່ານມີຄຳຖາມ ຫຼື ຕ້ອງການຂໍ້ມູນເພີ່ມເຕີມ, ກະລຸນາຕື່ມແບບຟອມຂ້າງລຸ່ມນີ້ ແລະ ພວກເຮົາຈະຕິດຕໍ່ກັບທ່ານໃນໄວໆນີ້
                        </p>
                        
                        <form method="POST" action="contact.php" id="contactForm">
                            <div class="form-group" style="margin-bottom: 24px;">
                                <label class="form-label" for="name">ຊື່ເຕັມ *</label>
                                <input type="text" id="name" name="name" class="form-input" required 
                                       placeholder="ປ້ອນຊື່ເຕັມຂອງທ່ານ"
                                       value="<?php echo isset($_POST['name']) ? htmlspecialchars($_POST['name']) : ''; ?>">
                            </div>
                            
                            <div class="grid grid-2" style="gap: 20px; margin-bottom: 24px;">
                                <div class="form-group">
                                    <label class="form-label" for="email">ອີເມວ *</label>
                                    <input type="email" id="email" name="email" class="form-input" required 
                                           placeholder="your@email.com"
                                           value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
                                </div>
                                
                                <div class="form-group">
                                    <label class="form-label" for="phone">ເບີໂທ</label>
                                    <input type="tel" id="phone" name="phone" class="form-input" 
                                           placeholder="020 1234 5678"
                                           value="<?php echo isset($_POST['phone']) ? htmlspecialchars($_POST['phone']) : ''; ?>">
                                </div>
                            </div>
                            
                            <div class="form-group" style="margin-bottom: 24px;">
                                <label class="form-label" for="subject">ຫົວຂໍ້</label>
                                <select id="subject" name="subject" class="form-input">
                                    <option value="ຂໍ້ມູນທົ່ວໄປ">ຂໍ້ມູນທົ່ວໄປ</option>
                                    <option value="ສອບຖາມໂຄງການ">ສອບຖາມໂຄງການ</option>
                                    <option value="ສອບຖາມແປງທີ່ດິນ">ສອບຖາມແປງທີ່ດິນ</option>
                                    <option value="ການລົງທຶນ">ການລົງທຶນ</option>
                                    <option value="ການຊື້ຂາຍ">ການຊື້ຂາຍ</option>
                                    <option value="ບໍລິການລູກຄ້າ">ບໍລິການລູກຄ້າ</option>
                                    <option value="ອື່ນໆ">ອື່ນໆ</option>
                                </select>
                            </div>
                            
                            <div class="form-group" style="margin-bottom: 32px;">
                                <label class="form-label" for="message">ຂໍ້ຄວາມ *</label>
                                <textarea id="message" name="message" class="form-input" rows="6" required 
                                          placeholder="ບອກພວກເຮົາກ່ຽວກັບຄຳຖາມ ຫຼື ຄວາມຕ້ອງການຂອງທ່ານ..."><?php echo isset($_POST['message']) ? htmlspecialchars($_POST['message']) : ''; ?></textarea>
                            </div>
                            
                            <button type="submit" name="submit_contact" class="btn-primary" style="width: 100%; padding: 16px; font-size: 1.1rem;">
                                <i class="fas fa-paper-plane" style="margin-right: 8px;"></i>
                                ສົ່ງຂໍ້ຄວາມ
                            </button>
                        </form>
                    </div>
                </div>

                <!-- Contact Information -->
                <div class="slide-up">
                    <div style="margin-bottom: 40px;">
                        <h2 style="font-size: 2rem; font-weight: 700; margin-bottom: 1rem; color: var(--text-primary);">ຂໍ້ມູນການຕິດຕໍ່</h2>
                        <p style="color: var(--text-secondary); margin-bottom: 2rem; line-height: 1.6;">
                            ທ່ານສາມາດຕິດຕໍ່ພວກເຮົາໄດ້ຫຼາຍວິທີ. ພວກເຮົາພ້ອມໃຫ້ບໍລິການທຸກມື້ເພື່ອຊ່ວຍເຫຼືອທ່ານ
                        </p>
                    </div>

                    <!-- Contact Cards -->
                    <div style="display: flex; flex-direction: column; gap: 24px;">
                        <div class="card" style="padding: 24px;">
                            <div style="display: flex; align-items: center; gap: 16px;">
                                <div style="width: 50px; height: 50px; background: var(--gradient-primary); border-radius: 12px; display: flex; align-items: center; justify-content: center; color: white; font-size: 1.2rem;">
                                    <i class="fas fa-phone"></i>
                                </div>
                                <div>
                                    <h3 style="font-weight: 600; margin-bottom: 4px; color: var(--text-primary);">ໂທຫາພວກເຮົາ</h3>
                                    <p style="color: var(--text-secondary); margin-bottom: 4px;">+856 20 1234 5678</p>
                                    <p style="color: var(--text-secondary); font-size: 0.9rem;">ຈັນ - ສຸກ: 8:00 - 17:00</p>
                                </div>
                            </div>
                        </div>

                        <div class="card" style="padding: 24px;">
                            <div style="display: flex; align-items: center; gap: 16px;">
                                <div style="width: 50px; height: 50px; background: var(--gradient-secondary); border-radius: 12px; display: flex; align-items: center; justify-content: center; color: white; font-size: 1.2rem;">
                                    <i class="fas fa-envelope"></i>
                                </div>
                                <div>
                                    <h3 style="font-weight: 600; margin-bottom: 4px; color: var(--text-primary);">ສົ່ງອີເມວ</h3>
                                    <p style="color: var(--text-secondary); margin-bottom: 4px;">info@ppsland.com</p>
                                    <p style="color: var(--text-secondary); font-size: 0.9rem;">ຕອບກັບພາຍໃນ 24 ຊົ່ວໂມງ</p>
                                </div>
                            </div>
                        </div>

                        <div class="card" style="padding: 24px;">
                            <div style="display: flex; align-items: center; gap: 16px;">
                                <div style="width: 50px; height: 50px; background: var(--gradient-accent); border-radius: 12px; display: flex; align-items: center; justify-content: center; color: white; font-size: 1.2rem;">
                                    <i class="fas fa-map-marker-alt"></i>
                                </div>
                                <div>
                                    <h3 style="font-weight: 600; margin-bottom: 4px; color: var(--text-primary);">ມາຢ້ຽມຢາມພວກເຮົາ</h3>
                                    <p style="color: var(--text-secondary); margin-bottom: 4px;">ບ້ານ ໂພນໄຊ, ເມືອງ ສີໂຄດຕະບອງ</p>
                                    <p style="color: var(--text-secondary); font-size: 0.9rem;">ນະຄອນຫຼວງວຽງຈັນ, ລາວ</p>
                                </div>
                            </div>
                        </div>

                        <div class="card" style="padding: 24px;">
                            <div style="display: flex; align-items: center; gap: 16px;">
                                <div style="width: 50px; height: 50px; background: var(--primary-color); border-radius: 12px; display: flex; align-items: center; justify-content: center; color: white; font-size: 1.2rem;">
                                    <i class="fas fa-clock"></i>
                                </div>
                                <div>
                                    <h3 style="font-weight: 600; margin-bottom: 4px; color: var(--text-primary);">ເວລາເຮັດວຽກ</h3>
                                    <p style="color: var(--text-secondary); margin-bottom: 4px;">ຈັນ - ສຸກ: 8:00 - 17:00</p>
                                    <p style="color: var(--text-secondary); font-size: 0.9rem;">ເສົາ: 8:00 - 12:00</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Social Media -->
                    <div style="margin-top: 40px;">
                        <h3 style="font-weight: 600; margin-bottom: 16px; color: var(--text-primary);">ຕິດຕາມພວກເຮົາ</h3>
                        <div style="display: flex; gap: 12px;">
                            <a href="#" style="width: 40px; height: 40px; background: var(--surface-color); border: 1px solid var(--border-color); border-radius: 8px; display: flex; align-items: center; justify-content: center; color: var(--text-secondary); text-decoration: none; transition: all 0.3s ease;">
                                <i class="fab fa-facebook-f"></i>
                            </a>
                            <a href="#" style="width: 40px; height: 40px; background: var(--surface-color); border: 1px solid var(--border-color); border-radius: 8px; display: flex; align-items: center; justify-content: center; color: var(--text-secondary); text-decoration: none; transition: all 0.3s ease;">
                                <i class="fab fa-twitter"></i>
                            </a>
                            <a href="#" style="width: 40px; height: 40px; background: var(--surface-color); border: 1px solid var(--border-color); border-radius: 8px; display: flex; align-items: center; justify-content: center; color: var(--text-secondary); text-decoration: none; transition: all 0.3s ease;">
                                <i class="fab fa-linkedin-in"></i>
                            </a>
                            <a href="#" style="width: 40px; height: 40px; background: var(--surface-color); border: 1px solid var(--border-color); border-radius: 8px; display: flex; align-items: center; justify-content: center; color: var(--text-secondary); text-decoration: none; transition: all 0.3s ease;">
                                <i class="fab fa-instagram"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- FAQ Section -->
    <section class="section" style="background: var(--surface-color);">
        <div class="container">
            <div class="text-center slide-up" style="margin-bottom: 3rem;">
                <h2 style="font-size: 2.5rem; font-weight: 700; margin-bottom: 1rem;">ຄຳຖາມທີ່ພົບເລື້ອຍ</h2>
                <p style="color: var(--text-secondary);">ຄຳຕອບສຳລັບຄຳຖາມທີ່ລູກຄ້າຖາມເລື້ອຍໆ</p>
            </div>

            <div style="max-width: 800px; margin: 0 auto;">
                <div class="faq-item" style="margin-bottom: 20px;">
                    <div class="card" style="padding: 24px;">
                        <h3 style="font-weight: 600; margin-bottom: 12px; color: var(--text-primary);">ຂ້ອຍສາມາດລົງທຶນໃນທີ່ດິນໄດ້ແນວໃດ?</h3>
                        <p style="color: var(--text-secondary); line-height: 1.6;">ທ່ານສາມາດເລີ່ມຕົ້ນໂດຍການສຳຫຼວດໂຄງການແລະແປງທີ່ດິນຂອງພວກເຮົາ, ຫຼັງຈາກນັ້ນຕິດຕໍ່ທີມງານເພື່ອນັດໝາຍເບິ່ງທີ່ດິນຈິງ ແລະ ປຶກສາລາຍລະອຽດການລົງທຶນ.</p>
                    </div>
                </div>

                <div class="faq-item" style="margin-bottom: 20px;">
                    <div class="card" style="padding: 24px;">
                        <h3 style="font-weight: 600; margin-bottom: 12px; color: var(--text-primary);">ມີການຮັບປະກັນຜົນຕອບແທນບໍ?</h3>
                        <p style="color: var(--text-secondary); line-height: 1.6;">ພວກເຮົາໃຫ້ຄຳແນະນຳແລະການວິເຄາະຕະຫຼາດທີ່ລະອຽດ, ແຕ່ການລົງທຶນທີ່ດິນມີຄວາມສ່ຽງຕາມທຳມະຊາດ. ພວກເຮົາຈະໃຫ້ຂໍ້ມູນທີ່ຄົບຖ້ວນເພື່ອໃຫ້ທ່ານຕັດສິນໃຈໄດ້ຢ່າງມີຂໍ້ມູນ.</p>
                    </div>
                </div>

                <div class="faq-item" style="margin-bottom: 20px;">
                    <div class="card" style="padding: 24px;">
                        <h3 style="font-weight: 600; margin-bottom: 12px; color: var(--text-primary);">ຂະບວນການຊື້ຂາຍເປັນແນວໃດ?</h3>
                        <p style="color: var(--text-secondary); line-height: 1.6;">ຂະບວນການລວມມີ: ການເລືອກແປງທີ່ດິນ, ການກວດສອບເອກະສານ, ການເຊັນສັນຍາ, ການຈ່າຍເງິນ, ແລະ ການໂອນເອກະສານກຳມະສິດ. ທີມງານຂອງພວກເຮົາຈະແນະນຳທ່ານຕະຫຼອດຂະບວນການ.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer style="background: var(--surface-color); padding: 60px 0 20px; border-top: 1px solid var(--border-color);">
        <div class="container">
            <div class="grid grid-4" style="margin-bottom: 40px;">
                <div>
                    <h3 style="margin-bottom: 1rem; font-weight: 600;">PPS Land</h3>
                    <p style="color: var(--text-secondary); line-height: 1.6;">ລະບົບການຄຸ້ມຄອງທີ່ດິນທີ່ທັນສະໄໝ ສຳລັບການລົງທຶນແລະການພັດທະນາທີ່ດິນ</p>
                </div>
                <div>
                    <h4 style="margin-bottom: 1rem; font-weight: 600;">ໂຄງການ</h4>
                    <ul style="list-style: none;">
                        <li style="margin-bottom: 0.5rem;"><a href="projects.php" style="color: var(--text-secondary); text-decoration: none;">ໂຄງການທັງໝົດ</a></li>
                        <li style="margin-bottom: 0.5rem;"><a href="#" style="color: var(--text-secondary); text-decoration: none;">ທີ່ຢູ່ອາໄສ</a></li>
                        <li style="margin-bottom: 0.5rem;"><a href="#" style="color: var(--text-secondary); text-decoration: none;">ການຄ້າ</a></li>
                    </ul>
                </div>
                <div>
                    <h4 style="margin-bottom: 1rem; font-weight: 600;">ບໍລິການ</h4>
                    <ul style="list-style: none;">
                        <li style="margin-bottom: 0.5rem;"><a href="#" style="color: var(--text-secondary); text-decoration: none;">ການພັດທະນາທີ່ດິນ</a></li>
                        <li style="margin-bottom: 0.5rem;"><a href="#" style="color: var(--text-secondary); text-decoration: none;">ການລົງທຶນ</a></li>
                        <li style="margin-bottom: 0.5rem;"><a href="#" style="color: var(--text-secondary); text-decoration: none;">ການປຶກສາ</a></li>
                    </ul>
                </div>
                <div>
                    <h4 style="margin-bottom: 1rem; font-weight: 600;">ຕິດຕາມພວກເຮົາ</h4>
                    <div style="display: flex; gap: 1rem;">
                        <a href="#" style="color: var(--text-secondary); font-size: 1.5rem;">📘</a>
                        <a href="#" style="color: var(--text-secondary); font-size: 1.5rem;">🐦</a>
                        <a href="#" style="color: var(--text-secondary); font-size: 1.5rem;">💼</a>
                        <a href="#" style="color: var(--text-secondary); font-size: 1.5rem;">📷</a>
                    </div>
                </div>
            </div>
            <div style="text-align: center; padding-top: 20px; border-top: 1px solid var(--border-color); color: var(--text-secondary);">
                <p>&copy; <?php echo date("Y"); ?> PPS Land Management System. ສະຫງວນລິຂະສິດທັງໝົດ.</p>
            </div>
        </div>
    </footer>

    <!-- JavaScript -->
    <script src="assets/js/main.js"></script>
    <script src="assets/js/theme-switcher.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Form validation
            const form = document.getElementById('contactForm');
            if (form) {
                form.addEventListener('submit', function(e) {
                    const name = document.getElementById('name').value.trim();
                    const email = document.getElementById('email').value.trim();
                    const message = document.getElementById('message').value.trim();
                    
                    if (!name || !email || !message) {
                        e.preventDefault();
                        alert('ກະລຸນາຕື່ມຂໍ້ມູນທີ່ຈຳເປັນໃຫ້ຄົບຖ້ວນ');
                        return false;
                    }
                    
                    // Email validation
                    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                    if (!emailRegex.test(email)) {
                        e.preventDefault();
                        alert('ກະລຸນາປ້ອນອີເມວທີ່ຖືກຕ້ອງ');
                        return false;
                    }
                });
            }
            
            // Animation on scroll
            const observerOptions = {
                threshold: 0.1,
                rootMargin: '0px 0px -50px 0px'
            };
            
            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.style.opacity = '1';
                        entry.target.style.transform = 'translateY(0)';
                    }
                });
            }, observerOptions);
            
            document.querySelectorAll('.fade-in, .slide-up').forEach(el => {
                el.style.opacity = '0';
                el.style.transform = 'translateY(20px)';
                el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
                observer.observe(el);
            });
        });
    </script>
</body>
</html>

