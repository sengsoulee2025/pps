-- Database Updates for PPS Land Management System
-- Contact Messages Table

CREATE TABLE IF NOT EXISTS `contact_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `subject` varchar(255) DEFAULT 'ຂໍ້ຄວາມທົ່ວໄປ',
  `message` text NOT NULL,
  `status` enum('new','read','replied','archived') DEFAULT 'new',
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `admin_notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Add contact_message_id to lead table if not exists
ALTER TABLE `lead` 
ADD COLUMN `contact_message_id` int(11) DEFAULT NULL AFTER `notes`,
ADD KEY `idx_contact_message` (`contact_message_id`);

-- Add foreign key constraint if contact_messages table exists
-- ALTER TABLE `lead` 
-- ADD CONSTRAINT `fk_lead_contact_message` 
-- FOREIGN KEY (`contact_message_id`) REFERENCES `contact_messages` (`id`) 
-- ON DELETE SET NULL ON UPDATE CASCADE;

-- Update existing lead table structure if needed
ALTER TABLE `lead` 
MODIFY COLUMN `email` varchar(255) DEFAULT NULL,
MODIFY COLUMN `phone` varchar(20) DEFAULT NULL,
MODIFY COLUMN `source` varchar(100) DEFAULT NULL,
MODIFY COLUMN `status` enum('new','contacted','qualified','proposal','negotiation','converted','lost') DEFAULT 'new',
MODIFY COLUMN `priority` enum('low','medium','high','urgent') DEFAULT 'medium';

-- Add indexes for better performance
ALTER TABLE `lead` 
ADD KEY `idx_status` (`status`),
ADD KEY `idx_priority` (`priority`),
ADD KEY `idx_source` (`source`),
ADD KEY `idx_created_at` (`created_at`);

-- Contact History Table (if not exists)
CREATE TABLE IF NOT EXISTS `contact_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lead_id` int(11) NOT NULL,
  `employee_id` int(11) DEFAULT NULL,
  `contact_type` enum('phone','email','meeting','sms','other') DEFAULT 'phone',
  `contact_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `duration_minutes` int(11) DEFAULT NULL,
  `outcome` enum('successful','no_answer','busy','callback_requested','not_interested','interested') DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `next_action` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_lead_id` (`lead_id`),
  KEY `idx_employee_id` (`employee_id`),
  KEY `idx_contact_date` (`contact_date`),
  CONSTRAINT `fk_contact_history_lead` FOREIGN KEY (`lead_id`) REFERENCES `lead` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_contact_history_employee` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert sample contact messages for testing
INSERT INTO `contact_messages` (`name`, `email`, `phone`, `subject`, `message`, `status`) VALUES
('ສົມຊາຍ ວົງສະຫວັນ', 'somchai@example.com', '020 1234 5678', 'ສອບຖາມໂຄງການ', 'ຂ້ອຍສົນໃຈໂຄງການພັດທະນາທີ່ດິນຂອງທ່ານ ຢາກໄດ້ຂໍ້ມູນເພີ່ມເຕີມ', 'new'),
('ນາງ ມາລີ ພົມມະວົງ', 'malee@example.com', '020 9876 5432', 'ການລົງທຶນ', 'ຢາກຮູ້ວ່າການລົງທຶນໃນທີ່ດິນມີຄວາມສ່ຽງແນວໃດ ແລະ ຜົນຕອບແທນເປັນແນວໃດ', 'read'),
('ທ້າວ ບຸນມີ ສີວິໄລ', 'bounmee@example.com', '020 5555 1234', 'ນັດໝາຍເບິ່ງທີ່ດິນ', 'ຢາກນັດໝາຍເບິ່ງແປງທີ່ດິນໃນໂຄງການ ABC ໃນວັນເສົາໜ້າ', 'replied');

-- Update lead table with sample data linked to contact messages
UPDATE `lead` SET `contact_message_id` = 1 WHERE `id` = 1;
UPDATE `lead` SET `contact_message_id` = 2 WHERE `id` = 2;
UPDATE `lead` SET `contact_message_id` = 3 WHERE `id` = 3;

