<?php
// about.php - ໜ້າກ່ຽວກັບພວກເຮົາ
// ໄຟລ໌ນີ້ໃຫ້ຂໍ້ມູນກ່ຽວກັບບໍລິສັດ, ຄຸນຄ່າຫຼັກ, ແລະທີມງານ.

// ລວມເອົາໄຟລ໌ການຕັ້ງຄ່າ
require_once 'config/config.php'; // ໄຟລ໌ການຕັ້ງຄ່າລະບົບ

// ດຶງຂໍ້ຄວາມແຈ້ງເຕືອນ (ຖ້າມີ)
// $alert: ຕົວແປນີ້ເກັບຂໍ້ຄວາມແຈ້ງເຕືອນທີ່ອາດຈະຖືກຕັ້ງໄວ້ໃນ session
$alert = getAlert();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ກ່ຽວກັບພວກເຮົາ - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .hero-section {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 6rem 0;
            text-align: center;
        }
        
        .hero-content h1 {
            font-size: 3rem;
            margin-bottom: 1rem;
            font-weight: 700;
        }
        
        .hero-content p {
            font-size: 1.2rem;
            max-width: 600px;
            margin: 0 auto;
            opacity: 0.9;
        }
        
        .about-section {
            padding: 5rem 0;
        }
        
        .about-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 4rem;
            align-items: center;
            margin-bottom: 4rem;
        }
        
        .about-text h2 {
            font-size: 2.5rem;
            margin-bottom: 1.5rem;
            color: #2c3e50;
        }
        
        .about-text p {
            font-size: 1.1rem;
            line-height: 1.8;
            color: #666;
            margin-bottom: 1.5rem;
        }
        
        .about-image {
            text-align: center;
        }
        
        .about-image img {
            max-width: 100%;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }
        
        .values-section {
            background: #f8f9fa;
            padding: 5rem 0;
        }
        
        .values-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 2rem;
            margin-top: 3rem;
        }
        
        .value-card {
            background: white;
            padding: 2.5rem;
            border-radius: 15px;
            text-align: center;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
        }
        
        .value-card:hover {
            transform: translateY(-5px);
        }
        
        .value-icon {
            font-size: 3rem;
            margin-bottom: 1.5rem;
        }
        
        .value-card h3 {
            font-size: 1.5rem;
            margin-bottom: 1rem;
            color: #2c3e50;
        }
        
        .value-card p {
            color: #666;
            line-height: 1.6;
        }
        
        .team-section {
            padding: 5rem 0;
        }
        
        .team-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 2rem;
            margin-top: 3rem;
        }
        
        .team-card {
            background: white;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
        }
        
        .team-card:hover {
            transform: translateY(-5px);
        }
        
        .team-image {
            height: 250px;
            background: linear-gradient(45deg, #667eea, #764ba2);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 4rem;
        }
        
        .team-info {
            padding: 1.5rem;
            text-align: center;
        }
        
        .team-info h4 {
            font-size: 1.3rem;
            margin-bottom: 0.5rem;
            color: #2c3e50;
        }
        
        .team-info .position {
            color: #3498db;
            font-weight: 600;
            margin-bottom: 1rem;
        }
        
        .team-info p {
            color: #666;
            font-size: 0.9rem;
            line-height: 1.5;
        }
        
        .stats-section {
            background: linear-gradient(135deg, #2c3e50 0%, #34495e 100%);
            color: white;
            padding: 5rem 0;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 2rem;
            text-align: center;
        }
        
        .stat-item h3 {
            font-size: 3rem;
            margin-bottom: 0.5rem;
            color: #3498db;
        }
        
        .stat-item p {
            font-size: 1.1rem;
            opacity: 0.9;
        }
        
        @media (max-width: 768px) {
            .about-grid {
                grid-template-columns: 1fr;
                gap: 2rem;
            }
            
            .hero-content h1 {
                font-size: 2rem;
            }
            
            .about-text h2 {
                font-size: 2rem;
            }
        }
    </style>
</head>
<body>
    <!-- Navigation - ສ່ວນເມນູການນຳທາງ -->
    <nav class="navbar">
        <div class="container">
            <div class="nav-brand">
                <a href="index.php"><?php echo SITE_NAME; ?></a>
            </div>
            <ul class="nav-menu">
                <li><a href="index.php">ໜ້າຫຼັກ</a></li>
                <li><a href="projects.php">ໂຄງການ</a></li>
                <li><a href="plots.php">ແປງທີ່ດິນ</a></li>
                <li><a href="about.php" class="active">ກ່ຽວກັບ</a></li>
                <li><a href="contact.php">ຕິດຕໍ່</a></li>
                <?php 
                // ກວດສອບວ່າຜູ້ໃຊ້ໄດ້ເຂົ້າສູ່ລະບົບແລ້ວບໍ
                // isLoggedIn() ແມ່ນຟັງຊັນທີ່ຢູ່ໃນ includes/auth.php
                if (isLoggedIn()): 
                ?>
                    <li><a href="customer/dashboard.php">ແຜງຄວບຄຸມ</a></li>
                    <li><a href="logout.php">ອອກຈາກລະບົບ</a></li>
                <?php else: ?>
                    <li><a href="login.php">ເຂົ້າສູ່ລະບົບ</a></li>
                    <li><a href="register.php">ລົງທະບຽນ</a></li>
                <?php endif; ?>
            </ul>
            <div class="nav-toggle">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>
    </nav>

    <!-- Hero Section - ສ່ວນຫົວຂໍ້ຫຼັກຂອງໜ້າ -->
    <section class="hero-section">
        <div class="container">
            <div class="hero-content">
                <h1>ກ່ຽວກັບລະບົບການຄຸ້ມຄອງທີ່ດິນ PPS</h1>
                <p>ນຳໜ້າໃນການພັດທະນາທີ່ດິນແບບຍືນຍົງ ແລະ ຄວາມເປັນເລີດດ້ານອະສັງຫາລິມະສັບມາເປັນເວລາສອງທົດສະວັດ.</p>
            </div>
        </div>
    </section>

    <!-- Alert Messages - ສ່ວນສະແດງຂໍ້ຄວາມແຈ້ງເຕືອນ -->
    <?php if ($alert): ?>
    <div class="alert alert-<?php echo $alert["type"]; ?>">
        <div class="container">
            <?php echo htmlspecialchars($alert["message"]); ?>
        </div>
    </div>
    <?php endif; ?>

    <!-- About Section - ສ່ວນເນື້ອໃນກ່ຽວກັບບໍລິສັດ -->
    <section class="about-section">
        <div class="container">
            <div class="about-grid">
                <div class="about-text">
                    <h2>ເລື່ອງລາວຂອງພວກເຮົາ</h2>
                    <p>ສ້າງຕັ້ງຂຶ້ນໃນປີ 2001, ລະບົບການຄຸ້ມຄອງທີ່ດິນ PPS ໄດ້ເປັນຜູ້ນຳໜ້າໃນການພັດທະນາທີ່ດິນ ແລະ ການຄຸ້ມຄອງອະສັງຫາລິມະສັບໃນພາກພື້ນ. ພວກເຮົາເລີ່ມຕົ້ນດ້ວຍວິໄສທັດງ່າຍໆຄື: ສ້າງຊຸມຊົນທີ່ມີການວາງແຜນທີ່ດີ ແລະ ຍືນຍົງ ເຊິ່ງຊ່ວຍເພີ່ມຄຸນນະພາບຊີວິດຂອງຜູ້ຢູ່ອາໄສ ໃນຂະນະທີ່ຮັກສາສິ່ງແວດລ້ອມທຳມະຊາດ.</p>
                    <p>ຕະຫຼອດຫຼາຍປີທີ່ຜ່ານມາ, ພວກເຮົາໄດ້ພັດທະນາໂຄງການທີ່ຢູ່ອາໄສ ແລະ ໂຄງການການຄ້າຫຼາຍກວ່າ 50 ໂຄງການສຳເລັດຜົນ, ຕັ້ງແຕ່ໂຄງການເຮືອນຫຼູຫຼາໄປຈົນເຖິງໂຄງການພັດທະນາແບບປະສົມປະສານ. ຄວາມມຸ່ງໝັ້ນຂອງພວກເຮົາຕໍ່ຄວາມເປັນເລີດ, ນະວັດຕະກຳ, ແລະ ຄວາມພໍໃຈຂອງລູກຄ້າໄດ້ເຮັດໃຫ້ພວກເຮົາເປັນໜຶ່ງໃນຊື່ທີ່ເຊື່ອຖືໄດ້ຫຼາຍທີ່ສຸດໃນອຸດສາຫະກຳ.</p>
                    <p>ມື້ນີ້, ພວກເຮົາສືບຕໍ່ກ້າວຂ້າມຂີດຈຳກັດໃນການພັດທະນາທີ່ດິນ, ລວມເອົາເຕັກໂນໂລຢີອັດສະລິຍະ ແລະ ການປະຕິບັດທີ່ຍືນຍົງເພື່ອສ້າງຊຸມຊົນສຳລັບອະນາຄົດ.</p>
                </div>
                <div class="about-image">
                    <img src="assets/images/about-us.jpg" alt="About PPS Land Management" onerror="this.style.display=\'none\'">
                </div>
            </div>
        </div>
    </section>

    <!-- Values Section - ສ່ວນຄຸນຄ່າຫຼັກຂອງບໍລິສັດ -->
    <section class="values-section">
        <div class="container">
            <div class="section-header">
                <h2>ຄຸນຄ່າຫຼັກຂອງພວກເຮົາ</h2>
                <p>ຫຼັກການທີ່ນຳພາທຸກສິ່ງທີ່ພວກເຮົາເຮັດ</p>
            </div>
            <div class="values-grid">
                <div class="value-card">
                    <div class="value-icon">🌱</div>
                    <h3>ຄວາມຍືນຍົງ</h3>
                    <p>ພວກເຮົາມຸ່ງໝັ້ນຕໍ່ການປະຕິບັດການພັດທະນາທີ່ຮັບຜິດຊອບຕໍ່ສິ່ງແວດລ້ອມ ເຊິ່ງຮັກສາຊັບພະຍາກອນທຳມະຊາດ ແລະ ສ້າງມູນຄ່າທີ່ຍືນຍົງສຳລັບຄົນລຸ້ນຫຼັງ.</p>
                </div>
                <div class="value-card">
                    <div class="value-icon">🏆</div>
                    <h3>ຄວາມເປັນເລີດ</h3>
                    <p>ພວກເຮົາພະຍາຍາມເພື່ອມາດຕະຖານສູງສຸດໃນທຸກດ້ານຂອງວຽກງານຂອງພວກເຮົາ, ຕັ້ງແຕ່ການວາງແຜນ ແລະ ການອອກແບບ ຈົນເຖິງການກໍ່ສ້າງ ແລະ ການບໍລິການລູກຄ້າ.</p>
                </div>
                <div class="value-card">
                    <div class="value-icon">🤝</div>
                    <h3>ຄວາມຊື່ສັດ</h3>
                    <p>ພວກເຮົາດຳເນີນທຸລະກິດດ້ວຍຄວາມຊື່ສັດ, ໂປ່ງໃສ, ແລະ ການປະຕິບັດຕາມຫຼັກຈັນຍາບັນ, ສ້າງຄວາມໄວ້ວາງໃຈກັບລູກຄ້າ, ຄູ່ຮ່ວມງານ, ແລະ ຊຸມຊົນຂອງພວກເຮົາ.</p>
                </div>
                <div class="value-card">
                    <div class="value-icon">💡</div>
                    <h3>ນະວັດຕະກຳ</h3>
                    <p>ພວກເຮົານຳໃຊ້ເຕັກໂນໂລຢີໃໝ່ໆ ແລະ ວິທີແກ້ໄຂທີ່ສ້າງສັນ ເພື່ອເພີ່ມປະສົບການການດຳລົງຊີວິດ ແລະ ປັບປຸງປະສິດທິພາບການດຳເນີນງານ.</p>
                </div>
                <div class="value-card">
                    <div class="value-icon">👥</div>
                    <h3>ຊຸມຊົນ</h3>
                    <p>ພວກເຮົາເຊື່ອໃນການສ້າງຫຼາຍກວ່າພຽງແຕ່ການພັດທະນາ – ພວກເຮົາສ້າງຊຸມຊົນທີ່ຜູ້ຄົນສາມາດຈະເລີນຮຸ່ງເຮືອງ ແລະ ເຊື່ອມຕໍ່ກັນໄດ້.</p>
                </div>
                <div class="value-card">
                    <div class="value-icon">⭐</div>
                    <h3>ການເອົາໃຈໃສ່ລູກຄ້າ</h3>
                    <p>ລູກຄ້າຂອງພວກເຮົາແມ່ນຫົວໃຈຂອງທຸກສິ່ງທີ່ພວກເຮົາເຮັດ. ພວກເຮົາຮັບຟັງຄວາມຕ້ອງການຂອງພວກເຂົາ ແລະ ເກີນຄວາມຄາດຫວັງຂອງພວກເຂົາໃນທຸກໆໂອກາດ.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Team Section - ສ່ວນທີມງານຂອງບໍລິສັດ -->
    <section class="team-section">
        <div class="container">
            <div class="section-header">
                <h2>ພົບກັບທີມງານນຳພາຂອງພວກເຮົາ</h2>
                <p>ຜູ້ຊ່ຽວຊານທີ່ມີປະສົບການທີ່ອຸທິດໃຫ້ແກ່ຄວາມເປັນເລີດ</p>
            </div>
            <div class="team-grid">
                <div class="team-card">
                    <div class="team-image">👨‍💼</div>
                    <div class="team-info">
                        <h4>ຈອນ ສະມິດ</h4>
                        <div class="position">ປະທານບໍລິຫານ</div>
                        <p>ດ້ວຍປະສົບການຫຼາຍກວ່າ 25 ປີໃນການພັດທະນາອະສັງຫາລິມະສັບ, ຈອນ ນຳພາວິໄສທັດຍຸດທະສາດຂອງພວກເຮົາ ແລະ ດູແລໂຄງການພັດທະນາທີ່ສຳຄັນທັງໝົດ.</p>
                    </div>
                </div>
                <div class="team-card">
                    <div class="team-image">👩‍💼</div>
                    <div class="team-info">
                        <h4>ຊາຣາ ຈອນສັນ</h4>
                        <div class="position">ປະທານຝ່າຍປະຕິບັດການ</div>
                        <p>ຊາຣາ ນຳເອົາປະສົບການຄວາມເປັນເລີດດ້ານການປະຕິບັດງານ 20 ປີມາສູ່ PPS, ຮັບປະກັນການດຳເນີນໂຄງການທີ່ລຽບງ່າຍ ແລະ ການບໍລິການລູກຄ້າທີ່ດີເລີດ.</p>
                    </div>
                </div>
                <div class="team-card">
                    <div class="team-image">👨‍🔧</div>
                    <div class="team-info">
                        <h4>ໄມເຄີລ ບຣາວ</h4>
                        <div class="position">ຫົວໜ້າຝ່າຍພັດທະນາ</div>
                        <p>ໄມເຄີລ ດູແລກິດຈະກຳການກໍ່ສ້າງ ແລະ ການພັດທະນາທັງໝົດ, ຮັບປະກັນວ່າໂຄງການສຳເລັດຕາມກຳນົດເວລາ ແລະ ມີຄຸນນະພາບສູງສຸດ.</p>
                    </div>
                </div>
                <div class="team-card">
                    <div class="team-image">👩‍💻</div>
                    <div class="team-info">
                        <h4>ເອມິລີ ເດວິດ</h4>
                        <div class="position">ຫົວໜ້າຝ່າຍຂາຍ ແລະ ການຕະຫຼາດ</div>
                        <p>ເອມິລີ ນຳພາຄວາມພະຍາຍາມດ້ານການຂາຍ ແລະ ການຕະຫຼາດຂອງພວກເຮົາ, ຊ່ວຍລູກຄ້າຊອກຫາອະສັງຫາລິມະສັບທີ່ສົມບູນແບບຂອງພວກເຂົາ ແລະ ສ້າງສາຍພົວພັນທີ່ຍືນຍົງ.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Stats Section - ສ່ວນສະແດງສະຖິຕິສຳຄັນ -->
    <section class="stats-section">
        <div class="container">
            <div class="stats-grid">
                <div class="stat-item">
                    <h3>50+</h3>
                    <p>ໂຄງການສຳເລັດ</p>
                </div>
                <div class="stat-item">
                    <h3>5000+</h3>
                    <p>ລູກຄ້າພໍໃຈ</p>
                </div>
                <div class="stat-item">
                    <h3>20+</h3>
                    <p>ປີແຫ່ງປະສົບການ</p>
                </div>
                <div class="stat-item">
                    <h3>1000+</h3>
                    <p>ພື້ນທີ່ພັດທະນາ (ເຮັກຕາ)</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer - ສ່ວນທ້າຍຂອງເວັບໄຊທ໌ -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3><?php echo SITE_NAME; ?></h3>
                    <p>Leading the way in sustainable land development and real estate excellence.</p>
                    <div class="social-links">
                        <a href="#" aria-label="Facebook">📘</a>
                        <a href="#" aria-label="Twitter">🐦</a>
                        <a href="#" aria-label="LinkedIn">💼</a>
                        <a href="#" aria-label="Instagram">📷</a>
                    </div>
                </div>
                <div class="footer-section">
                    <h4>ລິ້ງດ່ວນ</h4>
                    <ul>
                        <li><a href="index.php">ໜ້າຫຼັກ</a></li>
                        <li><a href="projects.php">ໂຄງການ</a></li>
                        <li><a href="plots.php">ແປງທີ່ດິນ</a></li>
                        <li><a href="about.php">ກ່ຽວກັບ</a></li>
                        <li><a href="contact.php">ຕິດຕໍ່</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h4>ບໍລິການ</h4>
                    <ul>
                        <li><a href="#">ການພັດທະນາທີ່ດິນ</a></li>
                        <li><a href="#">ການຄຸ້ມຄອງອະສັງຫາລິມະສັບ</a></li>
                        <li><a href="#">ການໃຫ້ຄຳປຶກສາດ້ານອະສັງຫາລິມະສັບ</a></li>
                        <li><a href="#">ການໃຫ້ຄຳປຶກສາດ້ານການລົງທຶນ</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h4>ຂໍ້ມູນຕິດຕໍ່</h4>
                    <div class="contact-info">
                        <p>📍 123 Business District, City Center</p>
                        <p>📞 +1 (555) 123-4567</p>
                        <p>✉️ info@ppsland.com</p>
                    </div>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; <?php echo date("Y"); ?> <?php echo SITE_NAME; ?>. ສະຫງວນລິຂະສິດທັງໝົດ.</p>
            </div>
        </div>
    </footer>

    <!-- JavaScript Files -->
    <script src="assets/js/main.js"></script>
</body>
</html>


