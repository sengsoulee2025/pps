
<?php
require_once 'config/config.php';
require_once 'includes/auth.php';

// 1. ດຶງການເຊື່ອມຕໍ່ຖານຂໍ້ມູນມາກ່ອນ
$pdo = getDBConnection();

// 2. ສົ່ງ $pdo ເຂົ້າໄປຕອນສ້າງ Auth object
$auth = new Auth($pdo); 
$auth->logout();

showAlert('You have been logged out successfully', 'success');
redirect('index.php');
?>