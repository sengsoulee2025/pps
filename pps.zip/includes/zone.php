<?php
// ໄຟລ໌: includes/zone.php
class ProjectZone {
    private $pdo;
    public function __construct($pdo) { $this->pdo = $pdo; }
    public function getAllZones() {
        try {
            $sql = "SELECT z.*, p.name as project_name FROM project_zones z JOIN project p ON z.project_id = p.id ORDER BY p.name, z.zone_name ASC";
            return $this->pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) { error_log($e->getMessage()); return []; }
    }
    public function getZonesByProjectId($projectId) {
        try {
            $stmt = $this->pdo->prepare("SELECT * FROM project_zones WHERE project_id = ? ORDER BY zone_name ASC");
            $stmt->execute([$projectId]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) { error_log($e->getMessage()); return []; }
    }
    public function getZoneById($id) {
        try {
            $stmt = $this->pdo->prepare("SELECT * FROM project_zones WHERE id = ?");
            $stmt->execute([$id]);
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (Exception $e) { error_log($e->getMessage()); return null; }
    }
    public function createZone($data) {
        try {
            $sql = "INSERT INTO project_zones (project_id, zone_name, price_per_sqm, currency) VALUES (?, ?, ?, ?)";
            $stmt = $this->pdo->prepare($sql);
            return $stmt->execute([$data['project_id'], $data['zone_name'], $data['price_per_sqm'], $data['currency']]);
        } catch (Exception $e) { throw new Exception($e->getMessage()); }
    }
    public function updateZone($id, $data) {
        try {
            $sql = "UPDATE project_zones SET zone_name = ?, price_per_sqm = ?, currency = ? WHERE id = ?";
            $stmt = $this->pdo->prepare($sql);
            return $stmt->execute([$data['zone_name'], $data['price_per_sqm'], $data['currency'], $id]);
        } catch (Exception $e) { throw new Exception($e->getMessage()); }
    }
    public function deleteZone($id) {
        try {
            $stmtCheck = $this->pdo->prepare("SELECT COUNT(*) FROM plot WHERE zone_id = ?");
            $stmtCheck->execute([$id]);
            if ($stmtCheck->fetchColumn() > 0) { return false; }
            $stmt = $this->pdo->prepare("DELETE FROM project_zones WHERE id = ?");
            return $stmt->execute([$id]);
        } catch (Exception $e) { throw new Exception($e->getMessage()); }
    }
    public function isZoneNameTaken($projectId, $zoneName, $excludeZoneId = null) {
        try {
            $sql = "SELECT COUNT(*) FROM project_zones WHERE project_id = ? AND zone_name = ?";
            $params = [$projectId, $zoneName];
            if ($excludeZoneId !== null) { $sql .= " AND id != ?"; $params[] = $excludeZoneId; }
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($params);
            return $stmt->fetchColumn() > 0;
        } catch (Exception $e) { error_log($e->getMessage()); return true; }
    }
}
?>