

<?php
require_once __DIR__ . '/../config/config.php';

class Auth {
    private $pdo;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }
    
    public function login($username, $password) {
        try {
            $stmt = $this->pdo->prepare("SELECT u.*, e.id as employee_id, c.id as customer_id 
                                        FROM username u 
                                        LEFT JOIN employee e ON u.id = e.username_id 
                                        LEFT JOIN customer c ON u.id = c.username_id 
                                        WHERE u.username = ? AND u.is_active = 1");
            $stmt->execute([$username]);
            $user = $stmt->fetch();
            
            if ($user && password_verify($password, $user['password_hash'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['email'] = $user['email'];
                $_SESSION['role'] = $user['role'];
                $_SESSION['employee_id'] = $user['employee_id'];
                $_SESSION['customer_id'] = $user['customer_id'];
                $_SESSION['last_activity'] = time();
                
                return true;
            }
            return false;
        } catch (Exception $e) {
            return false;
        }
    }
    
    public function register($username, $email, $password, $role = 'customer') {
        try {
            // Check if username or email already exists
            $stmt = $this->pdo->prepare("SELECT id FROM username WHERE username = ? OR email = ?");
            $stmt->execute([$username, $email]);
            if ($stmt->fetch()) {
                return false; // User already exists
            }
            
            $password_hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $this->pdo->prepare("INSERT INTO username (username, email, password_hash, role) VALUES (?, ?, ?, ?)");
            $stmt->execute([$username, $email, $password_hash, $role]);
            
            return $this->pdo->lastInsertId();
        } catch (Exception $e) {
            return false;
        }
    }
    
    public function logout() {
        session_destroy();
        return true;
    }
    
    public function checkSession() {
        if (!isLoggedIn()) {
            return false;
        }
        
        // Check session timeout
        if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > SESSION_TIMEOUT)) {
            $this->logout();
            return false;
        }
        
        $_SESSION['last_activity'] = time();
        return true;
    }
    
    public function changePassword($user_id, $old_password, $new_password) {
        try {
            $stmt = $this->pdo->prepare("SELECT password_hash FROM username WHERE id = ?");
            $stmt->execute([$user_id]);
            $user = $stmt->fetch();
            
            if ($user && password_verify($old_password, $user['password_hash'])) {
                $new_hash = password_hash($new_password, PASSWORD_DEFAULT);
                $stmt = $this->pdo->prepare("UPDATE username SET password_hash = ? WHERE id = ?");
                $stmt->execute([$new_hash, $user_id]);
                return true;
            }
            return false;
        } catch (Exception $e) {
            return false;
        }
    }
    
    public function resetPassword($email) {
        try {
            $stmt = $this->pdo->prepare("SELECT id FROM username WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch();
            
            if ($user) {
                $new_password = generateRandomString(8);
                $new_hash = password_hash($new_password, PASSWORD_DEFAULT);
                $stmt = $this->pdo->prepare("UPDATE username SET password_hash = ? WHERE id = ?");
                $stmt->execute([$new_hash, $user['id']]);
                
                // In a real application, you would send this via email
                return $new_password;
            }
            return false;
        } catch (Exception $e) {
            return false;
        }
    }
}
?>

