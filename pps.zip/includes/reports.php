<?php
require_once __DIR__ . '/../config/config.php';

class Reports {
    private $pdo;
    
    public function __construct() {
        $this->pdo = getDBConnection();
    }
    
    // Sales Reports
    public function getSalesReport($start_date = null, $end_date = null, $project_id = null) {
        try {
            $where_conditions = [];
            $params = [];
            
            if ($start_date) {
                $where_conditions[] = "s.created_at >= ?";
                $params[] = $start_date;
            }
            
            if ($end_date) {
                $where_conditions[] = "s.created_at <= ?";
                $params[] = $end_date . ' 23:59:59';
            }
            
            if ($project_id) {
                $where_conditions[] = "pr.id = ?";
                $params[] = $project_id;
            }
            
            $where_clause = !empty($where_conditions) ? 'WHERE ' . implode(' AND ', $where_conditions) : '';
            
            $sql = "SELECT 
                        s.id,
                        s.sale_price,
                        s.commission,
                        s.created_at,
                        p.plot_number,
                        p.area,
                        pr.name as project_name,
                        CONCAT(c.first_name, ' ', c.last_name) as customer_name,
                        CONCAT(e.first_name, ' ', e.last_name) as employee_name
                    FROM sale s
                    JOIN plot p ON s.plot_id = p.id
                    JOIN project pr ON p.project_id = pr.id
                    JOIN customer c ON s.customer_id = c.id
                    LEFT JOIN employee e ON s.employee_id = e.id
                    $where_clause
                    ORDER BY s.created_at DESC";
            
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($params);
            
            return $stmt->fetchAll();
        } catch (Exception $e) {
            error_log("Error in getSalesReport: " . $e->getMessage());
            return [];
        }
    }
    
    // Sales Summary
    public function getSalesSummary($start_date = null, $end_date = null) {
        try {
            $where_conditions = [];
            $params = [];
            
            if ($start_date) {
                $where_conditions[] = "created_at >= ?";
                $params[] = $start_date;
            }
            
            if ($end_date) {
                $where_conditions[] = "created_at <= ?";
                $params[] = $end_date . ' 23:59:59';
            }
            
            $where_clause = !empty($where_conditions) ? 'WHERE ' . implode(' AND ', $where_conditions) : '';
            
            $sql = "SELECT 
                        COUNT(*) as total_sales,
                        SUM(sale_price) as total_revenue,
                        AVG(sale_price) as avg_sale_price,
                        MIN(sale_price) as min_sale_price,
                        MAX(sale_price) as max_sale_price,
                        SUM(commission) as total_commission
                    FROM sale 
                    $where_clause";
            
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($params);
            
            return $stmt->fetch();
        } catch (Exception $e) {
            error_log("Error in getSalesSummary: " . $e->getMessage());
            return [
                'total_sales' => 0,
                'total_revenue' => 0,
                'avg_sale_price' => 0,
                'min_sale_price' => 0,
                'max_sale_price' => 0,
                'total_commission' => 0
            ];
        }
    }
    
    // Monthly Sales Data
    public function getMonthlySalesData($year = null) {
        try {
            $year = $year ?: date('Y');
            
            $sql = "SELECT 
                        MONTH(created_at) as month,
                        COUNT(*) as sales_count,
                        SUM(sale_price) as revenue,
                        AVG(sale_price) as avg_price
                    FROM sale 
                    WHERE YEAR(created_at) = ?
                    GROUP BY MONTH(created_at)
                    ORDER BY month";
            
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([$year]);
            
            $data = $stmt->fetchAll();
            
            // Fill in missing months with zero values
            $monthly_data = [];
            for ($i = 1; $i <= 12; $i++) {
                $found = false;
                foreach ($data as $row) {
                    if ($row['month'] == $i) {
                        $monthly_data[] = $row;
                        $found = true;
                        break;
                    }
                }
                if (!$found) {
                    $monthly_data[] = [
                        'month' => $i,
                        'sales_count' => 0,
                        'revenue' => 0,
                        'avg_price' => 0
                    ];
                }
            }
            
            return $monthly_data;
        } catch (Exception $e) {
            error_log("Error in getMonthlySalesData: " . $e->getMessage());
            return [];
        }
    }
    
    // Project Performance Report
    public function getProjectPerformance() {
        try {
            $sql = "SELECT 
                        pr.id,
                        pr.name,
                        pr.location,
                        pr.total_plots,
                        pr.status,
                        COUNT(p.id) as actual_plots,
                        SUM(CASE WHEN p.status = 'available' THEN 1 ELSE 0 END) as available_plots,
                        SUM(CASE WHEN p.status = 'reserved' THEN 1 ELSE 0 END) as reserved_plots,
                        SUM(CASE WHEN p.status = 'sold' THEN 1 ELSE 0 END) as sold_plots,
                        COUNT(s.id) as total_sales,
                        SUM(s.sale_price) as total_revenue,
                        AVG(s.sale_price) as avg_sale_price,
                        (SUM(CASE WHEN p.status = 'sold' THEN 1 ELSE 0 END) / COUNT(p.id) * 100) as sales_rate
                    FROM project pr
                    LEFT JOIN plot p ON pr.id = p.project_id
                    LEFT JOIN sale s ON p.id = s.plot_id
                    GROUP BY pr.id
                    ORDER BY total_revenue DESC";
            
            $stmt = $this->pdo->query($sql);
            return $stmt->fetchAll();
        } catch (Exception $e) {
            error_log("Error in getProjectPerformance: " . $e->getMessage());
            return [];
        }
    }
    
    // Customer Analytics
    public function getCustomerAnalytics() {
        try {
            $sql = "SELECT 
                        COUNT(*) as total_customers,
                        SUM(CASE WHEN created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY) THEN 1 ELSE 0 END) as new_customers_30d,
                        SUM(CASE WHEN created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY) THEN 1 ELSE 0 END) as new_customers_7d
                    FROM customer";
            
            $stmt = $this->pdo->query($sql);
            $customer_stats = $stmt->fetch();
            
            // Customer purchase behavior
            $sql = "SELECT 
                        c.id,
                        CONCAT(c.first_name, ' ', c.last_name) as name,
                        c.email,
                        c.phone,
                        COUNT(s.id) as total_purchases,
                        SUM(s.sale_price) as total_spent,
                        AVG(s.sale_price) as avg_purchase,
                        MAX(s.created_at) as last_purchase
                    FROM customer c
                    LEFT JOIN sale s ON c.id = s.customer_id
                    GROUP BY c.id
                    HAVING total_purchases > 0
                    ORDER BY total_spent DESC
                    LIMIT 20";
            
            $stmt = $this->pdo->query($sql);
            $top_customers = $stmt->fetchAll();
            
            return [
                'stats' => $customer_stats,
                'top_customers' => $top_customers
            ];
        } catch (Exception $e) {
            error_log("Error in getCustomerAnalytics: " . $e->getMessage());
            return [
                'stats' => ['total_customers' => 0, 'new_customers_30d' => 0, 'new_customers_7d' => 0],
                'top_customers' => []
            ];
        }
    }
    
    // Lead Conversion Report
    public function getLeadConversionReport() {
        try {
            $sql = "SELECT 
                        COUNT(*) as total_leads,
                        SUM(CASE WHEN status = 'new' THEN 1 ELSE 0 END) as new_leads,
                        SUM(CASE WHEN status = 'contacted' THEN 1 ELSE 0 END) as contacted_leads,
                        SUM(CASE WHEN status = 'converted' THEN 1 ELSE 0 END) as converted_leads,
                        (SUM(CASE WHEN status = 'converted' THEN 1 ELSE 0 END) / COUNT(*) * 100) as conversion_rate
                    FROM lead";
            
            $stmt = $this->pdo->query($sql);
            $lead_stats = $stmt->fetch();
            
            // Lead source analysis
            $sql = "SELECT 
                        source,
                        COUNT(*) as count,
                        SUM(CASE WHEN status = 'converted' THEN 1 ELSE 0 END) as converted,
                        (SUM(CASE WHEN status = 'converted' THEN 1 ELSE 0 END) / COUNT(*) * 100) as conversion_rate
                    FROM lead
                    GROUP BY source
                    ORDER BY count DESC";
            
            $stmt = $this->pdo->query($sql);
            $lead_sources = $stmt->fetchAll();
            
            // Monthly lead trends
            $sql = "SELECT 
                        DATE_FORMAT(created_at, '%Y-%m') as month,
                        COUNT(*) as total_leads,
                        SUM(CASE WHEN status = 'converted' THEN 1 ELSE 0 END) as converted_leads
                    FROM lead
                    WHERE created_at >= DATE_SUB(NOW(), INTERVAL 12 MONTH)
                    GROUP BY DATE_FORMAT(created_at, '%Y-%m')
                    ORDER BY month";
            
            $stmt = $this->pdo->query($sql);
            $monthly_trends = $stmt->fetchAll();
            
            return [
                'stats' => $lead_stats,
                'sources' => $lead_sources,
                'monthly_trends' => $monthly_trends
            ];
        } catch (Exception $e) {
            error_log("Error in getLeadConversionReport: " . $e->getMessage());
            return [
                'stats' => ['total_leads' => 0, 'new_leads' => 0, 'contacted_leads' => 0, 'converted_leads' => 0, 'conversion_rate' => 0],
                'sources' => [],
                'monthly_trends' => []
            ];
        }
    }
    
    // Employee Performance Report
    public function getEmployeePerformance($start_date = null, $end_date = null) {
        try {
            $where_conditions = [];
            $params = [];
            
            if ($start_date) {
                $where_conditions[] = "s.created_at >= ?";
                $params[] = $start_date;
            }
            
            if ($end_date) {
                $where_conditions[] = "s.created_at <= ?";
                $params[] = $end_date . ' 23:59:59';
            }
            
            $where_clause = !empty($where_conditions) ? 'WHERE ' . implode(' AND ', $where_conditions) : '';
            
            $sql = "SELECT 
                        e.id,
                        CONCAT(e.first_name, ' ', e.last_name) as name,
                        e.position,
                        e.department,
                        COUNT(s.id) as total_sales,
                        SUM(s.sale_price) as total_revenue,
                        SUM(s.commission) as total_commission,
                        AVG(s.sale_price) as avg_sale_price
                    FROM employee e
                    LEFT JOIN sale s ON e.id = s.employee_id $where_clause
                    GROUP BY e.id
                    ORDER BY total_revenue DESC";
            
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($params);
            
            return $stmt->fetchAll();
        } catch (Exception $e) {
            error_log("Error in getEmployeePerformance: " . $e->getMessage());
            return [];
        }
    }
    
    // Inventory Report
    public function getInventoryReport() {
        try {
            $sql = "SELECT 
                        pr.name as project_name,
                        pr.location,
                        pr.status as project_status,
                        COUNT(p.id) as total_plots,
                        SUM(CASE WHEN p.status = 'available' THEN 1 ELSE 0 END) as available_plots,
                        SUM(CASE WHEN p.status = 'reserved' THEN 1 ELSE 0 END) as reserved_plots,
                        SUM(CASE WHEN p.status = 'sold' THEN 1 ELSE 0 END) as sold_plots,
                        SUM(p.area) as total_area,
                        AVG(p.price) as avg_price,
                        MIN(p.price) as min_price,
                        MAX(p.price) as max_price
                    FROM project pr
                    LEFT JOIN plot p ON pr.id = p.project_id
                    GROUP BY pr.id
                    ORDER BY pr.name";
            
            $stmt = $this->pdo->query($sql);
            return $stmt->fetchAll();
        } catch (Exception $e) {
            error_log("Error in getInventoryReport: " . $e->getMessage());
            return [];
        }
    }
    
    // Financial Summary
    public function getFinancialSummary($start_date = null, $end_date = null) {
        try {
            $where_conditions = [];
            $params = [];
            
            if ($start_date) {
                $where_conditions[] = "created_at >= ?";
                $params[] = $start_date;
            }
            
            if ($end_date) {
                $where_conditions[] = "created_at <= ?";
                $params[] = $end_date . ' 23:59:59';
            }
            
            $where_clause = !empty($where_conditions) ? 'WHERE ' . implode(' AND ', $where_conditions) : '';
            
            // Sales revenue
            $sql = "SELECT 
                        SUM(sale_price) as total_revenue,
                        SUM(commission) as total_commission,
                        COUNT(*) as total_transactions
                    FROM sale 
                    $where_clause";
            
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($params);
            $sales_data = $stmt->fetch();
            
            // Calculate net revenue (revenue - commission)
            $net_revenue = ($sales_data['total_revenue'] ?: 0) - ($sales_data['total_commission'] ?: 0);
            
            return [
                'total_revenue' => $sales_data['total_revenue'] ?: 0,
                'total_commission' => $sales_data['total_commission'] ?: 0,
                'net_revenue' => $net_revenue,
                'total_transactions' => $sales_data['total_transactions'] ?: 0,
                'avg_transaction' => $sales_data['total_transactions'] > 0 ? 
                    ($sales_data['total_revenue'] / $sales_data['total_transactions']) : 0
            ];
        } catch (Exception $e) {
            error_log("Error in getFinancialSummary: " . $e->getMessage());
            return [
                'total_revenue' => 0,
                'total_commission' => 0,
                'net_revenue' => 0,
                'total_transactions' => 0,
                'avg_transaction' => 0
            ];
        }
    }
    
    // Export report to CSV
    public function exportToCSV($data, $filename, $headers = []) {
        try {
            $output = fopen('php://temp', 'w');
            
            // Write headers if provided
            if (!empty($headers)) {
                fputcsv($output, $headers);
            } elseif (!empty($data)) {
                // Use array keys as headers
                fputcsv($output, array_keys($data[0]));
            }
            
            // Write data
            foreach ($data as $row) {
                fputcsv($output, $row);
            }
            
            rewind($output);
            $csv_content = stream_get_contents($output);
            fclose($output);
            
            // Set headers for download
            header('Content-Type: text/csv');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            header('Content-Length: ' . strlen($csv_content));
            
            echo $csv_content;
            exit;
        } catch (Exception $e) {
            error_log("Error in exportToCSV: " . $e->getMessage());
            return false;
        }
    }
    
    // Generate chart data for JavaScript
    public function getChartData($type, $params = []) {
        try {
            switch ($type) {
                case 'monthly_sales':
                    $data = $this->getMonthlySalesData($params['year'] ?? null);
                    return [
                        'labels' => array_map(function($item) {
                            return date('M', mktime(0, 0, 0, $item['month'], 1));
                        }, $data),
                        'datasets' => [
                            [
                                'label' => 'Sales Count',
                                'data' => array_column($data, 'sales_count'),
                                'backgroundColor' => 'rgba(52, 152, 219, 0.8)'
                            ],
                            [
                                'label' => 'Revenue',
                                'data' => array_column($data, 'revenue'),
                                'backgroundColor' => 'rgba(46, 204, 113, 0.8)'
                            ]
                        ]
                    ];
                    
                case 'project_performance':
                    $data = $this->getProjectPerformance();
                    return [
                        'labels' => array_column($data, 'name'),
                        'datasets' => [
                            [
                                'label' => 'Sales Rate (%)',
                                'data' => array_column($data, 'sales_rate'),
                                'backgroundColor' => 'rgba(155, 89, 182, 0.8)'
                            ]
                        ]
                    ];
                    
                case 'lead_sources':
                    $lead_data = $this->getLeadConversionReport();
                    return [
                        'labels' => array_column($lead_data['sources'], 'source'),
                        'datasets' => [
                            [
                                'label' => 'Lead Count',
                                'data' => array_column($lead_data['sources'], 'count'),
                                'backgroundColor' => [
                                    'rgba(231, 76, 60, 0.8)',
                                    'rgba(52, 152, 219, 0.8)',
                                    'rgba(46, 204, 113, 0.8)',
                                    'rgba(241, 196, 15, 0.8)',
                                    'rgba(155, 89, 182, 0.8)'
                                ]
                            ]
                        ]
                    ];
                    
                default:
                    return [];
            }
        } catch (Exception $e) {
            error_log("Error in getChartData: " . $e->getMessage());
            return [];
        }
    }
}
?>

