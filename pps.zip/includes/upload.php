<?php
require_once __DIR__ . '/../config/config.php';

class FileUpload {
    private $uploadPath;
    private $allowedTypes;
    private $maxFileSize;
    
    public function __construct() {
        $this->uploadPath = UPLOAD_PATH;
        $this->maxFileSize = MAX_FILE_SIZE;
        $this->allowedTypes = [
            'image' => ALLOWED_IMAGE_TYPES,
            'video' => ALLOWED_VIDEO_TYPES,
            'document' => ALLOWED_DOC_TYPES
        ];
        
        // Create upload directories if they don't exist
        $this->createDirectories();
    }
    
    private function createDirectories() {
        $directories = ['images', 'videos', 'documents'];
        foreach ($directories as $dir) {
            $path = $this->uploadPath . $dir;
            if (!is_dir($path)) {
                mkdir($path, 0755, true);
            }
        }
    }
    
    public function uploadFile($file, $type = 'image', $customName = null) {
        try {
            // Validate file
            $validation = $this->validateFile($file, $type);
            if ($validation !== true) {
                return ['success' => false, 'message' => $validation];
            }
            
            // Generate filename
            $filename = $this->generateFilename($file['name'], $customName);
            $targetPath = $this->uploadPath . $type . 's/' . $filename;
            
            // Move uploaded file
            if (move_uploaded_file($file['tmp_name'], $targetPath)) {
                // Generate web-accessible URL
                $webUrl = 'uploads/' . $type . 's/' . $filename;
                
                return [
                    'success' => true,
                    'filename' => $filename,
                    'path' => $targetPath,
                    'url' => $webUrl,
                    'size' => $file['size'],
                    'type' => $file['type']
                ];
            } else {
                return ['success' => false, 'message' => 'Failed to move uploaded file'];
            }
        } catch (Exception $e) {
            return ['success' => false, 'message' => 'Upload error: ' . $e->getMessage()];
        }
    }
    
    public function uploadMultipleFiles($files, $type = 'image') {
        $results = [];
        
        // Handle multiple files
        if (is_array($files['name'])) {
            for ($i = 0; $i < count($files['name']); $i++) {
                $file = [
                    'name' => $files['name'][$i],
                    'type' => $files['type'][$i],
                    'tmp_name' => $files['tmp_name'][$i],
                    'error' => $files['error'][$i],
                    'size' => $files['size'][$i]
                ];
                $results[] = $this->uploadFile($file, $type);
            }
        } else {
            $results[] = $this->uploadFile($files, $type);
        }
        
        return $results;
    }
    
    private function validateFile($file, $type) {
        // Check for upload errors
        if ($file['error'] !== UPLOAD_ERR_OK) {
            return $this->getUploadErrorMessage($file['error']);
        }
        
        // Check file size
        if ($file['size'] > $this->maxFileSize) {
            return 'File size exceeds maximum allowed size of ' . ($this->maxFileSize / 1024 / 1024) . 'MB';
        }
        
        // Check file type
        $fileExtension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if (!in_array($fileExtension, $this->allowedTypes[$type])) {
            return 'File type not allowed. Allowed types: ' . implode(', ', $this->allowedTypes[$type]);
        }
        
        // Additional validation for images
        if ($type === 'image') {
            $imageInfo = getimagesize($file['tmp_name']);
            if ($imageInfo === false) {
                return 'Invalid image file';
            }
        }
        
        return true;
    }
    
    private function generateFilename($originalName, $customName = null) {
        $extension = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
        
        if ($customName) {
            $basename = preg_replace('/[^a-zA-Z0-9_-]/', '_', $customName);
        } else {
            $basename = pathinfo($originalName, PATHINFO_FILENAME);
            $basename = preg_replace('/[^a-zA-Z0-9_-]/', '_', $basename);
        }
        
        // Add timestamp to avoid conflicts
        $timestamp = time();
        return $basename . '_' . $timestamp . '.' . $extension;
    }
    
    private function getUploadErrorMessage($errorCode) {
        switch ($errorCode) {
            case UPLOAD_ERR_INI_SIZE:
            case UPLOAD_ERR_FORM_SIZE:
                return 'File size exceeds maximum allowed size';
            case UPLOAD_ERR_PARTIAL:
                return 'File was only partially uploaded';
            case UPLOAD_ERR_NO_FILE:
                return 'No file was uploaded';
            case UPLOAD_ERR_NO_TMP_DIR:
                return 'Missing temporary folder';
            case UPLOAD_ERR_CANT_WRITE:
                return 'Failed to write file to disk';
            case UPLOAD_ERR_EXTENSION:
                return 'File upload stopped by extension';
            default:
                return 'Unknown upload error';
        }
    }
    
    public function deleteFile($filePath) {
        try {
            $fullPath = $this->uploadPath . $filePath;
            if (file_exists($fullPath)) {
                return unlink($fullPath);
            }
            return false;
        } catch (Exception $e) {
            return false;
        }
    }
    
    public function getFileInfo($filePath) {
        try {
            $fullPath = $this->uploadPath . $filePath;
            if (file_exists($fullPath)) {
                return [
                    'exists' => true,
                    'size' => filesize($fullPath),
                    'modified' => filemtime($fullPath),
                    'type' => mime_content_type($fullPath)
                ];
            }
            return ['exists' => false];
        } catch (Exception $e) {
            return ['exists' => false];
        }
    }
    
    public function listFiles($type = 'image', $limit = null) {
        try {
            $directory = $this->uploadPath . $type . 's/';
            if (!is_dir($directory)) {
                return [];
            }
            
            $files = [];
            $iterator = new DirectoryIterator($directory);
            
            foreach ($iterator as $file) {
                if ($file->isFile() && !$file->isDot()) {
                    $files[] = [
                        'name' => $file->getFilename(),
                        'size' => $file->getSize(),
                        'modified' => $file->getMTime(),
                        'url' => 'uploads/' . $type . 's/' . $file->getFilename()
                    ];
                }
            }
            
            // Sort by modification time (newest first)
            usort($files, function($a, $b) {
                return $b['modified'] - $a['modified'];
            });
            
            if ($limit) {
                $files = array_slice($files, 0, $limit);
            }
            
            return $files;
        } catch (Exception $e) {
            return [];
        }
    }
    
    public function resizeImage($imagePath, $maxWidth = 800, $maxHeight = 600, $quality = 85) {
        try {
            $fullPath = $this->uploadPath . $imagePath;
            if (!file_exists($fullPath)) {
                return false;
            }
            
            $imageInfo = getimagesize($fullPath);
            if ($imageInfo === false) {
                return false;
            }
            
            list($width, $height, $type) = $imageInfo;
            
            // Calculate new dimensions
            $ratio = min($maxWidth / $width, $maxHeight / $height);
            if ($ratio >= 1) {
                return true; // No need to resize
            }
            
            $newWidth = round($width * $ratio);
            $newHeight = round($height * $ratio);
            
            // Create image resource
            switch ($type) {
                case IMAGETYPE_JPEG:
                    $source = imagecreatefromjpeg($fullPath);
                    break;
                case IMAGETYPE_PNG:
                    $source = imagecreatefrompng($fullPath);
                    break;
                case IMAGETYPE_GIF:
                    $source = imagecreatefromgif($fullPath);
                    break;
                default:
                    return false;
            }
            
            if (!$source) {
                return false;
            }
            
            // Create new image
            $destination = imagecreatetruecolor($newWidth, $newHeight);
            
            // Preserve transparency for PNG and GIF
            if ($type == IMAGETYPE_PNG || $type == IMAGETYPE_GIF) {
                imagealphablending($destination, false);
                imagesavealpha($destination, true);
                $transparent = imagecolorallocatealpha($destination, 255, 255, 255, 127);
                imagefilledrectangle($destination, 0, 0, $newWidth, $newHeight, $transparent);
            }
            
            // Resize image
            imagecopyresampled($destination, $source, 0, 0, 0, 0, $newWidth, $newHeight, $width, $height);
            
            // Save resized image
            switch ($type) {
                case IMAGETYPE_JPEG:
                    $result = imagejpeg($destination, $fullPath, $quality);
                    break;
                case IMAGETYPE_PNG:
                    $result = imagepng($destination, $fullPath, 9);
                    break;
                case IMAGETYPE_GIF:
                    $result = imagegif($destination, $fullPath);
                    break;
                default:
                    $result = false;
            }
            
            // Clean up
            imagedestroy($source);
            imagedestroy($destination);
            
            return $result;
        } catch (Exception $e) {
            return false;
        }
    }
    
    public function createThumbnail($imagePath, $thumbWidth = 200, $thumbHeight = 200) {
        try {
            $fullPath = $this->uploadPath . $imagePath;
            $pathInfo = pathinfo($fullPath);
            $thumbPath = $pathInfo['dirname'] . '/thumb_' . $pathInfo['basename'];
            
            if (!file_exists($fullPath)) {
                return false;
            }
            
            $imageInfo = getimagesize($fullPath);
            if ($imageInfo === false) {
                return false;
            }
            
            list($width, $height, $type) = $imageInfo;
            
            // Create image resource
            switch ($type) {
                case IMAGETYPE_JPEG:
                    $source = imagecreatefromjpeg($fullPath);
                    break;
                case IMAGETYPE_PNG:
                    $source = imagecreatefrompng($fullPath);
                    break;
                case IMAGETYPE_GIF:
                    $source = imagecreatefromgif($fullPath);
                    break;
                default:
                    return false;
            }
            
            if (!$source) {
                return false;
            }
            
            // Calculate crop dimensions for square thumbnail
            $size = min($width, $height);
            $x = ($width - $size) / 2;
            $y = ($height - $size) / 2;
            
            // Create thumbnail
            $thumbnail = imagecreatetruecolor($thumbWidth, $thumbHeight);
            
            // Preserve transparency
            if ($type == IMAGETYPE_PNG || $type == IMAGETYPE_GIF) {
                imagealphablending($thumbnail, false);
                imagesavealpha($thumbnail, true);
                $transparent = imagecolorallocatealpha($thumbnail, 255, 255, 255, 127);
                imagefilledrectangle($thumbnail, 0, 0, $thumbWidth, $thumbHeight, $transparent);
            }
            
            // Resize and crop
            imagecopyresampled($thumbnail, $source, 0, 0, $x, $y, $thumbWidth, $thumbHeight, $size, $size);
            
            // Save thumbnail
            switch ($type) {
                case IMAGETYPE_JPEG:
                    $result = imagejpeg($thumbnail, $thumbPath, 85);
                    break;
                case IMAGETYPE_PNG:
                    $result = imagepng($thumbnail, $thumbPath, 9);
                    break;
                case IMAGETYPE_GIF:
                    $result = imagegif($thumbnail, $thumbPath);
                    break;
                default:
                    $result = false;
            }
            
            // Clean up
            imagedestroy($source);
            imagedestroy($thumbnail);
            
            if ($result) {
                return str_replace($this->uploadPath, 'uploads/', $thumbPath);
            }
            
            return false;
        } catch (Exception $e) {
            return false;
        }
    }
}
?>

