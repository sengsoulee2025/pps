<?php
// includes/contact.php - Contact Management Class
require_once __DIR__ . '/../config/config.php';

class Contact {
    private $pdo;
    
    public function __construct($pdo = null) {
        $this->pdo = $pdo ?: getDBConnection();
    }
    
    /**
     * Add a new contact message
     */
    public function addContact($data) {
        try {
            $stmt = $this->pdo->prepare("
                INSERT INTO contact_messages (
                    name, email, phone, subject, message, 
                    ip_address, user_agent, status, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, 'new', NOW())
            ");
            
            $result = $stmt->execute([
                $data['name'],
                $data['email'],
                $data['phone'] ?? null,
                $data['subject'] ?? 'ຂໍ້ຄວາມທົ່ວໄປ',
                $data['message'],
                $_SERVER['REMOTE_ADDR'] ?? null,
                $_SERVER['HTTP_USER_AGENT'] ?? null
            ]);
            
            if ($result) {
                $contact_id = $this->pdo->lastInsertId();
                
                // Also create a lead record for follow-up
                $this->createLeadFromContact($contact_id, $data);
                
                return $contact_id;
            }
            
            return false;
        } catch (Exception $e) {
            error_log("Contact creation error: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Create a lead record from contact form submission
     */
    private function createLeadFromContact($contact_id, $data) {
        try {
            // Split name into first and last name
            $name_parts = explode(' ', trim($data['name']), 2);
            $first_name = $name_parts[0];
            $last_name = isset($name_parts[1]) ? $name_parts[1] : '';
            
            $stmt = $this->pdo->prepare("
                INSERT INTO lead (
                    first_name, last_name, email, phone, source, 
                    status, priority, notes, contact_message_id, created_at
                ) VALUES (?, ?, ?, ?, 'contact_form', 'new', 'medium', ?, ?, NOW())
            ");
            
            $notes = "ຂໍ້ຄວາມຈາກແບບຟອມຕິດຕໍ່:\n";
            $notes .= "ຫົວຂໍ້: " . ($data['subject'] ?? 'ບໍ່ມີຫົວຂໍ້') . "\n";
            $notes .= "ຂໍ້ຄວາມ: " . $data['message'];
            
            return $stmt->execute([
                $first_name,
                $last_name,
                $data['email'],
                $data['phone'] ?? null,
                $notes,
                $contact_id
            ]);
        } catch (Exception $e) {
            error_log("Lead creation from contact error: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Get all contact messages
     */
    public function getAllContacts($limit = null, $offset = 0, $search = '', $status = '') {
        try {
            $sql = "SELECT * FROM contact_messages WHERE 1=1";
            $params = [];
            
            if (!empty($search)) {
                $sql .= " AND (name LIKE ? OR email LIKE ? OR subject LIKE ? OR message LIKE ?)";
                $params[] = "%$search%";
                $params[] = "%$search%";
                $params[] = "%$search%";
                $params[] = "%$search%";
            }
            
            if (!empty($status)) {
                $sql .= " AND status = ?";
                $params[] = $status;
            }
            
            $sql .= " ORDER BY created_at DESC";
            
            if ($limit) {
                $sql .= " LIMIT ? OFFSET ?";
                $params[] = $limit;
                $params[] = $offset;
            }
            
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($params);
            return $stmt->fetchAll();
        } catch (Exception $e) {
            error_log("Get contacts error: " . $e->getMessage());
            return [];
        }
    }
    
    /**
     * Get contact by ID
     */
    public function getContactById($id) {
        try {
            $stmt = $this->pdo->prepare("SELECT * FROM contact_messages WHERE id = ?");
            $stmt->execute([$id]);
            return $stmt->fetch();
        } catch (Exception $e) {
            error_log("Get contact by ID error: " . $e->getMessage());
            return null;
        }
    }
    
    /**
     * Update contact status
     */
    public function updateContactStatus($id, $status, $admin_notes = null) {
        try {
            $sql = "UPDATE contact_messages SET status = ?, updated_at = NOW()";
            $params = [$status];
            
            if ($admin_notes !== null) {
                $sql .= ", admin_notes = ?";
                $params[] = $admin_notes;
            }
            
            $sql .= " WHERE id = ?";
            $params[] = $id;
            
            $stmt = $this->pdo->prepare($sql);
            return $stmt->execute($params);
        } catch (Exception $e) {
            error_log("Update contact status error: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Delete contact message
     */
    public function deleteContact($id) {
        try {
            $stmt = $this->pdo->prepare("DELETE FROM contact_messages WHERE id = ?");
            return $stmt->execute([$id]);
        } catch (Exception $e) {
            error_log("Delete contact error: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Get contact count
     */
    public function getContactCount($search = '', $status = '') {
        try {
            $sql = "SELECT COUNT(*) as count FROM contact_messages WHERE 1=1";
            $params = [];
            
            if (!empty($search)) {
                $sql .= " AND (name LIKE ? OR email LIKE ? OR subject LIKE ? OR message LIKE ?)";
                $params[] = "%$search%";
                $params[] = "%$search%";
                $params[] = "%$search%";
                $params[] = "%$search%";
            }
            
            if (!empty($status)) {
                $sql .= " AND status = ?";
                $params[] = $status;
            }
            
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($params);
            $result = $stmt->fetch();
            return $result['count'];
        } catch (Exception $e) {
            error_log("Get contact count error: " . $e->getMessage());
            return 0;
        }
    }
    
    /**
     * Get recent contacts
     */
    public function getRecentContacts($limit = 5) {
        try {
            $stmt = $this->pdo->prepare("
                SELECT * FROM contact_messages 
                ORDER BY created_at DESC 
                LIMIT ?
            ");
            $stmt->execute([$limit]);
            return $stmt->fetchAll();
        } catch (Exception $e) {
            error_log("Get recent contacts error: " . $e->getMessage());
            return [];
        }
    }
    
    /**
     * Mark contact as read
     */
    public function markAsRead($id) {
        return $this->updateContactStatus($id, 'read');
    }
    
    /**
     * Mark contact as replied
     */
    public function markAsReplied($id, $admin_notes = null) {
        return $this->updateContactStatus($id, 'replied', $admin_notes);
    }
    
    /**
     * Get contact statistics
     */
    public function getContactStats() {
        try {
            $stmt = $this->pdo->query("
                SELECT 
                    COUNT(*) as total,
                    SUM(CASE WHEN status = 'new' THEN 1 ELSE 0 END) as new_count,
                    SUM(CASE WHEN status = 'read' THEN 1 ELSE 0 END) as read_count,
                    SUM(CASE WHEN status = 'replied' THEN 1 ELSE 0 END) as replied_count,
                    SUM(CASE WHEN DATE(created_at) = CURDATE() THEN 1 ELSE 0 END) as today_count,
                    SUM(CASE WHEN created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY) THEN 1 ELSE 0 END) as week_count
                FROM contact_messages
            ");
            return $stmt->fetch();
        } catch (Exception $e) {
            error_log("Get contact stats error: " . $e->getMessage());
            return [
                'total' => 0,
                'new_count' => 0,
                'read_count' => 0,
                'replied_count' => 0,
                'today_count' => 0,
                'week_count' => 0
            ];
        }
    }
}
?>

