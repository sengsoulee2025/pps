<?php
// ໄຟລ໌: includes/plot.php
class Plot {
    private $pdo;
    public function __construct($pdo) { $this->pdo = $pdo; }
	
	public function getFeaturedPlots($limit = 8) {
        try {
            $sql = "SELECT p.*, pr.name as project_name, pr.location as project_location,
                           pz.currency, (p.area * pz.price_per_sqm) AS calculated_price
                    FROM plot p
                    JOIN project pr ON p.project_id = pr.id
                    LEFT JOIN project_zones pz ON p.zone_id = pz.id
                    WHERE p.status = 'available' AND pr.status = 'active'
                    ORDER BY p.created_at DESC
                    LIMIT :limit";
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindValue(':limit', (int) $limit, PDO::PARAM_INT);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log($e->getMessage());
            return [];
        }
    }
	
    public function getAllPlots() {
        try {
            $sql = "SELECT p.*, pr.name as project_name, pz.currency, (p.area * pz.price_per_sqm) AS calculated_price
                    FROM plot p
                    LEFT JOIN project pr ON p.project_id = pr.id
                    LEFT JOIN project_zones pz ON p.zone_id = pz.id
                    ORDER BY p.project_id, p.id DESC";
            return $this->pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) { error_log($e->getMessage()); return []; }
    }
    public function getPlotById($id) {
        try {
            $stmt = $this->pdo->prepare("SELECT * FROM plot WHERE id = ?");
            $stmt->execute([$id]);
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (Exception $e) { return null; }
    }
    public function isPlotNumberTaken($plotNumber, $projectId, $excludePlotId = null) {
        try {
            $sql = "SELECT COUNT(*) FROM plot WHERE plot_number = ? AND project_id = ?";
            $params = [$plotNumber, $projectId];
            if ($excludePlotId !== null) { $sql .= " AND id != ?"; $params[] = $excludePlotId; }
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($params);
            return $stmt->fetchColumn() > 0;
        } catch (Exception $e) { error_log($e->getMessage()); return true; }
    }
    public function createPlot($data) {
        try {
            $sql = "INSERT INTO plot (project_id, plot_number, area, zone_id, status) VALUES (?, ?, ?, ?, ?)";
            $stmt = $this->pdo->prepare($sql);
            return $stmt->execute([$data['project_id'], $data['plot_number'], $data['area'], $data['zone_id'], 'available']);
        } catch (Exception $e) { throw new Exception($e->getMessage()); }
    }
    public function updatePlot($id, $data) {
        try {
            $sql = "UPDATE plot SET project_id = ?, plot_number = ?, area = ?, zone_id = ?, status = ? WHERE id = ?";
            $stmt = $this->pdo->prepare($sql);
            return $stmt->execute([$data['project_id'], $data['plot_number'], $data['area'], $data['zone_id'], $data['status'], $id]);
        } catch (Exception $e) { throw new Exception($e->getMessage()); }
    }
    public function deletePlot($id) {
        try {
            $stmt = $this->pdo->prepare("DELETE FROM plot WHERE id = ?");
            return $stmt->execute([$id]);
        } catch (Exception $e) { throw new Exception($e->getMessage()); }
    }
}
?>