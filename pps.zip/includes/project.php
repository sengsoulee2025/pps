<?php
// File: includes/project.php (ฉบับสมบูรณ์)
class Project {
    private $pdo;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    public function getAllProjects($limit = null, $offset = 0, $search = '', $status = '') {
        try {
            $sql = "SELECT p.*, 
                           COUNT(pl.id) as total_plots,
                           SUM(CASE WHEN pl.status = 'available' THEN 1 ELSE 0 END) as available_plots,
                           SUM(CASE WHEN pl.status = 'sold' THEN 1 ELSE 0 END) as sold_plots
                    FROM project p
                    LEFT JOIN plot pl ON p.id = pl.project_id
                    WHERE 1=1";
            $params = [];
            
            if (!empty($search)) {
                $sql .= " AND (p.name LIKE ? OR p.location LIKE ?)";
                $params[] = "%$search%";
                $params[] = "%$search%";
            }
            
            if (!empty($status)) {
                $sql .= " AND p.status = ?";
                $params[] = $status;
            }
            
            $sql .= " GROUP BY p.id ORDER BY p.created_at DESC";
            
            if ($limit !== null) {
                $sql .= " LIMIT " . (int)$limit . " OFFSET " . (int)$offset;
            }
            
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($params);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log($e->getMessage());
            return [];
        }
    }
    
    public function getProjectById($id) {
        try {
             $stmt = $this->pdo->prepare("
                SELECT p.*, COUNT(pl.id) as total_plots
                FROM project p
                LEFT JOIN plot pl ON p.id = pl.project_id
                WHERE p.id = ? GROUP BY p.id
            ");
            $stmt->execute([$id]);
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (Exception $e) { return null; }
    }

    public function isNameTaken($name, $excludeId = null) {
        try {
            $sql = "SELECT COUNT(*) FROM project WHERE name = ?";
            $params = [$name];
            if ($excludeId !== null) { $sql .= " AND id != ?"; $params[] = $excludeId; }
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($params);
            return $stmt->fetchColumn() > 0;
        } catch (Exception $e) { return true; }
    }
    
    public function createProject($data) {
        try {
            $stmt = $this->pdo->prepare("INSERT INTO project (name, location, description, master_plan_url, video_url, status) VALUES (?, ?, ?, ?, ?, ?)");
            return $stmt->execute([ $data['name'], $data['location'], $data['description'] ?? null, $data['master_plan_url'] ?? null, $data['video_url'] ?? null, $data['status'] ?? 'active' ]);
        } catch (Exception $e) { throw new Exception($e->getMessage()); }
    }
    
    public function updateProject($id, $data) {
        try {
            $fields = []; $params = [];
            foreach ($data as $key => $value) { $fields[] = "$key = ?"; $params[] = $value; }
            if (empty($fields)) return true;
            $params[] = $id;
            $sql = "UPDATE project SET " . implode(', ', $fields) . " WHERE id = ?";
            $stmt = $this->pdo->prepare($sql);
            return $stmt->execute($params);
        } catch (Exception $e) { throw new Exception($e->getMessage()); }
    }
    
    public function deleteProject($id) {
        try {
            $stmtCheck = $this->pdo->prepare("SELECT COUNT(*) FROM plot WHERE project_id = ?");
            $stmtCheck->execute([$id]);
            if ($stmtCheck->fetchColumn() > 0) { return false; }
            $stmtProject = $this->pdo->prepare("DELETE FROM project WHERE id = ?");
            return $stmtProject->execute([$id]);
        } catch (Exception $e) { throw new Exception($e->getMessage()); }
    }

    public function getFeaturedProjects($limit = 3) {
        try {
            $sql = "SELECT p.*, COUNT(pl.id) as total_plots,
                           SUM(CASE WHEN pl.status = 'available' THEN 1 ELSE 0 END) as available_plots
                    FROM project p
                    LEFT JOIN plot pl ON p.id = pl.project_id
                    WHERE p.status = 'active'
                    GROUP BY p.id
                    ORDER BY p.created_at DESC
                    LIMIT :limit";
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindValue(':limit', (int) $limit, PDO::PARAM_INT);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log($e->getMessage());
            return [];
        }
    }

    // === ฟังก์ชันที่ขาดไป, เพิ่มกลับเข้ามา ===
    public function getProjectCount($search = '', $status = '') {
        try {
            $sql = "SELECT COUNT(DISTINCT p.id) as count FROM project p WHERE 1=1";
            $params = [];
            if (!empty($search)) {
                $sql .= " AND (p.name LIKE ? OR p.location LIKE ?)";
                $params[] = "%$search%";
                $params[] = "%$search%";
            }
            if (!empty($status)) {
                $sql .= " AND p.status = ?";
                $params[] = $status;
            }
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($params);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            return $result['count'] ?? 0;
        } catch (Exception $e) { 
            error_log($e->getMessage());
            return 0; 
        }
    }
}
?>