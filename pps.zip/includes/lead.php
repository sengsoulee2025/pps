<?php
require_once __DIR__ . '/../config/config.php';

class Lead {
    private $pdo;
    
    public function __construct() {
        $this->pdo = getDBConnection();
    }
    
    public function getAllLeads($limit = null, $offset = 0, $search = '', $status = '', $assigned_to = null) {
        try {
            $sql = "SELECT l.*, e.first_name as assigned_first_name, e.last_name as assigned_last_name, 
                           pr.name as project_name, p.plot_number 
                    FROM lead l 
                    LEFT JOIN employee e ON l.assigned_to = e.id 
                    LEFT JOIN project pr ON l.interested_project_id = pr.id 
                    LEFT JOIN plot p ON l.interested_plot_id = p.id 
                    WHERE 1=1";
            $params = [];
            
            if (!empty($search)) {
                $sql .= " AND (l.first_name LIKE ? OR l.last_name LIKE ? OR l.phone LIKE ? OR l.email LIKE ?)";
                $params[] = "%$search%";
                $params[] = "%$search%";
                $params[] = "%$search%";
                $params[] = "%$search%";
            }
            
            if (!empty($status)) {
                $sql .= " AND l.status = ?";
                $params[] = $status;
            }
            
            if ($assigned_to) {
                $sql .= " AND l.assigned_to = ?";
                $params[] = $assigned_to;
            }
            
            $sql .= " ORDER BY l.created_at DESC";
            
            if ($limit) {
                $sql .= " LIMIT ? OFFSET ?";
                $params[] = $limit;
                $params[] = $offset;
            }
            
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($params);
            return $stmt->fetchAll();
        } catch (Exception $e) {
            return [];
        }
    }
    
    public function getLeadById($id) {
        try {
            $stmt = $this->pdo->prepare("SELECT l.*, e.first_name as assigned_first_name, e.last_name as assigned_last_name, 
                                               pr.name as project_name, p.plot_number 
                                        FROM lead l 
                                        LEFT JOIN employee e ON l.assigned_to = e.id 
                                        LEFT JOIN project pr ON l.interested_project_id = pr.id 
                                        LEFT JOIN plot p ON l.interested_plot_id = p.id 
                                        WHERE l.id = ?");
            $stmt->execute([$id]);
            return $stmt->fetch();
        } catch (Exception $e) {
            return null;
        }
    }
    
    public function createLead($data) {
        try {
            $stmt = $this->pdo->prepare("INSERT INTO lead (first_name, last_name, email, phone, source, status, priority, interested_project_id, interested_plot_id, budget_min, budget_max, notes, assigned_to, next_follow_up) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([
                $data['first_name'],
                $data['last_name'],
                $data['email'] ?? null,
                $data['phone'],
                $data['source'] ?? null,
                $data['status'] ?? 'new',
                $data['priority'] ?? 'medium',
                $data['interested_project_id'] ?? null,
                $data['interested_plot_id'] ?? null,
                $data['budget_min'] ?? null,
                $data['budget_max'] ?? null,
                $data['notes'] ?? null,
                $data['assigned_to'] ?? null,
                $data['next_follow_up'] ?? null
            ]);
            return $this->pdo->lastInsertId();
        } catch (Exception $e) {
            return false;
        }
    }
    
    public function updateLead($id, $data) {
        try {
            $stmt = $this->pdo->prepare("UPDATE lead SET first_name = ?, last_name = ?, email = ?, phone = ?, source = ?, status = ?, priority = ?, interested_project_id = ?, interested_plot_id = ?, budget_min = ?, budget_max = ?, notes = ?, assigned_to = ?, next_follow_up = ? WHERE id = ?");
            $stmt->execute([
                $data['first_name'],
                $data['last_name'],
                $data['email'] ?? null,
                $data['phone'],
                $data['source'] ?? null,
                $data['status'],
                $data['priority'],
                $data['interested_project_id'] ?? null,
                $data['interested_plot_id'] ?? null,
                $data['budget_min'] ?? null,
                $data['budget_max'] ?? null,
                $data['notes'] ?? null,
                $data['assigned_to'] ?? null,
                $data['next_follow_up'] ?? null,
                $id
            ]);
            return true;
        } catch (Exception $e) {
            return false;
        }
    }
    
    public function deleteLead($id) {
        try {
            $stmt = $this->pdo->prepare("DELETE FROM lead WHERE id = ?");
            $stmt->execute([$id]);
            return true;
        } catch (Exception $e) {
            return false;
        }
    }
    
    public function convertToCustomer($lead_id, $customer_data, $user_data = null) {
        try {
            $this->pdo->beginTransaction();
            
            // Get lead data
            $lead = $this->getLeadById($lead_id);
            if (!$lead) {
                throw new Exception("Lead not found");
            }
            
            $customer_id = null;
            $user_id = null;
            
            // Create user account if provided
            if ($user_data) {
                $auth = new Auth();
                $user_id = $auth->register($user_data['username'], $user_data['email'], $user_data['password'], 'customer');
                if (!$user_id) {
                    throw new Exception("Failed to create user account");
                }
            }
            
            // Create customer
            $customer = new Customer();
            $customer_data['username_id'] = $user_id;
            $customer_data['first_name'] = $customer_data['first_name'] ?? $lead['first_name'];
            $customer_data['last_name'] = $customer_data['last_name'] ?? $lead['last_name'];
            $customer_data['phone'] = $customer_data['phone'] ?? $lead['phone'];
            $customer_data['email'] = $customer_data['email'] ?? $lead['email'];
            
            $customer_id = $customer->createCustomer($customer_data);
            if (!$customer_id) {
                throw new Exception("Failed to create customer");
            }
            
            // Update lead with converted customer ID
            $stmt = $this->pdo->prepare("UPDATE lead SET converted_to_customer_id = ?, status = 'converted' WHERE id = ?");
            $stmt->execute([$customer_id, $lead_id]);
            
            $this->pdo->commit();
            return $customer_id;
        } catch (Exception $e) {
            $this->pdo->rollBack();
            return false;
        }
    }
    
    public function getLeadContactHistory($lead_id) {
        try {
            $stmt = $this->pdo->prepare("SELECT ch.*, e.first_name as employee_first_name, e.last_name as employee_last_name 
                                        FROM contact_history ch 
                                        JOIN employee e ON ch.employee_id = e.id 
                                        WHERE ch.lead_id = ? 
                                        ORDER BY ch.contact_date DESC");
            $stmt->execute([$lead_id]);
            return $stmt->fetchAll();
        } catch (Exception $e) {
            return [];
        }
    }
    
    public function addContactHistory($data) {
        try {
            $stmt = $this->pdo->prepare("INSERT INTO contact_history (lead_id, employee_id, contact_type, contact_date, duration_minutes, outcome, notes, next_action) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([
                $data['lead_id'],
                $data['employee_id'],
                $data['contact_type'] ?? null,
                $data['contact_date'] ?? date('Y-m-d H:i:s'),
                $data['duration_minutes'] ?? null,
                $data['outcome'] ?? null,
                $data['notes'] ?? null,
                $data['next_action'] ?? null
            ]);
            
            // Update lead's last contact date
            $stmt = $this->pdo->prepare("UPDATE lead SET last_contact_date = ? WHERE id = ?");
            $stmt->execute([date('Y-m-d H:i:s'), $data['lead_id']]);
            
            return $this->pdo->lastInsertId();
        } catch (Exception $e) {
            return false;
        }
    }
    
    public function getLeadCount($search = '', $status = '', $assigned_to = null) {
        try {
            $sql = "SELECT COUNT(*) as count FROM lead l WHERE 1=1";
            $params = [];
            
            if (!empty($search)) {
                $sql .= " AND (l.first_name LIKE ? OR l.last_name LIKE ? OR l.phone LIKE ? OR l.email LIKE ?)";
                $params[] = "%$search%";
                $params[] = "%$search%";
                $params[] = "%$search%";
                $params[] = "%$search%";
            }
            
            if (!empty($status)) {
                $sql .= " AND l.status = ?";
                $params[] = $status;
            }
            
            if ($assigned_to) {
                $sql .= " AND l.assigned_to = ?";
                $params[] = $assigned_to;
            }
            
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($params);
            $result = $stmt->fetch();
            return $result['count'];
        } catch (Exception $e) {
            return 0;
        }
    }
    
    public function getLeadsRequiringFollowUp($employee_id = null) {
        try {
            $sql = "SELECT l.*, e.first_name as assigned_first_name, e.last_name as assigned_last_name 
                    FROM lead l 
                    LEFT JOIN employee e ON l.assigned_to = e.id 
                    WHERE l.next_follow_up <= NOW() AND l.status NOT IN ('converted', 'lost')";
            $params = [];
            
            if ($employee_id) {
                $sql .= " AND l.assigned_to = ?";
                $params[] = $employee_id;
            }
            
            $sql .= " ORDER BY l.next_follow_up ASC";
            
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($params);
            return $stmt->fetchAll();
        } catch (Exception $e) {
            return [];
        }
    }
    
    public function updateFollowUpDate($lead_id, $next_follow_up) {
        try {
            $stmt = $this->pdo->prepare("UPDATE lead SET next_follow_up = ? WHERE id = ?");
            $stmt->execute([$next_follow_up, $lead_id]);
            return true;
        } catch (Exception $e) {
            return false;
        }
    }
}
?>

