<?php
require_once __DIR__ . '/../config/config.php';

class Employee {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    public function getAllEmployees() {
        try {
            $stmt = $this->pdo->prepare(
                "SELECT e.*, u.username, u.email as user_email, u.role 
                 FROM employee e 
                 LEFT JOIN username u ON e.username_id = u.id 
                 ORDER BY e.first_name ASC"
            );
            $stmt->execute();
            // fetchAll() will return an empty array if no rows are found
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log($e->getMessage());
            // In case of an error, also return an empty array to prevent fatal errors
            return [];
        }
    }

    public function getEmployeeById($id) {
        try {
            $stmt = $this->pdo->prepare(
                "SELECT e.*, u.email as user_email, u.role 
                 FROM employee e
                 LEFT JOIN username u ON e.username_id = u.id
                 WHERE e.id = ?"
            );
            $stmt->execute([$id]);
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log($e->getMessage());
            return null; // Returning null here is okay as we usually check if a single item exists
        }
    }

    public function employeeIdExists($employee_id) {
        $stmt = $this->pdo->prepare("SELECT id FROM employee WHERE employee_id = ?");
        $stmt->execute([$employee_id]);
        return $stmt->fetch() !== false;
    }

    public function createEmployee($data) {
        $this->pdo->beginTransaction();
        try {
            // Check for duplicate email
            $stmt = $this->pdo->prepare("SELECT id FROM username WHERE email = ?");
            $stmt->execute([$data['email']]);
            if ($stmt->fetch()) {
                $this->pdo->rollBack();
                return ['success' => false, 'message' => 'This email is already in use.'];
            }
            // Check for duplicate employee ID
            if ($this->employeeIdExists($data['employee_id'])) {
                $this->pdo->rollBack();
                return ['success' => false, 'message' => 'This Employee ID is already in use.'];
            }

            // Create username record
            $password_hash = password_hash($data['password'], PASSWORD_BCRYPT);
            $user_stmt = $this->pdo->prepare(
                "INSERT INTO username (username, email, password_hash, role) VALUES (?, ?, ?, ?)"
            );
            $username = $data['username'] ?? explode('@', $data['email'])[0];
            $user_stmt->execute([$username, $data['email'], $password_hash, $data['role']]);
            $user_id = $this->pdo->lastInsertId();

            // Create employee record
            $emp_stmt = $this->pdo->prepare(
                "INSERT INTO employee (employee_id, username_id, first_name, last_name, phone, department, position) 
                 VALUES (?, ?, ?, ?, ?, ?, ?)"
            );
            $emp_stmt->execute([
                $data['employee_id'], $user_id, $data['first_name'], $data['last_name'],
                $data['phone'], $data['department'], $data['position']
            ]);

            $this->pdo->commit();
            return ['success' => true];
        } catch (Exception $e) {
            $this->pdo->rollBack();
            error_log($e->getMessage());
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }
    
    public function updateEmployee($id, $data) {
        $this->pdo->beginTransaction();
        try {
            $stmt = $this->pdo->prepare("SELECT username_id FROM employee WHERE id = ?");
            $stmt->execute([$id]);
            $employee = $stmt->fetch();
            if (!$employee) {
                throw new Exception("Employee not found.");
            }
            $user_id = $employee['username_id'];
            
            // Build and execute employee table update
            $employee_fields = [];
            $employee_params = [];
            $allowed_employee_fields = ['first_name', 'last_name', 'phone', 'department', 'position', 'hire_date', 'salary'];
            foreach ($allowed_employee_fields as $field) {
                if (isset($data[$field])) {
                    $employee_fields[] = "$field = ?";
                    $employee_params[] = $data[$field];
                }
            }
            if (!empty($employee_fields)) {
                $employee_params[] = $id;
                $emp_stmt = $this->pdo->prepare("UPDATE employee SET " . implode(', ', $employee_fields) . " WHERE id = ?");
                $emp_stmt->execute($employee_params);
            }
            
            // Build and execute username table update
            $user_fields = [];
            $user_params = [];
            $allowed_user_fields = ['email', 'role'];
             foreach ($allowed_user_fields as $field) {
                if (isset($data[$field])) {
                    $user_fields[] = "$field = ?";
                    $user_params[] = $data[$field];
                }
            }
            if (!empty($user_fields)) {
                $user_params[] = $user_id;
                $user_stmt = $this->pdo->prepare("UPDATE username SET " . implode(', ', $user_fields) . " WHERE id = ?");
                $user_stmt->execute($user_params);
            }

            $this->pdo->commit();
            return ['success' => true];
        } catch (Exception $e) {
            $this->pdo->rollBack();
            error_log($e->getMessage());
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }
}
?>