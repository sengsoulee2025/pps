<?php
require_once __DIR__ . '/../config/config.php';

class Customer {
    private $pdo;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }
    
    public function getAllCustomers($limit = null, $offset = 0, $search = '') {
        try {
            $sql = "SELECT c.*, u.username, u.email as user_email FROM customer c 
                    LEFT JOIN username u ON c.user_id = u.id"; // CORRECTED
            $params = [];
            
            if (!empty($search)) {
                $sql .= " AND (c.first_name LIKE ? OR c.last_name LIKE ? OR c.phone LIKE ? OR u.email LIKE ?)";
                $searchParam = "%$search%";
                array_push($params, $searchParam, $searchParam, $searchParam, $searchParam);
            }
            
            $sql .= " ORDER BY c.created_at DESC";
            
            if ($limit !== null) {
                $sql .= " LIMIT " . (int)$limit . " OFFSET " . (int)$offset;
            }
            
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($params);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log($e->getMessage());
            return [];
        }
    }
    
    public function getCustomerById($id) {
        try {
            $stmt = $this->pdo->prepare("SELECT c.*, u.username, u.email as user_email 
                                         FROM customer c 
                                         LEFT JOIN username u ON c.user_id = u.id -- CORRECTED
                                         WHERE c.id = ?");
            $stmt->execute([$id]);
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log($e->getMessage());
            return null;
        }
    }

    public function getCustomerByUserId($user_id) {
        try {
            $stmt = $this->pdo->prepare("SELECT * FROM customer WHERE user_id = ?"); // CORRECTED
            $stmt->execute([$user_id]);
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log($e->getMessage());
            return null;
        }
    }
    
    public function createCustomer($data) {
        try {
            $stmt = $this->pdo->prepare("INSERT INTO customer (username_id, first_name, last_name, phone, email, address) VALUES (?, ?, ?, ?, ?, ?)"); // CORRECTED
            $stmt->execute([
                $data['user_id'] ?? null, // CORRECTED
                $data['first_name'],
                $data['last_name'],
                $data['phone'],
                $data['email'] ?? null,
                $data['address'] ?? null 
            ]);
            return $this->pdo->lastInsertId();
        } catch (Exception $e) {
            // Temporarily show the real error to help debug if problems persist
            die("DATABASE ERROR IN createCustomer(): " . $e->getMessage());
        }
    }
    
    public function updateCustomer($id, $data) {
        try {
            $stmt = $this->pdo->prepare("UPDATE customer SET first_name = ?, last_name = ?, phone = ?, email = ?, address = ? WHERE id = ?");
            $stmt->execute([
                $data['first_name'],
                $data['last_name'],
                $data['phone'],
                $data['email'] ?? null,
                $data['address'] ?? null,
                $id
            ]);
            return true;
        } catch (Exception $e) {
            error_log($e->getMessage());
            return false;
        }
    }
    
    public function deleteCustomer($id) {
        try {
            $stmt = $this->pdo->prepare("DELETE FROM customer WHERE id = ?");
            $stmt->execute([$id]);
            return true;
        } catch (Exception $e) {
            error_log($e->getMessage());
            return false;
        }
    }
    
    public function getCustomerFavorites($customer_id) {
        try {
            $stmt = $this->pdo->prepare("SELECT p.*, pr.name as project_name, pr.location as project_location 
                                         FROM favorite_plot fp 
                                         JOIN plot p ON fp.plot_id = p.id 
                                         JOIN project pr ON p.project_id = pr.id 
                                         WHERE fp.customer_id = ? 
                                         ORDER BY fp.created_at DESC");
            $stmt->execute([$customer_id]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log($e->getMessage());
            return [];
        }
    }

    public function getCustomerProperties($customer_id) {
        try {
            $stmt = $this->pdo->prepare(
                "SELECT p.*, pr.name as project_name, s.sale_date 
                 FROM sale s
                 JOIN plot p ON s.plot_id = p.id
                 JOIN project pr ON p.project_id = pr.id
                 WHERE s.customer_id = ? AND s.status = 'completed'
                 ORDER BY s.sale_date DESC"
            );
            $stmt->execute([$customer_id]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log($e->getMessage());
            return [];
        }
    }
    
    public function addToFavorites($customer_id, $plot_id) {
        try {
            $stmt = $this->pdo->prepare("INSERT IGNORE INTO favorite_plot (customer_id, plot_id) VALUES (?, ?)");
            $stmt->execute([$customer_id, $plot_id]);
            return true;
        } catch (Exception $e) {
            error_log($e->getMessage());
            return false;
        }
    }
    
    public function removeFromFavorites($customer_id, $plot_id) {
        try {
            $stmt = $this->pdo->prepare("DELETE FROM favorite_plot WHERE customer_id = ? AND plot_id = ?");
            return $stmt->execute([$customer_id, $plot_id]);
        } catch (Exception $e) {
            error_log($e->getMessage());
            return false;
        }
    }
    
    public function isInFavorites($customer_id, $plot_id) {
        try {
            $stmt = $this->pdo->prepare("SELECT id FROM favorite_plot WHERE customer_id = ? AND plot_id = ?");
            $stmt->execute([$customer_id, $plot_id]);
            return $stmt->fetch() !== false;
        } catch (Exception $e) {
            error_log($e->getMessage());
            return false;
        }
    }
    
    public function getCustomerAppointments($customer_id) {
        try {
            $stmt = $this->pdo->prepare("SELECT a.*, e.first_name as employee_first_name, e.last_name as employee_last_name 
                                         FROM appointment a 
                                         JOIN employee e ON a.employee_id = e.id 
                                         WHERE a.customer_id = ? 
                                         ORDER BY a.appointment_date DESC");
            $stmt->execute([$customer_id]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log($e->getMessage());
            return [];
        }
    }
    
    public function createAppointment($data) {
        try {
            $stmt = $this->pdo->prepare("INSERT INTO appointment (customer_id, employee_id, appointment_date, purpose, status) VALUES (?, ?, ?, ?, 'scheduled')");
            return $stmt->execute([
                $data['customer_id'],
                $data['employee_id'],
                $data['appointment_date'],
                $data['purpose']
            ]);
        } catch (Exception $e) {
            error_log($e->getMessage());
            return false;
        }
    }
    
    public function getCustomerCount($search = '') {
        try {
            $sql = "SELECT COUNT(*) as count FROM customer c 
                    LEFT JOIN username u ON c.user_id = u.id -- CORRECTED
                    WHERE 1=1";
            $params = [];
            
            if (!empty($search)) {
                $sql .= " AND (c.first_name LIKE ? OR c.last_name LIKE ? OR c.phone LIKE ? OR c.email LIKE ?)";
                $searchParam = "%$search%";
                array_push($params, $searchParam, $searchParam, $searchParam, $searchParam);
            }
            
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($params);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            return $result['count'] ?? 0;
        } catch (Exception $e) {
            error_log($e->getMessage());
            return 0;
        }
    }
}
?>