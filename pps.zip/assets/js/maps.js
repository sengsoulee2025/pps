// Interactive Maps for PPS Land Management System

class PPSMaps {
    constructor() {
        this.map = null;
        this.markers = [];
        this.infoWindows = [];
        this.defaultCenter = { lat: 17.9757, lng: 102.6331 }; // Vientiane, Laos
        this.defaultZoom = 10;
    }
    
    // Initialize map
    initMap(containerId, options = {}) {
        const container = document.getElementById(containerId);
        if (!container) {
            console.error('Map container not found:', containerId);
            return false;
        }
        
        // Check if Google Maps is available
        if (typeof google === 'undefined' || !google.maps) {
            this.createFallbackMap(container);
            return false;
        }
        
        const mapOptions = {
            center: options.center || this.defaultCenter,
            zoom: options.zoom || this.defaultZoom,
            mapTypeId: google.maps.MapTypeId.ROADMAP,
            styles: this.getMapStyles(),
            ...options
        };
        
        this.map = new google.maps.Map(container, mapOptions);
        return true;
    }
    
    // Create fallback map when Google Maps is not available
    createFallbackMap(container) {
        container.innerHTML = `
            <div style="width: 100%; height: 100%; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); display: flex; align-items: center; justify-content: center; color: white; text-align: center; border-radius: 15px;">
                <div>
                    <div style="font-size: 3rem; margin-bottom: 1rem;">🗺️</div>
                    <h3>Interactive Map</h3>
                    <p>Map will be displayed here with project locations</p>
                    <p style="font-size: 0.9rem; opacity: 0.8; margin-top: 1rem;">Google Maps integration available in production</p>
                </div>
            </div>
        `;
    }
    
    // Load and display projects on map
    async loadProjects() {
        try {
            const response = await fetch('api/maps.php?action=projects');
            const data = await response.json();
            
            if (data.success) {
                this.displayProjects(data.projects);
            } else {
                console.error('Failed to load projects:', data.message);
            }
        } catch (error) {
            console.error('Error loading projects:', error);
        }
    }
    
    // Display projects as markers
    displayProjects(projects) {
        if (!this.map) return;
        
        this.clearMarkers();
        
        projects.forEach(project => {
            const marker = new google.maps.Marker({
                position: project.coordinates,
                map: this.map,
                title: project.name,
                icon: this.getProjectIcon(project.status)
            });
            
            const infoWindow = new google.maps.InfoWindow({
                content: this.createProjectInfoWindow(project)
            });
            
            marker.addListener('click', () => {
                this.closeAllInfoWindows();
                infoWindow.open(this.map, marker);
            });
            
            this.markers.push(marker);
            this.infoWindows.push(infoWindow);
        });
        
        // Fit map to show all markers
        if (this.markers.length > 0) {
            const bounds = new google.maps.LatLngBounds();
            this.markers.forEach(marker => {
                bounds.extend(marker.getPosition());
            });
            this.map.fitBounds(bounds);
        }
    }
    
    // Load and display project details with plots
    async loadProjectDetails(projectId) {
        try {
            const response = await fetch(`api/maps.php?action=project_details&id=${projectId}`);
            const data = await response.json();
            
            if (data.success) {
                this.displayProjectDetails(data.project, data.plots);
            } else {
                console.error('Failed to load project details:', data.message);
            }
        } catch (error) {
            console.error('Error loading project details:', error);
        }
    }
    
    // Display project details with individual plots
    displayProjectDetails(project, plots) {
        if (!this.map) return;
        
        this.clearMarkers();
        
        // Center map on project
        this.map.setCenter(project.coordinates);
        this.map.setZoom(15);
        
        // Add project marker
        const projectMarker = new google.maps.Marker({
            position: project.coordinates,
            map: this.map,
            title: project.name,
            icon: this.getProjectIcon('active'),
            zIndex: 1000
        });
        
        const projectInfoWindow = new google.maps.InfoWindow({
            content: this.createProjectDetailInfoWindow(project)
        });
        
        projectMarker.addListener('click', () => {
            this.closeAllInfoWindows();
            projectInfoWindow.open(this.map, projectMarker);
        });
        
        this.markers.push(projectMarker);
        this.infoWindows.push(projectInfoWindow);
        
        // Add plot markers
        plots.forEach(plot => {
            const plotMarker = new google.maps.Marker({
                position: plot.coordinates,
                map: this.map,
                title: `Plot ${plot.plot_number}`,
                icon: this.getPlotIcon(plot.status)
            });
            
            const plotInfoWindow = new google.maps.InfoWindow({
                content: this.createPlotInfoWindow(plot)
            });
            
            plotMarker.addListener('click', () => {
                this.closeAllInfoWindows();
                plotInfoWindow.open(this.map, plotMarker);
            });
            
            this.markers.push(plotMarker);
            this.infoWindows.push(plotInfoWindow);
        });
    }
    
    // Create info window content for project
    createProjectInfoWindow(project) {
        return `
            <div style="max-width: 300px; padding: 10px;">
                <h3 style="margin: 0 0 10px 0; color: #2c3e50;">${project.name}</h3>
                <p style="margin: 0 0 5px 0; color: #666;"><strong>Location:</strong> ${project.location}</p>
                <p style="margin: 0 0 10px 0; color: #666;">${project.description.substring(0, 100)}...</p>
                <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
                    <span style="color: #3498db;"><strong>${project.total_plots}</strong> Total Plots</span>
                    <span style="color: #27ae60;"><strong>${project.available_plots}</strong> Available</span>
                </div>
                <a href="${project.url}" style="display: inline-block; padding: 8px 16px; background: #3498db; color: white; text-decoration: none; border-radius: 5px; font-size: 14px;">View Details</a>
            </div>
        `;
    }
    
    // Create detailed info window for project
    createProjectDetailInfoWindow(project) {
        return `
            <div style="max-width: 250px; padding: 10px;">
                <h3 style="margin: 0 0 10px 0; color: #2c3e50;">${project.name}</h3>
                <p style="margin: 0 0 10px 0; color: #666;"><strong>Location:</strong> ${project.location}</p>
                <p style="color: #3498db; font-weight: bold;">Project Center</p>
            </div>
        `;
    }
    
    // Create info window content for plot
    createPlotInfoWindow(plot) {
        const statusColors = {
            available: '#27ae60',
            reserved: '#f39c12',
            sold: '#e74c3c'
        };
        
        return `
            <div style="max-width: 250px; padding: 10px;">
                <h3 style="margin: 0 0 10px 0; color: #2c3e50;">Plot ${plot.plot_number}</h3>
                <p style="margin: 0 0 5px 0; color: #666;"><strong>Area:</strong> ${plot.area.toLocaleString()} m²</p>
                <p style="margin: 0 0 5px 0; color: #666;"><strong>Price:</strong> ${this.formatPrice(plot.price)}</p>
                <p style="margin: 0 0 10px 0;">
                    <span style="color: ${statusColors[plot.status]}; font-weight: bold; text-transform: uppercase;">
                        ${plot.status}
                    </span>
                </p>
                <a href="${plot.url}" style="display: inline-block; padding: 8px 16px; background: #3498db; color: white; text-decoration: none; border-radius: 5px; font-size: 14px;">View Details</a>
            </div>
        `;
    }
    
    // Get custom icon for project markers
    getProjectIcon(status) {
        const colors = {
            active: '#27ae60',
            planning: '#f39c12',
            completed: '#3498db'
        };
        
        return {
            url: `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(`
                <svg width="40" height="40" viewBox="0 0 40 40" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="20" cy="20" r="18" fill="${colors[status] || '#3498db'}" stroke="white" stroke-width="3"/>
                    <text x="20" y="26" text-anchor="middle" fill="white" font-family="Arial" font-size="16" font-weight="bold">🏗️</text>
                </svg>
            `)}`,
            scaledSize: new google.maps.Size(40, 40),
            anchor: new google.maps.Point(20, 20)
        };
    }
    
    // Get custom icon for plot markers
    getPlotIcon(status) {
        const colors = {
            available: '#27ae60',
            reserved: '#f39c12',
            sold: '#e74c3c'
        };
        
        return {
            url: `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(`
                <svg width="30" height="30" viewBox="0 0 30 30" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="15" cy="15" r="12" fill="${colors[status] || '#3498db'}" stroke="white" stroke-width="2"/>
                    <text x="15" y="20" text-anchor="middle" fill="white" font-family="Arial" font-size="12" font-weight="bold">🏞️</text>
                </svg>
            `)}`,
            scaledSize: new google.maps.Size(30, 30),
            anchor: new google.maps.Point(15, 15)
        };
    }
    
    // Get custom map styles
    getMapStyles() {
        return [
            {
                featureType: 'water',
                elementType: 'geometry',
                stylers: [{ color: '#e9e9e9' }, { lightness: 17 }]
            },
            {
                featureType: 'landscape',
                elementType: 'geometry',
                stylers: [{ color: '#f5f5f5' }, { lightness: 20 }]
            },
            {
                featureType: 'road.highway',
                elementType: 'geometry.fill',
                stylers: [{ color: '#ffffff' }, { lightness: 17 }]
            },
            {
                featureType: 'road.highway',
                elementType: 'geometry.stroke',
                stylers: [{ color: '#ffffff' }, { lightness: 29 }, { weight: 0.2 }]
            },
            {
                featureType: 'road.arterial',
                elementType: 'geometry',
                stylers: [{ color: '#ffffff' }, { lightness: 18 }]
            },
            {
                featureType: 'road.local',
                elementType: 'geometry',
                stylers: [{ color: '#ffffff' }, { lightness: 16 }]
            },
            {
                featureType: 'poi',
                elementType: 'geometry',
                stylers: [{ color: '#f5f5f5' }, { lightness: 21 }]
            },
            {
                featureType: 'poi.park',
                elementType: 'geometry',
                stylers: [{ color: '#dedede' }, { lightness: 21 }]
            },
            {
                elementType: 'labels.text.stroke',
                stylers: [{ visibility: 'on' }, { color: '#ffffff' }, { lightness: 16 }]
            },
            {
                elementType: 'labels.text.fill',
                stylers: [{ saturation: 36 }, { color: '#333333' }, { lightness: 40 }]
            },
            {
                elementType: 'labels.icon',
                stylers: [{ visibility: 'off' }]
            },
            {
                featureType: 'transit',
                elementType: 'geometry',
                stylers: [{ color: '#f2f2f2' }, { lightness: 19 }]
            },
            {
                featureType: 'administrative',
                elementType: 'geometry.fill',
                stylers: [{ color: '#fefefe' }, { lightness: 20 }]
            },
            {
                featureType: 'administrative',
                elementType: 'geometry.stroke',
                stylers: [{ color: '#fefefe' }, { lightness: 17 }, { weight: 1.2 }]
            }
        ];
    }
    
    // Clear all markers
    clearMarkers() {
        this.markers.forEach(marker => {
            marker.setMap(null);
        });
        this.markers = [];
        this.infoWindows = [];
    }
    
    // Close all info windows
    closeAllInfoWindows() {
        this.infoWindows.forEach(infoWindow => {
            infoWindow.close();
        });
    }
    
    // Format price
    formatPrice(price) {
        return new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: 'LAK',
            minimumFractionDigits: 0
        }).format(price);
    }
    
    // Add search functionality to map
    addSearchBox(inputId) {
        if (!this.map || typeof google === 'undefined') return;
        
        const input = document.getElementById(inputId);
        if (!input) return;
        
        const searchBox = new google.maps.places.SearchBox(input);
        this.map.controls[google.maps.ControlPosition.TOP_LEFT].push(input);
        
        // Bias the SearchBox results towards current map's viewport
        this.map.addListener('bounds_changed', () => {
            searchBox.setBounds(this.map.getBounds());
        });
        
        searchBox.addListener('places_changed', () => {
            const places = searchBox.getPlaces();
            
            if (places.length === 0) return;
            
            // Clear existing search markers
            this.clearSearchMarkers();
            
            // For each place, get the icon, name and location
            const bounds = new google.maps.LatLngBounds();
            
            places.forEach(place => {
                if (!place.geometry || !place.geometry.location) return;
                
                const marker = new google.maps.Marker({
                    map: this.map,
                    title: place.name,
                    position: place.geometry.location
                });
                
                this.searchMarkers = this.searchMarkers || [];
                this.searchMarkers.push(marker);
                
                if (place.geometry.viewport) {
                    bounds.union(place.geometry.viewport);
                } else {
                    bounds.extend(place.geometry.location);
                }
            });
            
            this.map.fitBounds(bounds);
        });
    }
    
    // Clear search markers
    clearSearchMarkers() {
        if (this.searchMarkers) {
            this.searchMarkers.forEach(marker => {
                marker.setMap(null);
            });
            this.searchMarkers = [];
        }
    }
    
    // Get user's current location
    getCurrentLocation() {
        return new Promise((resolve, reject) => {
            if (!navigator.geolocation) {
                reject(new Error('Geolocation is not supported'));
                return;
            }
            
            navigator.geolocation.getCurrentPosition(
                position => {
                    resolve({
                        lat: position.coords.latitude,
                        lng: position.coords.longitude
                    });
                },
                error => {
                    reject(error);
                },
                {
                    enableHighAccuracy: true,
                    timeout: 10000,
                    maximumAge: 300000
                }
            );
        });
    }
    
    // Center map on user's location
    async centerOnUserLocation() {
        try {
            const location = await this.getCurrentLocation();
            if (this.map) {
                this.map.setCenter(location);
                this.map.setZoom(12);
                
                // Add marker for user's location
                new google.maps.Marker({
                    position: location,
                    map: this.map,
                    title: 'Your Location',
                    icon: {
                        url: 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(`
                            <svg width="20" height="20" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                <circle cx="10" cy="10" r="8" fill="#3498db" stroke="white" stroke-width="2"/>
                                <circle cx="10" cy="10" r="3" fill="white"/>
                            </svg>
                        `),
                        scaledSize: new google.maps.Size(20, 20),
                        anchor: new google.maps.Point(10, 10)
                    }
                });
            }
        } catch (error) {
            console.error('Error getting user location:', error);
        }
    }
}

// Global instance
window.PPSMaps = new PPSMaps();

// Initialize map when Google Maps is loaded
window.initPPSMap = function() {
    // This function will be called by Google Maps API
    console.log('Google Maps API loaded');
};

// Export for use in other scripts
if (typeof module !== 'undefined' && module.exports) {
    module.exports = PPSMaps;
}

