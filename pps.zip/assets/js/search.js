// Advanced Search Functionality for PPS Land Management System

class PPSSearch {
    constructor() {
        this.searchForm = null;
        this.resultsContainer = null;
        this.loadingIndicator = null;
        this.currentFilters = {};
        this.currentPage = 1;
        this.itemsPerPage = 12;
        this.totalResults = 0;
        this.searchTimeout = null;
    }
    
    // Initialize search functionality
    init(options = {}) {
        this.searchForm = document.getElementById(options.formId || 'searchForm');
        this.resultsContainer = document.getElementById(options.resultsId || 'searchResults');
        this.loadingIndicator = document.getElementById(options.loadingId || 'searchLoading');
        
        if (this.searchForm) {
            this.bindEvents();
            this.loadInitialResults();
        }
    }
    
    // Bind event listeners
    bindEvents() {
        // Search input with debounce
        const searchInput = this.searchForm.querySelector('input[name="search"]');
        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                this.debounceSearch(() => {
                    this.currentFilters.search = e.target.value;
                    this.performSearch();
                });
            });
        }
        
        // Filter inputs
        const filterInputs = this.searchForm.querySelectorAll('select, input[type="number"], input[type="range"]');
        filterInputs.forEach(input => {
            input.addEventListener('change', (e) => {
                this.currentFilters[e.target.name] = e.target.value;
                this.performSearch();
            });
        });
        
        // Form submission
        this.searchForm.addEventListener('submit', (e) => {
            e.preventDefault();
            this.performSearch();
        });
        
        // Clear filters button
        const clearButton = this.searchForm.querySelector('.clear-filters');
        if (clearButton) {
            clearButton.addEventListener('click', () => {
                this.clearFilters();
            });
        }
        
        // Sort options
        const sortSelect = document.getElementById('sortBy');
        if (sortSelect) {
            sortSelect.addEventListener('change', (e) => {
                this.currentFilters.sort = e.target.value;
                this.performSearch();
            });
        }
        
        // View mode toggle
        const viewButtons = document.querySelectorAll('.view-toggle button');
        viewButtons.forEach(button => {
            button.addEventListener('click', (e) => {
                this.toggleViewMode(e.target.dataset.view);
            });
        });
    }
    
    // Debounce search input
    debounceSearch(callback, delay = 500) {
        clearTimeout(this.searchTimeout);
        this.searchTimeout = setTimeout(callback, delay);
    }
    
    // Load initial results
    loadInitialResults() {
        this.currentFilters = this.getFiltersFromForm();
        this.performSearch();
    }
    
    // Get current filters from form
    getFiltersFromForm() {
        const formData = new FormData(this.searchForm);
        const filters = {};
        
        for (let [key, value] of formData.entries()) {
            if (value && value.trim() !== '') {
                filters[key] = value.trim();
            }
        }
        
        return filters;
    }
    
    // Perform search
    async performSearch(page = 1) {
        this.currentPage = page;
        this.showLoading(true);
        
        try {
            const params = new URLSearchParams({
                ...this.currentFilters,
                limit: this.itemsPerPage,
                offset: (page - 1) * this.itemsPerPage
            });
            
            const response = await fetch(`api/search.php?${params}`);
            const data = await response.json();
            
            if (data.success) {
                this.displayResults(data.results);
                this.updatePagination(data.total);
                this.updateResultsCount(data.total);
            } else {
                this.showError(data.message || 'Search failed');
            }
        } catch (error) {
            console.error('Search error:', error);
            this.showError('Search failed. Please try again.');
        } finally {
            this.showLoading(false);
        }
    }
    
    // Display search results
    displayResults(results) {
        if (!this.resultsContainer) return;
        
        if (results.length === 0) {
            this.resultsContainer.innerHTML = this.getNoResultsHTML();
            return;
        }
        
        const viewMode = this.getViewMode();
        let html = '';
        
        if (viewMode === 'grid') {
            html = `<div class="results-grid">${results.map(item => this.getGridItemHTML(item)).join('')}</div>`;
        } else if (viewMode === 'list') {
            html = `<div class="results-list">${results.map(item => this.getListItemHTML(item)).join('')}</div>`;
        } else if (viewMode === 'map') {
            html = this.getMapViewHTML(results);
        }
        
        this.resultsContainer.innerHTML = html;
        
        // Bind result item events
        this.bindResultEvents();
        
        // Load map if in map view
        if (viewMode === 'map') {
            this.loadMapView(results);
        }
    }
    
    // Get grid item HTML
    getGridItemHTML(item) {
        const favoriteButton = window.userLoggedIn ? 
            `<button class="favorite-btn ${item.is_favorite ? 'active' : ''}" data-plot-id="${item.id}" onclick="toggleFavorite(${item.id}, this)">
                <span class="heart">${item.is_favorite ? '❤️' : '🤍'}</span>
            </button>` : '';
        
        return `
            <div class="result-card" data-id="${item.id}">
                <div class="card-image">
                    <img src="${item.image_url || 'assets/images/default-plot.jpg'}" alt="Plot ${item.plot_number}" loading="lazy">
                    <div class="card-overlay">
                        ${favoriteButton}
                        <div class="status-badge status-${item.status}">${item.status}</div>
                    </div>
                </div>
                <div class="card-content">
                    <h3 class="card-title">Plot ${item.plot_number}</h3>
                    <p class="card-subtitle">${item.project_name}</p>
                    <div class="card-details">
                        <div class="detail-item">
                            <span class="label">Area:</span>
                            <span class="value">${item.area.toLocaleString()} m²</span>
                        </div>
                        <div class="detail-item">
                            <span class="label">Price:</span>
                            <span class="value price">${this.formatPrice(item.price)}</span>
                        </div>
                        <div class="detail-item">
                            <span class="label">Price/m²:</span>
                            <span class="value">${this.formatPrice(item.price / item.area)}</span>
                        </div>
                    </div>
                    <div class="card-actions">
                        <a href="plot-details.php?id=${item.id}" class="btn btn-primary">View Details</a>
                        <button class="btn btn-secondary" onclick="showOnMap(${item.id})">Show on Map</button>
                    </div>
                </div>
            </div>
        `;
    }
    
    // Get list item HTML
    getListItemHTML(item) {
        const favoriteButton = window.userLoggedIn ? 
            `<button class="favorite-btn ${item.is_favorite ? 'active' : ''}" data-plot-id="${item.id}" onclick="toggleFavorite(${item.id}, this)">
                <span class="heart">${item.is_favorite ? '❤️' : '🤍'}</span>
            </button>` : '';
        
        return `
            <div class="result-list-item" data-id="${item.id}">
                <div class="list-image">
                    <img src="${item.image_url || 'assets/images/default-plot.jpg'}" alt="Plot ${item.plot_number}" loading="lazy">
                    <div class="status-badge status-${item.status}">${item.status}</div>
                </div>
                <div class="list-content">
                    <div class="list-header">
                        <h3 class="list-title">Plot ${item.plot_number}</h3>
                        <div class="list-price">${this.formatPrice(item.price)}</div>
                        ${favoriteButton}
                    </div>
                    <p class="list-subtitle">${item.project_name} - ${item.location}</p>
                    <div class="list-details">
                        <span class="detail">📐 ${item.area.toLocaleString()} m²</span>
                        <span class="detail">💰 ${this.formatPrice(item.price / item.area)}/m²</span>
                        <span class="detail">📍 ${item.location}</span>
                    </div>
                    <div class="list-actions">
                        <a href="plot-details.php?id=${item.id}" class="btn btn-primary">View Details</a>
                        <button class="btn btn-secondary" onclick="showOnMap(${item.id})">Show on Map</button>
                        <button class="btn btn-secondary" onclick="compareAdd(${item.id})">Compare</button>
                    </div>
                </div>
            </div>
        `;
    }
    
    // Get map view HTML
    getMapViewHTML(results) {
        return `
            <div class="map-view">
                <div class="map-container">
                    <div id="searchResultsMap" style="width: 100%; height: 500px; border-radius: 15px;"></div>
                </div>
                <div class="map-sidebar">
                    <h3>Search Results (${results.length})</h3>
                    <div class="map-results-list">
                        ${results.map(item => this.getMapSidebarItemHTML(item)).join('')}
                    </div>
                </div>
            </div>
        `;
    }
    
    // Get map sidebar item HTML
    getMapSidebarItemHTML(item) {
        return `
            <div class="map-result-item" data-id="${item.id}" onclick="focusMapMarker(${item.id})">
                <div class="map-item-image">
                    <img src="${item.image_url || 'assets/images/default-plot.jpg'}" alt="Plot ${item.plot_number}">
                </div>
                <div class="map-item-content">
                    <h4>Plot ${item.plot_number}</h4>
                    <p>${item.project_name}</p>
                    <div class="map-item-price">${this.formatPrice(item.price)}</div>
                    <div class="map-item-area">${item.area.toLocaleString()} m²</div>
                </div>
                <div class="status-badge status-${item.status}">${item.status}</div>
            </div>
        `;
    }
    
    // Get no results HTML
    getNoResultsHTML() {
        return `
            <div class="no-results">
                <div class="no-results-icon">🔍</div>
                <h3>No Results Found</h3>
                <p>We couldn't find any plots matching your search criteria.</p>
                <div class="no-results-actions">
                    <button class="btn btn-primary" onclick="ppSearch.clearFilters()">Clear Filters</button>
                    <button class="btn btn-secondary" onclick="ppSearch.expandSearch()">Expand Search</button>
                </div>
            </div>
        `;
    }
    
    // Load map view
    loadMapView(results) {
        if (typeof window.PPSMaps !== 'undefined') {
            const mapInitialized = window.PPSMaps.initMap('searchResultsMap', {
                zoom: 12
            });
            
            if (mapInitialized) {
                // Add markers for search results
                this.addSearchResultMarkers(results);
            }
        }
    }
    
    // Add search result markers to map
    addSearchResultMarkers(results) {
        // This would integrate with the maps.js functionality
        // For now, we'll just log the results
        console.log('Adding markers for search results:', results);
    }
    
    // Update pagination
    updatePagination(total) {
        this.totalResults = total;
        const totalPages = Math.ceil(total / this.itemsPerPage);
        
        const paginationContainer = document.getElementById('searchPagination');
        if (!paginationContainer || totalPages <= 1) return;
        
        let html = '<div class="pagination">';
        
        // Previous button
        if (this.currentPage > 1) {
            html += `<button class="pagination-btn" onclick="ppSearch.performSearch(${this.currentPage - 1})">← Previous</button>`;
        }
        
        // Page numbers
        const startPage = Math.max(1, this.currentPage - 2);
        const endPage = Math.min(totalPages, this.currentPage + 2);
        
        for (let i = startPage; i <= endPage; i++) {
            const activeClass = i === this.currentPage ? 'active' : '';
            html += `<button class="pagination-btn ${activeClass}" onclick="ppSearch.performSearch(${i})">${i}</button>`;
        }
        
        // Next button
        if (this.currentPage < totalPages) {
            html += `<button class="pagination-btn" onclick="ppSearch.performSearch(${this.currentPage + 1})">Next →</button>`;
        }
        
        html += '</div>';
        paginationContainer.innerHTML = html;
    }
    
    // Update results count
    updateResultsCount(total) {
        const countContainer = document.getElementById('resultsCount');
        if (countContainer) {
            const start = (this.currentPage - 1) * this.itemsPerPage + 1;
            const end = Math.min(this.currentPage * this.itemsPerPage, total);
            countContainer.textContent = `Showing ${start}-${end} of ${total} results`;
        }
    }
    
    // Show/hide loading indicator
    showLoading(show) {
        if (this.loadingIndicator) {
            this.loadingIndicator.style.display = show ? 'block' : 'none';
        }
        
        if (this.resultsContainer) {
            this.resultsContainer.style.opacity = show ? '0.5' : '1';
        }
    }
    
    // Show error message
    showError(message) {
        if (this.resultsContainer) {
            this.resultsContainer.innerHTML = `
                <div class="search-error">
                    <div class="error-icon">⚠️</div>
                    <h3>Search Error</h3>
                    <p>${message}</p>
                    <button class="btn btn-primary" onclick="ppSearch.performSearch()">Try Again</button>
                </div>
            `;
        }
    }
    
    // Clear all filters
    clearFilters() {
        this.searchForm.reset();
        this.currentFilters = {};
        this.currentPage = 1;
        this.performSearch();
    }
    
    // Expand search (remove some filters)
    expandSearch() {
        // Remove price and area filters to expand search
        delete this.currentFilters.min_price;
        delete this.currentFilters.max_price;
        delete this.currentFilters.min_area;
        delete this.currentFilters.max_area;
        
        // Update form
        const priceInputs = this.searchForm.querySelectorAll('input[name*="price"], input[name*="area"]');
        priceInputs.forEach(input => input.value = '');
        
        this.performSearch();
    }
    
    // Toggle view mode
    toggleViewMode(mode) {
        const viewButtons = document.querySelectorAll('.view-toggle button');
        viewButtons.forEach(btn => btn.classList.remove('active'));
        
        const activeButton = document.querySelector(`[data-view="${mode}"]`);
        if (activeButton) {
            activeButton.classList.add('active');
        }
        
        // Store preference
        localStorage.setItem('searchViewMode', mode);
        
        // Re-render results
        this.performSearch();
    }
    
    // Get current view mode
    getViewMode() {
        const activeButton = document.querySelector('.view-toggle button.active');
        return activeButton ? activeButton.dataset.view : 'grid';
    }
    
    // Bind events for result items
    bindResultEvents() {
        // Add click handlers for result items
        const resultItems = document.querySelectorAll('.result-card, .result-list-item');
        resultItems.forEach(item => {
            item.addEventListener('click', (e) => {
                // Don't trigger if clicking on buttons
                if (e.target.tagName === 'BUTTON' || e.target.tagName === 'A') return;
                
                const plotId = item.dataset.id;
                window.location.href = `plot-details.php?id=${plotId}`;
            });
        });
    }
    
    // Format price
    formatPrice(price) {
        return new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: 'LAK',
            minimumFractionDigits: 0
        }).format(price);
    }
    
    // Save search
    saveSearch() {
        if (!window.userLoggedIn) {
            showAlert('Please log in to save searches', 'info');
            return;
        }
        
        const searchData = {
            filters: this.currentFilters,
            name: prompt('Enter a name for this search:')
        };
        
        if (!searchData.name) return;
        
        // Save to localStorage for now (in production, save to server)
        const savedSearches = JSON.parse(localStorage.getItem('savedSearches') || '[]');
        savedSearches.push({
            ...searchData,
            id: Date.now(),
            created: new Date().toISOString()
        });
        localStorage.setItem('savedSearches', JSON.stringify(savedSearches));
        
        showAlert('Search saved successfully!', 'success');
    }
    
    // Load saved search
    loadSavedSearch(searchId) {
        const savedSearches = JSON.parse(localStorage.getItem('savedSearches') || '[]');
        const search = savedSearches.find(s => s.id === searchId);
        
        if (search) {
            this.currentFilters = search.filters;
            this.updateFormFromFilters();
            this.performSearch();
        }
    }
    
    // Update form from filters
    updateFormFromFilters() {
        Object.keys(this.currentFilters).forEach(key => {
            const input = this.searchForm.querySelector(`[name="${key}"]`);
            if (input) {
                input.value = this.currentFilters[key];
            }
        });
    }
}

// Global search instance
window.ppSearch = new PPSSearch();

// Global functions for use in HTML
window.toggleFavorite = async function(plotId, button) {
    if (!window.userLoggedIn) {
        showAlert('Please log in to manage favorites', 'info');
        return;
    }
    
    try {
        const response = await fetch('api/favorites.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                action: 'toggle',
                plot_id: plotId
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            const heart = button.querySelector('.heart');
            if (data.is_favorite) {
                button.classList.add('active');
                heart.textContent = '❤️';
            } else {
                button.classList.remove('active');
                heart.textContent = '🤍';
            }
            showAlert(data.message, 'success');
        } else {
            showAlert(data.message, 'error');
        }
    } catch (error) {
        console.error('Error toggling favorite:', error);
        showAlert('Failed to update favorites', 'error');
    }
};

window.showOnMap = function(plotId) {
    // This would integrate with the maps functionality
    console.log('Show plot on map:', plotId);
    showAlert('Map integration coming soon!', 'info');
};

window.compareAdd = function(plotId) {
    // Add to comparison list
    let compareList = JSON.parse(localStorage.getItem('compareList') || '[]');
    
    if (compareList.includes(plotId)) {
        showAlert('Plot already in comparison list', 'info');
        return;
    }
    
    if (compareList.length >= 3) {
        showAlert('You can compare up to 3 plots at a time', 'warning');
        return;
    }
    
    compareList.push(plotId);
    localStorage.setItem('compareList', JSON.stringify(compareList));
    
    updateCompareCounter();
    showAlert('Added to comparison list', 'success');
};

window.updateCompareCounter = function() {
    const compareList = JSON.parse(localStorage.getItem('compareList') || '[]');
    const counter = document.getElementById('compareCounter');
    if (counter) {
        counter.textContent = compareList.length;
        counter.style.display = compareList.length > 0 ? 'inline' : 'none';
    }
};

window.focusMapMarker = function(plotId) {
    // Focus on specific marker in map view
    console.log('Focus map marker:', plotId);
};

// Initialize search when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    if (document.getElementById('searchForm')) {
        window.ppSearch.init();
    }
    
    // Update compare counter
    updateCompareCounter();
    
    // Load saved view mode
    const savedViewMode = localStorage.getItem('searchViewMode');
    if (savedViewMode) {
        const viewButton = document.querySelector(`[data-view="${savedViewMode}"]`);
        if (viewButton) {
            viewButton.click();
        }
    }
});

