// Theme Switcher for PPS Land Management System
class ThemeSwitcher {
    constructor() {
        this.currentTheme = localStorage.getItem('pps-theme') || 'light';
        this.init();
    }

    init() {
        this.applyTheme(this.currentTheme);
        this.createThemeSwitcher();
        this.bindEvents();
    }

    applyTheme(theme) {
        document.documentElement.setAttribute('data-theme', theme);
        this.currentTheme = theme;
        localStorage.setItem('pps-theme', theme);
        
        // Update active button
        const buttons = document.querySelectorAll('.theme-option');
        buttons.forEach(btn => {
            btn.classList.remove('active');
            if (btn.dataset.theme === theme) {
                btn.classList.add('active');
            }
        });
    }

    createThemeSwitcher() {
        const switcher = document.createElement('div');
        switcher.className = 'theme-switcher';
        switcher.innerHTML = `
            <h4>ເລືອກຮູບແບບສີ</h4>
            <div class="theme-options">
                <button class="theme-option" data-theme="light">🌞 ສີສະຫວ່າງ</button>
                <button class="theme-option" data-theme="dark1">🌙 ສີເຂັ້ມ 1</button>
                <button class="theme-option" data-theme="dark2">🔥 ສີເຂັ້ມ 2</button>
            </div>
        `;
        
        document.body.appendChild(switcher);
        
        // Set initial active state
        const activeBtn = switcher.querySelector(`[data-theme="${this.currentTheme}"]`);
        if (activeBtn) {
            activeBtn.classList.add('active');
        }
    }

    bindEvents() {
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('theme-option')) {
                const theme = e.target.dataset.theme;
                this.applyTheme(theme);
                
                // Add animation effect
                document.body.style.transition = 'all 0.3s ease';
                setTimeout(() => {
                    document.body.style.transition = '';
                }, 300);
            }
        });
    }

    // Method to get current theme
    getCurrentTheme() {
        return this.currentTheme;
    }

    // Method to set theme programmatically
    setTheme(theme) {
        if (['light', 'dark1', 'dark2'].includes(theme)) {
            this.applyTheme(theme);
        }
    }
}

// Auto-detect system theme preference
function detectSystemTheme() {
    if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
        return 'dark1';
    }
    return 'light';
}

// Initialize theme switcher when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    // If no saved theme, use system preference
    if (!localStorage.getItem('pps-theme')) {
        localStorage.setItem('pps-theme', detectSystemTheme());
    }
    
    window.themeSwitcher = new ThemeSwitcher();
});

// Listen for system theme changes
if (window.matchMedia) {
    window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', (e) => {
        if (!localStorage.getItem('pps-theme')) {
            const newTheme = e.matches ? 'dark1' : 'light';
            window.themeSwitcher.setTheme(newTheme);
        }
    });
}

// Export for use in other files
if (typeof module !== 'undefined' && module.exports) {
    module.exports = ThemeSwitcher;
}

