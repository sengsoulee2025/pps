/*
 * ໄຟລ໌: admin.js
 * ໜ້າທີ່: ຄວບຄຸມ JavaScript ທັງໝົດທີ່ໃຊ້ສະເພາະໃນ Admin Panel
*/

// ເມື່ອໜ້າเว็บໂຫຼດຂໍ້ມູນສຳເລັດແລ້ວ (DOM Ready), ຈຶ່ງເລີ່ມເຮັດວຽກ
document.addEventListener('DOMContentLoaded', function() {
    
    // ໂຕແປ menuToggle ຈະໄປຊອກຫາປຸ່ມທີ່ມີ id="menu-toggle" ໃນໄຟລ໌ header.php
    const menuToggle = document.getElementById('menu-toggle');
    
    // ໂຕແປ navMenu ຈະໄປຊອກຫາແຖບເມນູທີ່ມີ id="main-nav" ໃນໄຟລ໌ header.php
    const navMenu = document.getElementById('main-nav');

    // ກວດສອບກ່ອນວ່າທັງສອງໂຕແປນີ້ມີຢູ່ຈິງໃນໜ້າເວັບ ເພື່ອປ້ອງກັນ Error
    if (menuToggle && navMenu) {
        
        // ເພີ່ມ Event Listener ເພື່ອລໍຖ້າການ 'ຄລິກ' ທີ່ປຸ່ມ menuToggle
        menuToggle.addEventListener('click', function() {
            
            // ເມື່ອມີການຄລິກ, ໃຫ້ "ສະຫຼັບ" (toggle) class 'active' ຢູ່ທີ່ navMenu
            navMenu.classList.toggle('active');

        });
    }
});