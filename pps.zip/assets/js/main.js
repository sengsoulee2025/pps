// ໄຟລ໌ JavaScript ຫຼັກສຳລັບລະບົບຈັດການທີ່ດິນ PPS

// ເມື່ອໜ້າເວັບໂຫຼດຂໍ້ມູນສຳເລັດ (DOM Ready)
document.addEventListener('DOMContentLoaded', function() {
    initializeNavigation();
    initializeSearch();
    initializeFavorites();
    initializeModals();
    initializeAnimations();
});

// ຟັງຊັນກ່ຽວກັບການນຳທາງ (Navigation)
function initializeNavigation() {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');
    
    if (navToggle && navMenu) {
        navToggle.addEventListener('click', function() {
            navMenu.classList.toggle('active');
        });
        
        // ປິດເມນູເມື່ອມີການຄລິກລິ້ງ
        navMenu.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                navMenu.classList.remove('active');
            });
        });
    }
    
    // ເລື່ອນໜ້າเว็บແບບ Smooth ສຳລັບລິ້ງພາຍໃນໜ້າ
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
}

// ຟັງຊັນກ່ຽວກັບການຄົ້ນຫາ ແລະ ການກັ່ນຕອງ
function initializeSearch() {
    const searchForm = document.getElementById('searchForm');
    const searchInput = document.getElementById('searchInput');
    const filterInputs = document.querySelectorAll('.filter-input');
    
    if (searchForm) {
        searchForm.addEventListener('submit', function(e) {
            e.preventDefault();
            performSearch();
        });
    }
    
    if (searchInput) {
        searchInput.addEventListener('input', debounce(performSearch, 500));
    }
    
    filterInputs.forEach(input => {
        input.addEventListener('change', performSearch);
    });
}

function performSearch() {
    const searchInput = document.getElementById('searchInput');
    const projectFilter = document.getElementById('projectFilter');
    const statusFilter = document.getElementById('statusFilter');
    const minPrice = document.getElementById('minPrice');
    const maxPrice = document.getElementById('maxPrice');
    const minArea = document.getElementById('minArea');
    const maxArea = document.getElementById('maxArea');
    
    const params = new URLSearchParams();
    
    if (searchInput && searchInput.value) {
        params.append('search', searchInput.value);
    }
    
    if (projectFilter && projectFilter.value) {
        params.append('project_id', projectFilter.value);
    }
    
    if (statusFilter && statusFilter.value) {
        params.append('status', statusFilter.value);
    }
    
    if (minPrice && minPrice.value) {
        params.append('min_price', minPrice.value);
    }
    
    if (maxPrice && maxPrice.value) {
        params.append('max_price', maxPrice.value);
    }
    
    if (minArea && minArea.value) {
        params.append('min_area', minArea.value);
    }
    
    if (maxArea && maxArea.value) {
        params.append('max_area', maxArea.value);
    }
    
    // ອັບເດດ URL ແລະ ໂຫຼດຜົນການຄົ້ນຫາໃໝ່
    const newUrl = window.location.pathname + '?' + params.toString();
    window.history.pushState({}, '', newUrl);
    
    // ຖ້າຢູ່ໃນໜ້າຄົ້ນຫາ, ໃຫ້ໂຫຼດຜົນລັບໃໝ່
    if (window.location.pathname.includes('search') || window.location.pathname.includes('plots')) {
        loadSearchResults(params.toString());
    }
}

function loadSearchResults(queryString) {
    const resultsContainer = document.getElementById('searchResults');
    if (!resultsContainer) return;
    
    // ສະແດງໄອຄອນກຳລັງໂຫຼດ
    resultsContainer.innerHTML = '<div class="spinner"></div>';
    
    fetch(`api/search.php?${queryString}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                displaySearchResults(data.results);
            } else {
                resultsContainer.innerHTML = '<p class="text-center">Error loading results</p>';
            }
        })
        .catch(error => {
            console.error('Search error:', error);
            resultsContainer.innerHTML = '<p class="text-center">Error loading results</p>';
        });
}

function displaySearchResults(results) {
    const resultsContainer = document.getElementById('searchResults');
    if (!resultsContainer) return;
    
    if (results.length === 0) {
        resultsContainer.innerHTML = '<p class="text-center">No results found</p>';
        return;
    }
    
    let html = '<div class="grid grid-3">';
    results.forEach(plot => {
        html += createPlotCard(plot);
    });
    html += '</div>';
    
    resultsContainer.innerHTML = html;
    initializeAnimations();
}

function createPlotCard(plot) {
    const statusClass = `status-${plot.status}`;
    const imageUrl = plot.image_url || 'assets/images/default-plot.jpg';
    
    return `
        <div class="card plot-card fade-in">
            <img src="${imageUrl}" alt="Plot ${plot.plot_number}" class="card-image">
            <div class="plot-info">
                <span class="plot-area">${plot.area} m²</span>
                <span class="plot-status ${statusClass}">${plot.status}</span>
            </div>
            <h3 class="card-title">Plot ${plot.plot_number}</h3>
            <p class="card-text">${plot.project_name} - ${plot.project_location}</p>
            <div class="card-price">${formatPrice(plot.price)}</div>
            <div class="card-actions">
                <a href="plot-details.php?id=${plot.id}" class="btn">View Details</a>
                <button onclick="toggleFavorite(${plot.id})" class="btn btn-secondary">
                    <i class="heart-icon ${plot.is_favorite ? 'filled' : ''}"></i>
                </button>
            </div>
        </div>
    `;
}

// ຟັງຊັນກ່ຽວກັບລາຍການທີ່ມັກ (Favorites)
function initializeFavorites() {
    document.querySelectorAll('.favorite-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const plotId = this.dataset.plotId;
            toggleFavorite(plotId);
        });
    });
}

function toggleFavorite(plotId) {
    if (!isLoggedIn()) {
        showLoginModal();
        return;
    }
    
    fetch('api/favorites.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            action: 'toggle',
            plot_id: plotId
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            updateFavoriteButton(plotId, data.is_favorite);
            showAlert(data.message, 'success');
        } else {
            showAlert(data.message, 'error');
        }
    })
    .catch(error => {
        console.error('Favorite error:', error);
        showAlert('Error updating favorites', 'error');
    });
}

function updateFavoriteButton(plotId, isFavorite) {
    const btn = document.querySelector(`[data-plot-id="${plotId}"]`);
    if (btn) {
        const icon = btn.querySelector('.heart-icon');
        if (icon) {
            icon.classList.toggle('filled', isFavorite);
        }
    }
}

// ຟັງຊັນກ່ຽວກັບກ່ອງໂຕ້ຕອບ (Modals)
function initializeModals() {
    // ກ່ອງໂຕ້ຕອບສຳລັບລັອກອິນ
    const loginModal = document.getElementById('loginModal');
    const loginBtn = document.getElementById('loginBtn');
    const closeModal = document.querySelectorAll('.modal-close');
    
    if (loginBtn && loginModal) {
        loginBtn.addEventListener('click', () => showModal('loginModal'));
    }
    
    closeModal.forEach(btn => {
        btn.addEventListener('click', function() {
            const modal = this.closest('.modal');
            if (modal) {
                hideModal(modal.id);
            }
        });
    });
    
    // ປິດກ່ອງໂຕ້ຕອບເມື່ອຄລິກພື້ນທີ່ດ້ານນອກ
    window.addEventListener('click', function(e) {
        if (e.target.classList.contains('modal')) {
            hideModal(e.target.id);
        }
    });
}

function showModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'block';
        document.body.style.overflow = 'hidden';
    }
}

function hideModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'none';
        document.body.style.overflow = 'auto';
    }
}

function showLoginModal() {
    showModal('loginModal');
}

// ຟັງຊັນກ່ຽວກັບການເຄື່ອນໄຫວ (Animations)
function initializeAnimations() {
    // ໃຊ້ Intersection Observer ສຳລັບການເຄື່ອນໄຫວແບບ fade-in
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('fade-in');
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);
    
    // ສັງເກດການ์ด ແລະ ส่วนຕ່າງໆທັງໝົດ
    document.querySelectorAll('.card, .section').forEach(el => {
        observer.observe(el);
    });
}

// ຟັງຊັນກ່ຽວກັບການເຊື່ອມຕໍ່ແຜນທີ່ (Map Integration)
function initializeMap(containerId, projects = []) {
    // ສ່ວນນີ້ຈະເຊື່ອມຕໍ່ກັບ Google Maps ຫຼື ບໍລິການແຜນທີ່ອື່ນໆ
    const mapContainer = document.getElementById(containerId);
    if (!mapContainer) return;
    
    // ໃນຕອນນີ້, ເຮົາຈະສ້າງພື້ນທີ່ຕົວຢ່າງໄວ້ກ່ອນ
    mapContainer.innerHTML = `
        <div style="width: 100%; height: 100%; background: #e9ecef; display: flex; align-items: center; justify-content: center; color: #666;">
            <div style="text-align: center;">
                <h3>Interactive Map</h3>
                <p>Map integration will be implemented here</p>
                <p>Projects: ${projects.length}</p>
            </div>
        </div>
    `;
}

// ຟັງຊັນຊ່ວຍເຫຼືອທົ່ວໄປ (Utility Functions)
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

function formatPrice(price) {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'LAK',
        minimumFractionDigits: 0
    }).format(price);
}

function formatArea(area) {
    return `${area.toLocaleString()} m²`;
}

// ກວດສອບວ່າຜູ້ໃຊ້ລັອກອິນແລ້ວບໍ່ (ຄ່ານີ້ຈະຖືກກຳນົດໂດຍ PHP)
function isLoggedIn() {
    return window.userLoggedIn || false;
}

function showAlert(message, type = 'info') {
    const alertContainer = document.getElementById('alertContainer') || createAlertContainer();
    
    const alert = document.createElement('div');
    alert.className = `alert alert-${type}`;
    alert.innerHTML = `
        ${message}
        <button type="button" class="modal-close" onclick="this.parentElement.remove()">&times;</button>
    `;
    
    alertContainer.appendChild(alert);
    
    // ລົບອອກອັດຕະໂນມັດຫຼັງຈາກ 5 ວິນາທີ
    setTimeout(() => {
        if (alert.parentElement) {
            alert.remove();
        }
    }, 5000);
}

function createAlertContainer() {
    const container = document.createElement('div');
    container.id = 'alertContainer';
    container.style.cssText = 'position: fixed; top: 100px; right: 20px; z-index: 3000; max-width: 400px;';
    document.body.appendChild(container);
    return container;
}

// ຟັງຊັນກວດສອບຄວາມຖືກຕ້ອງຂອງຟອມ (Form Validation)
function validateForm(formId) {
    const form = document.getElementById(formId);
    if (!form) return false;
    
    let isValid = true;
    const requiredFields = form.querySelectorAll('[required]');
    
    requiredFields.forEach(field => {
        if (!field.value.trim()) {
            field.classList.add('error');
            isValid = false;
        } else {
            field.classList.remove('error');
        }
    });
    
    return isValid;
}

// ຟັງຊັນສຳລັບຟອມຕິດຕໍ່ (Contact Form)
function submitContactForm(formData) {
    fetch('api/contact.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData)
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showAlert('Message sent successfully!', 'success');
            document.getElementById('contactForm').reset();
        } else {
            showAlert(data.message || 'Error sending message', 'error');
        }
    })
    .catch(error => {
        console.error('Contact form error:', error);
        showAlert('Error sending message', 'error');
    });
}

// ຟັງຊັນສຳລັບການຈອງນັດໝາຍ (Appointment Booking)
function bookAppointment(plotId) {
    if (!isLoggedIn()) {
        showLoginModal();
        return;
    }
    
    // ສະແດງກ່ອງໂຕ້ຕອບການຈອງນັດໝາຍ
    showModal('appointmentModal');
    
    // ກຳນົດ ID ຂອງຕອນດິນໃນຟອມ
    const plotIdInput = document.getElementById('appointmentPlotId');
    if (plotIdInput) {
        plotIdInput.value = plotId;
    }
}

// ຟັງຊັນສຳລັບຄັງຮູບພາບ (Image Gallery)
function initializeGallery() {
    const galleryImages = document.querySelectorAll('.gallery-image');
    
    galleryImages.forEach(img => {
        img.addEventListener('click', function() {
            showImageModal(this.src, this.alt);
        });
    });
}

function showImageModal(src, alt) {
    const modal = document.createElement('div');
    modal.className = 'modal';
    modal.innerHTML = `
        <div class="modal-content" style="max-width: 90%; max-height: 90%;">
            <button class="modal-close">&times;</button>
            <img src="${src}" alt="${alt}" style="width: 100%; height: auto;">
        </div>
    `;
    
    document.body.appendChild(modal);
    modal.style.display = 'block';
    
    modal.querySelector('.modal-close').addEventListener('click', () => {
        modal.remove();
    });
    
    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            modal.remove();
        }
    });
}

// Export ຟັງຊັນຕ່າງໆເພື່ອໃຫ້ສາມາດເອີ້ນໃຊ້ຈາກບ່ອນອື່ນໄດ້
window.PPS = {
    toggleFavorite,
    showModal,
    hideModal,
    showAlert,
    bookAppointment,
    initializeMap,
    formatPrice,
    formatArea
};