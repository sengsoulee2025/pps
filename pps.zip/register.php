<?php
// register.php - ໜ້າລົງທະບຽນ
// ໄຟລ໌ນີ້ຈັດການການລົງທະບຽນຜູ້ໃຊ້ໃໝ່ເຂົ້າສູ່ລະບົບ.

// ເປີດການສະແດງຜົນ Error (ສຳລັບການກວດສອບ) - ຄວນປິດໃນ Production
ini_set("display_errors", 1);
ini_set("display_startup_errors", 1);
error_reporting(E_ALL);

// Start session if not already started
// ກວດສອບວ່າ session ໄດ້ເລີ່ມຕົ້ນແລ້ວບໍ, ຖ້າບໍ່, ໃຫ້ເລີ່ມຕົ້ນ
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// ລວມເອົາໄຟລ໌ການຕັ້ງຄ່າ ແລະ ຟັງຊັນ/ຄລາສທີ່ຈຳເປັນ
require_once __DIR__ . "/config/config.php"; // ໄຟລ໌ການຕັ້ງຄ່າລະບົບ (ເຊັ່ນ: ຂໍ້ມູນຖານຂໍ້ມູນ, ຄ່າຄົງທີ່)
require_once __DIR__ . "/includes/auth.php"; // ຟັງຊັນການກວດສອບສິດ (ເຊັ່ນ: isLoggedIn(), redirect())
require_once __DIR__ . "/includes/customer.php"; // ຄລາສສຳລັບຈັດການຂໍ້ມູນລູກຄ້າ

// ປ່ຽນເສັ້ນທາງຖ້າຜູ້ໃຊ້ໄດ້ເຂົ້າສູ່ລະບົບແລ້ວ
// isLoggedIn(): ຟັງຊັນນີ້ກວດສອບວ່າຜູ້ໃຊ້ໄດ້ເຂົ້າສູ່ລະບົບແລ້ວບໍ
if (isLoggedIn()) {
    redirect("customer/dashboard.php");
}

// $error: ຕົວແປນີ້ເກັບຂໍ້ຄວາມຜິດພາດສຳລັບການລົງທະບຽນ
$error = "";
// $success: ຕົວແປນີ້ເກັບຂໍ້ຄວາມສຳເລັດສຳລັບການລົງທະບຽນ
$success = "";

// ຈັດການການສົ່ງຟອມເມື່ອມີການຮ້ອງຂໍແບບ POST
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // ດຶງຂໍ້ມູນຈາກຟອມ ແລະ ກັ່ນຕອງ
    // sanitizeInput(): ຟັງຊັນນີ້ກັ່ນຕອງຂໍ້ມູນທີ່ປ້ອນເຂົ້າມາເພື່ອປ້ອງກັນ XSS
    $username = sanitizeInput($_POST["username"]);
    $email = sanitizeInput($_POST["email"]);
    $password = $_POST["password"];
    $confirm_password = $_POST["confirm_password"];
    $first_name = sanitizeInput($_POST["first_name"]);
    $last_name = sanitizeInput($_POST["last_name"]);
    $phone = sanitizeInput($_POST["phone"]);

    // ການກວດສອບຂໍ້ມູນ (Validation)
    // ກວດສອບວ່າຂໍ້ມູນທີ່ຈຳເປັນຖືກປ້ອນຄົບຖ້ວນ
    if (empty($username) || empty($email) || empty($password) || empty($first_name) || empty($last_name) || empty($phone)) {
        $error = "ກະລຸນາຕື່ມຂໍ້ມູນທີ່ຈຳເປັນໃຫ້ຄົບຖ້ວນ";
    // ກວດສອບຄວາມຍາວຂອງລະຫັດຜ່ານ
    } elseif (strlen($password) < (defined("PASSWORD_MIN_LENGTH") ? PASSWORD_MIN_LENGTH : 8)) {
        $error = "ລະຫັດຜ່ານຕ້ອງມີຢ່າງໜ້ອຍ " . (defined("PASSWORD_MIN_LENGTH") ? PASSWORD_MIN_LENGTH : 8) . " ຕົວອັກສອນ";
    // ກວດສອບວ່າລະຫັດຜ່ານ ແລະ ຢືນຢັນລະຫັດຜ່ານກົງກັນ
    } elseif ($password !== $confirm_password) {
        $error = "ລະຫັດຜ່ານບໍ່ກົງກັນ";
    // ກວດສອບຮູບແບບອີເມວ
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "ກະລຸນາໃສ່ທີ່ຢູ່ອີເມວທີ່ຖືກຕ້ອງ";
    } else {
        // ເຊື່ອມຕໍ່ຖານຂໍ້ມູນ
        // getDBConnection(): ຟັງຊັນນີ້ສ້າງການເຊື່ອມຕໍ່ຖານຂໍ້ມູນ (ຢູ່ໃນ config/config.php)
        $pdo = getDBConnection(); 
        try {
            // ເລີ່ມຕົ້ນ Transaction ເພື່ອຮັບປະກັນຄວາມຖືກຕ້ອງຂອງຂໍ້ມູນ
            $pdo->beginTransaction();

            // ສ້າງ Object ຂອງ Auth ແລະ ລົງທະບຽນຜູ້ໃຊ້
            // register(): ເມທອດນີ້ລົງທະບຽນຜູ້ໃຊ້ໃໝ່ໃນຕາຕະລາງ users
            $auth = new Auth($pdo);
            $user_id = $auth->register($username, $email, $password, "customer");

            if ($user_id) {
                // ສ້າງ Object ຂອງ Customer ແລະ ເພີ່ມຂໍ້ມູນລູກຄ້າ
                // createCustomer(): ເມທອດນີ້ສ້າງຂໍ້ມູນລູກຄ້າໃນຕາຕະລາງ customers
                $customer = new Customer($pdo);
                $customer_data = [
                    "user_id" => $user_id,
                    "first_name" => $first_name,
                    "last_name" => $last_name,
                    "phone" => $phone,
                    "email" => $email
                ];

                $customer_id = $customer->createCustomer($customer_data);

                if ($customer_id) {
                    // Commit Transaction ຖ້າທຸກຢ່າງສຳເລັດ
                    $pdo->commit();
                    $success = "ສ້າງບັນຊີສຳເລັດແລ້ວ! ຕອນນີ້ທ່ານສາມາດເຂົ້າສູ່ລະບົບໄດ້.";
                } else {
                    // Rollback Transaction ຖ້າມີຂໍ້ຜິດພາດໃນການສ້າງໂປຣໄຟລ໌ລູກຄ້າ
                    $pdo->rollBack();
                    $error = "ເກີດຂໍ້ຜິດພາດໃນການສ້າງໂປຣໄຟລ໌ລູກຄ້າ. ເບີໂທລະສັບ ຫຼື ອີເມວອາດຈະຊ້ຳກັນ.";
                }
            } else {
                // Rollback Transaction ຖ້າມີຂໍ້ຜິດພາດໃນການລົງທະບຽນຜູ້ໃຊ້ (ເຊັ່ນ: ຊື່ຜູ້ໃຊ້/ອີເມວຊ້ຳກັນ)
                $pdo->rollBack();
                $error = "ຊື່ຜູ້ໃຊ້ ຫຼື ອີເມວມີຢູ່ແລ້ວ.";
            }
        } catch (Exception $e) {
            // Rollback Transaction ຖ້າມີຂໍ້ຜິດພາດໃດໆເກີດຂຶ້ນ
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            // ສະແດງຂໍ້ຄວາມຜິດພາດຂອງຖານຂໍ້ມູນ
            $error = "ຂໍ້ຜິດພາດຖານຂໍ້ມູນ: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ລົງທະບຽນ - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .register-container { min-height: 100vh; display: flex; align-items: center; justify-content: center; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 2rem; }
        .register-card { background: white; padding: 3rem; border-radius: 20px; box-shadow: 0 20px 40px rgba(0,0,0,0.1); width: 100%; max-width: 500px; }
        .register-header { text-align: center; margin-bottom: 2rem; }
        .register-header h1 { color: #333; margin-bottom: 0.5rem; }
        .register-header p { color: #666; }
        .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; }
        .form-group { margin-bottom: 1.5rem; }
        .form-label { display: block; margin-bottom: 0.5rem; font-weight: 600; color: #333; }
        .form-control { width: 100%; padding: 1rem; border: 2px solid #e9ecef; border-radius: 10px; font-size: 1rem; transition: border-color 0.3s ease; }
        .form-control:focus { outline: none; border-color: #667eea; box-shadow: 0 0 0 3px rgba(102,126,234,0.1); }
        .btn-register { width: 100%; padding: 1rem; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; border: none; border-radius: 10px; font-size: 1rem; font-weight: 600; cursor: pointer; transition: transform 0.3s ease; }
        .btn-register:hover { transform: translateY(-2px); }
        .register-links { text-align: center; margin-top: 2rem; }
        .register-links a { color: #667eea; text-decoration: none; margin: 0 1rem; }
        .register-links a:hover { text-decoration: underline; }
        .error-message { background: #f8d7da; color: #721c24; padding: 1rem; border-radius: 10px; margin-bottom: 1.5rem; text-align: center; }
        .success-message { background: #d4edda; color: #155724; padding: 1rem; border-radius: 10px; margin-bottom: 1.5rem; text-align: center; }
        @media (max-width: 768px) { .form-row { grid-template-columns: 1fr; } }
    </style>
</head>
<body>
    <!-- Register Container - ສ່ວນບັນຈຸຟອມລົງທະບຽນ -->
    <div class="register-container">
        <div class="register-card">
            <div class="register-header">
                <h1>ສ້າງບັນຊີ</h1>
                <p>ເຂົ້າຮ່ວມລະບົບການຄຸ້ມຄອງທີ່ດິນ PPS</p>
            </div>

            <?php if (!empty($error)): // ສະແດງຂໍ້ຄວາມຜິດພາດຖ້າມີ ?>
            <div class="error-message">
                <?php echo htmlspecialchars($error); ?>
            </div>
            <?php endif; ?>

            <?php if (!empty($success)): // ສະແດງຂໍ້ຄວາມສຳເລັດຖ້າມີ ?>
            <div class="success-message">
                <?php echo htmlspecialchars($success); ?>
            </div>
            <?php else: // ສະແດງຟອມລົງທະບຽນ ?>
            <form method="POST" action="register.php">
                <div class="form-row">
                    <div class="form-group">
                        <label for="first_name" class="form-label">ຊື່ *</label>
                        <input type="text" id="first_name" name="first_name" class="form-control" required 
                               value="<?php echo isset($_POST["first_name"]) ? htmlspecialchars($_POST["first_name"]) : ""; ?>">
                    </div>

                    <div class="form-group">
                        <label for="last_name" class="form-label">ນາມສະກຸນ *</label>
                        <input type="text" id="last_name" name="last_name" class="form-control" required 
                               value="<?php echo isset($_POST["last_name"]) ? htmlspecialchars($_POST["last_name"]) : ""; ?>">
                    </div>
                </div>

                <div class="form-group">
                    <label for="username" class="form-label">ຊື່ຜູ້ໃຊ້ *</label>
                    <input type="text" id="username" name="username" class="form-control" required 
                           value="<?php echo isset($_POST["username"]) ? htmlspecialchars($_POST["username"]) : ""; ?>">
                </div>

                <div class="form-group">
                    <label for="email" class="form-label">ທີ່ຢູ່ອີເມວ *</label>
                    <input type="email" id="email" name="email" class="form-control" required 
                           value="<?php echo isset($_POST["email"]) ? htmlspecialchars($_POST["email"]) : ""; ?>">
                </div>

                <div class="form-group">
                    <label for="phone" class="form-label">ເບີໂທລະສັບ *</label>
                    <input type="tel" id="phone" name="phone" class="form-control" required 
                           value="<?php echo isset($_POST["phone"]) ? htmlspecialchars($_POST["phone"]) : ""; ?>">
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="password" class="form-label">ລະຫັດຜ່ານ *</label>
                        <input type="password" id="password" name="password" class="form-control" required 
                               minlength="<?php echo defined("PASSWORD_MIN_LENGTH") ? PASSWORD_MIN_LENGTH : 8; ?>">
                    </div>

                    <div class="form-group">
                        <label for="confirm_password" class="form-label">ຢືນຢັນລະຫັດຜ່ານ *</label>
                        <input type="password" id="confirm_password" name="confirm_password" class="form-control" required>
                    </div>
                </div>

                <button type="submit" class="btn-register">ສ້າງບັນຊີ</button>
            </form>
            <?php endif; ?>

            <!-- Register Links - ລິ້ງສຳລັບເຂົ້າສູ່ລະບົບຖ້າມີບັນຊີແລ້ວ -->
            <div class="register-links">
                <a href="login.php">ມີບັນຊີແລ້ວບໍ? ເຂົ້າສູ່ລະບົບ</a>
            </div>

            <!-- Back to Home Link - ລິ້ງກັບໄປໜ້າຫຼັກ -->
            <div class="register-links">
                <a href="index.php">← ກັບຄືນໜ້າຫຼັກ</a>
            </div>
        </div>
    </div>

    <script>
        // JavaScript ສຳລັບການກວດສອບລະຫັດຜ່ານ
        const passwordField = document.getElementById("password");
        const confirmPasswordField = document.getElementById("confirm_password");

        if(confirmPasswordField && passwordField) {
            confirmPasswordField.addEventListener("input", function() {
                // ກວດສອບວ່າລະຫັດຜ່ານກົງກັນ
                if (passwordField.value !== this.value) {
                    this.setCustomValidity("ລະຫັດຜ່ານບໍ່ກົງກັນ");
                } else {
                    this.setCustomValidity("");
                }
            });
        }
    </script>

