<?php
// login.php - ໜ້າເຂົ້າສູ່ລະບົບ
// ໄຟລ໌ນີ້ຈັດການການເຂົ້າສູ່ລະບົບຂອງຜູ້ໃຊ້.

// ລວມເອົາໄຟລ໌ການຕັ້ງຄ່າ ແລະ ຟັງຊັນການກວດສອບສິດ
require_once 'config/config.php'; // ໄຟລ໌ການຕັ້ງຄ່າລະບົບ
require_once 'includes/auth.php'; // ຟັງຊັນການກວດສອບສິດ (ເຊັ່ນ: isLoggedIn(), hasRole(), redirect())

// ປ່ຽນເສັ້ນທາງຖ້າຜູ້ໃຊ້ໄດ້ເຂົ້າສູ່ລະບົບແລ້ວ
// isLoggedIn(): ຟັງຊັນນີ້ກວດສອບວ່າຜູ້ໃຊ້ໄດ້ເຂົ້າສູ່ລະບົບແລ້ວບໍ
if (isLoggedIn()) {
    // hasRole(): ຟັງຊັນນີ້ກວດສອບບົດບາດຂອງຜູ້ໃຊ້
    if (hasRole('admin') || hasRole('manager') || hasRole('sales')) {
        // redirect(): ຟັງຊັນນີ້ປ່ຽນເສັ້ນທາງຜູ້ໃຊ້ໄປຍັງໜ້າທີ່ກຳນົດ
        redirect('admin/dashboard.php');
    } else {
        redirect('customer/dashboard.php');
    }
}

// $error: ຕົວແປນີ້ເກັບຂໍ້ຄວາມຜິດພາດສຳລັບການເຂົ້າສູ່ລະບົບ
$error = '';

// ຈັດການການສົ່ງຟອມເມື່ອມີການຮ້ອງຂໍແບບ POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // $username: ຕົວແປນີ້ເກັບຊື່ຜູ້ໃຊ້ທີ່ປ້ອນເຂົ້າມາ (ຖືກກັ່ນຕອງດ້ວຍ sanitizeInput())
    $username = sanitizeInput($_POST['username']);
    // $password: ຕົວແປນີ້ເກັບລະຫັດຜ່ານທີ່ປ້ອນເຂົ້າມາ
    $password = $_POST['password'];
    
    // ກວດສອບວ່າຊື່ຜູ້ໃຊ້ ແລະ ລະຫັດຜ່ານບໍ່ຫວ່າງເປົ່າ
    if (empty($username) || empty($password)) {
        $error = 'ກະລຸນາຕື່ມຂໍ້ມູນໃຫ້ຄົບຖ້ວນ';
    } else {
        // ເຊື່ອມຕໍ່ຖານຂໍ້ມູນ
        // $pdo: ຕົວແປນີ້ຖືກສ້າງຂຶ້ນຈາກຟັງຊັນ getDBConnection() ທີ່ຢູ່ໃນ config/config.php
        $pdo = getDBConnection();
        // ສ້າງ Object ຂອງ Auth
        $auth = new Auth($pdo);
        // login(): ເມທອດນີ້ພະຍາຍາມເຂົ້າສູ່ລະບົບຜູ້ໃຊ້
        if ($auth->login($username, $password)) {
            // ປ່ຽນເສັ້ນທາງຕາມບົດບາດຂອງຜູ້ໃຊ້ຫຼັງຈາກເຂົ້າສູ່ລະບົບສຳເລັດ
            if (hasRole('admin') || hasRole('manager') || hasRole('sales')) {
                redirect('admin/dashboard.php');
            } else {
                redirect('customer/dashboard.php');
            }
        } else {
            $error = 'ຊື່ຜູ້ໃຊ້ ຫຼື ລະຫັດຜ່ານບໍ່ຖືກຕ້ອງ';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ເຂົ້າສູ່ລະບົບ - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .login-container {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 2rem;
        }
        
        .login-card {
            background: white;
            padding: 3rem;
            border-radius: 20px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            width: 100%;
            max-width: 400px;
        }
        
        .login-header {
            text-align: center;
            margin-bottom: 2rem;
        }
        
        .login-header h1 {
            color: #333;
            margin-bottom: 0.5rem;
        }
        
        .login-header p {
            color: #666;
        }
        
        .form-group {
            margin-bottom: 1.5rem;
        }
        
        .form-label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 600;
            color: #333;
        }
        
        .form-control {
            width: 100%;
            padding: 1rem;
            border: 2px solid #e9ecef;
            border-radius: 10px;
            font-size: 1rem;
            transition: border-color 0.3s ease;
        }
        
        .form-control:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102,126,234,0.1);
        }
        
        .btn-login {
            width: 100%;
            padding: 1rem;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.3s ease;
        }
        
        .btn-login:hover {
            transform: translateY(-2px);
        }
        
        .login-links {
            text-align: center;
            margin-top: 2rem;
        }
        
        .login-links a {
            color: #667eea;
            text-decoration: none;
            margin: 0 1rem;
        }
        
        .login-links a:hover {
            text-decoration: underline;
        }
        
        .error-message {
            background: #f8d7da;
            color: #721c24;
            padding: 1rem;
            border-radius: 10px;
            margin-bottom: 1.5rem;
            text-align: center;
        }
    </style>
</head>
<body>
    <!-- Login Container - ສ່ວນບັນຈຸຟອມເຂົ້າສູ່ລະບົບ -->
    <div class="login-container">
        <div class="login-card">
            <div class="login-header">
                <h1>ຍິນດີຕ້ອນຮັບກັບມາ</h1>
                <p>ເຂົ້າສູ່ລະບົບບັນຊີຂອງທ່ານ</p>
            </div>
            
            <?php if ($error): // ສະແດງຂໍ້ຄວາມຜິດພາດຖ້າມີ ?>
            <div class="error-message">
                <?php echo htmlspecialchars($error); ?>
            </div>
            <?php endif; ?>
            
            <!-- Login Form - ແບບຟອມເຂົ້າສູ່ລະບົບ -->
            <form method="POST">
                <div class="form-group">
                    <label for="username" class="form-label">ຊື່ຜູ້ໃຊ້</label>
                    <input type="text" id="username" name="username" class="form-control" required 
                           value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>">
                </div>
                
                <div class="form-group">
                    <label for="password" class="form-label">ລະຫັດຜ່ານ</label>
                    <input type="password" id="password" name="password" class="form-control" required>
                </div>
                
                <button type="submit" class="btn-login">ເຂົ້າສູ່ລະບົບ</button>
            </form>
            
            <!-- Login Links - ລິ້ງສຳລັບລົງທະບຽນ ແລະ ລືມລະຫັດຜ່ານ -->
            <div class="login-links">
                <a href="register.php">ສ້າງບັນຊີ</a>
                <a href="forgot-password.php">ລືມລະຫັດຜ່ານ?</a>
            </div>
            
            <!-- Back to Home Link - ລິ້ງກັບໄປໜ້າຫຼັກ -->
            <div class="login-links">
                <a href="index.php">← ກັບຄືນໜ້າຫຼັກ</a>
            </div>
            
            <!-- Demo Accounts Information - ຂໍ້ມູນບັນຊີຕົວຢ່າງ -->
            <div style="margin-top: 2rem; padding: 1rem; background: #f8f9fa; border-radius: 10px; font-size: 0.9rem; color: #666;">
                <strong>ບັນຊີຕົວຢ່າງ:</strong><br>
                Admin: admin / admin123<br>
                Customer: ລົງທະບຽນບັນຊີໃໝ່
            </div>
        </div>
    </div>
</body>
</html>


