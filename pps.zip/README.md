# PPS Land Management System

A comprehensive land management system built with PHP and MySQL for managing real estate projects, land plots, customers, and sales.

## Features

### Public Website
- **Homepage**: Modern landing page with project showcase and interactive map
- **Project Listings**: Browse all development projects with filtering and search
- **Land Plot Search**: Advanced search with filters for price, area, location
- **Customer Portal**: Registration, login, favorites, and purchase history
- **Interactive Maps**: Google Maps integration for project locations
- **Responsive Design**: Mobile-friendly interface

### Admin Dashboard
- **Project Management**: Create, edit, and manage development projects
- **Plot Management**: Manage individual land plots with pricing and status
- **Customer Management**: Customer database with purchase history
- **Lead Management**: Track and convert leads from various sources
- **Employee Management**: Staff management with performance tracking
- **Sales Management**: Record and track all sales transactions
- **Media Management**: Upload and manage images, videos, documents
- **Reports & Analytics**: Comprehensive reporting with charts and exports
- **User Management**: Role-based access control

### Key Capabilities
- **File Upload System**: Support for images, videos, and documents
- **Search & Filtering**: Advanced search with multiple criteria
- **Favorites System**: Customers can save favorite plots
- **Interactive Maps**: Project and plot location mapping
- **Reporting System**: Sales, customer, and performance analytics
- **Export Functionality**: CSV export for all major reports
- **Responsive Design**: Works on desktop, tablet, and mobile

## Technology Stack

- **Backend**: PHP 7.4+ (Traditional, non-MVC architecture)
- **Database**: MySQL 5.7+
- **Frontend**: HTML5, CSS3, JavaScript (ES6+)
- **Maps**: Google Maps API integration
- **Charts**: Chart.js for analytics visualization
- **File Upload**: Custom PHP upload handler with image processing

## Installation

### Requirements
- PHP 7.4 or higher
- MySQL 5.7 or higher
- Apache/Nginx web server
- GD extension for image processing
- PDO MySQL extension

### Setup Instructions

1. **Extract Files**
   ```bash
   unzip pps-land-management.zip
   cd pps-land-management
   ```

2. **Database Setup**
   - Create a new MySQL database
   - Import the provided SQL file:
   ```bash
   mysql -u username -p database_name < ppsapp.sql
   ```

3. **Configuration**
   - Edit `config/database.php` with your database credentials:
   ```php
   define('DB_HOST', 'localhost');
   define('DB_NAME', 'your_database_name');
   define('DB_USER', 'your_username');
   define('DB_PASS', 'your_password');
   ```

4. **File Permissions**
   ```bash
   chmod 755 uploads/
   chmod 755 uploads/images/
   chmod 755 uploads/videos/
   chmod 755 uploads/documents/
   ```

5. **Web Server Configuration**
   - Point your web server document root to the project directory
   - Ensure mod_rewrite is enabled for Apache

6. **Initial Setup**
   - Visit `install.php` in your browser to set up the database
   - Default admin credentials:
     - Username: `admin`
     - Password: `admin123`

## File Structure

```
pps-land-management/
├── admin/                  # Admin dashboard
│   ├── dashboard.php      # Main admin dashboard
│   ├── projects.php       # Project management
│   ├── plots.php          # Plot management
│   ├── customers.php      # Customer management
│   ├── leads.php          # Lead management
│   ├── employees.php      # Employee management
│   ├── sales.php          # Sales management
│   ├── media.php          # Media management
│   ├── reports.php        # Reports & analytics
│   └── login.php          # Admin login
├── api/                   # API endpoints
│   ├── search.php         # Search functionality
│   ├── favorites.php      # Favorites management
│   ├── maps.php           # Maps data
│   └── upload.php         # File upload handler
├── assets/                # Static assets
│   ├── css/
│   │   └── style.css      # Main stylesheet
│   ├── js/
│   │   ├── main.js        # Core JavaScript
│   │   ├── maps.js        # Maps functionality
│   │   └── search.js      # Search functionality
│   └── images/            # Static images
├── config/                # Configuration files
│   ├── config.php         # Main configuration
│   └── database.php       # Database configuration
├── customer/              # Customer portal
│   ├── dashboard.php      # Customer dashboard
│   ├── favorites.php      # Customer favorites
│   └── profile.php        # Customer profile
├── includes/              # PHP classes and functions
│   ├── auth.php           # Authentication
│   ├── project.php        # Project management
│   ├── plot.php           # Plot management
│   ├── customer.php       # Customer management
│   ├── employee.php       # Employee management
│   ├── lead.php           # Lead management
│   ├── upload.php         # File upload
│   └── reports.php        # Reporting system
├── uploads/               # Upload directory
│   ├── images/            # Image uploads
│   ├── videos/            # Video uploads
│   └── documents/         # Document uploads
├── index.php              # Homepage
├── projects.php           # Project listings
├── plots.php              # Plot search
├── login.php              # User login
├── register.php           # User registration
├── logout.php             # Logout handler
├── install.php            # Database installer
├── ppsapp.sql             # Database schema
└── README.md              # This file
```

## Default Users

### Admin User
- **Username**: `admin`
- **Password**: `admin123`
- **Role**: Administrator
- **Access**: Full system access

### Test Customer
- **Username**: `customer`
- **Password**: `customer123`
- **Role**: Customer
- **Access**: Customer portal only

## Configuration Options

### Database Settings (`config/database.php`)
```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'pps_land_db');
define('DB_USER', 'username');
define('DB_PASS', 'password');
```

### General Settings (`config/config.php`)
```php
define('SITE_NAME', 'PPS Land Management System');
define('ADMIN_EMAIL', 'admin@ppsland.com');
define('UPLOAD_PATH', __DIR__ . '/../uploads/');
define('MAX_FILE_SIZE', 10 * 1024 * 1024); // 10MB
```

### File Upload Settings
- **Max File Size**: 10MB (configurable)
- **Allowed Image Types**: jpg, jpeg, png, gif, webp
- **Allowed Video Types**: mp4, avi, mov, wmv
- **Allowed Document Types**: pdf, doc, docx, txt

## API Endpoints

### Search API (`/api/search.php`)
- **Method**: GET
- **Parameters**: search, project_id, status, min_price, max_price, min_area, max_area
- **Response**: JSON with search results

### Favorites API (`/api/favorites.php`)
- **Methods**: GET, POST
- **Actions**: add, remove, toggle
- **Authentication**: Required

### Maps API (`/api/maps.php`)
- **Actions**: projects, project_details
- **Response**: JSON with location data

### Upload API (`/api/upload.php`)
- **Method**: POST
- **Actions**: upload, upload_multiple, delete, list, info
- **Authentication**: Admin required

## Security Features

- **SQL Injection Protection**: Prepared statements throughout
- **XSS Prevention**: Input sanitization and output escaping
- **CSRF Protection**: Session-based token validation
- **File Upload Security**: Type validation and secure storage
- **Role-Based Access**: Admin and customer role separation
- **Password Hashing**: Secure password storage with PHP password_hash()

## Customization

### Adding New Fields
1. Update database schema
2. Modify relevant PHP classes in `includes/`
3. Update forms and display templates
4. Add validation rules

### Styling Customization
- Main styles in `assets/css/style.css`
- Responsive design with CSS Grid and Flexbox
- CSS custom properties for easy theming

### Adding New Features
1. Create new PHP files following existing patterns
2. Add database tables if needed
3. Update navigation menus
4. Add appropriate access controls

## Troubleshooting

### Common Issues

1. **Database Connection Error**
   - Check database credentials in `config/database.php`
   - Ensure MySQL service is running
   - Verify database exists and user has permissions

2. **File Upload Issues**
   - Check directory permissions (755 for uploads/)
   - Verify PHP upload settings (upload_max_filesize, post_max_size)
   - Check available disk space

3. **Login Problems**
   - Clear browser cookies and session data
   - Check database user table for correct credentials
   - Verify session configuration in PHP

4. **Map Not Loading**
   - Google Maps API key required for production
   - Check browser console for JavaScript errors
   - Verify internet connection for external resources

### Error Logs
- PHP errors logged to system error log
- Application errors logged in database
- Check browser console for JavaScript errors

## Performance Optimization

### Database
- Indexes on frequently queried columns
- Optimized queries with proper JOINs
- Connection pooling for high traffic

### File Handling
- Image resizing and compression
- Thumbnail generation for faster loading
- CDN integration ready

### Caching
- Browser caching headers set
- Static asset optimization
- Database query result caching ready

## Support

For technical support or questions:
- Check the troubleshooting section above
- Review error logs for specific issues
- Ensure all requirements are met

## License

This project is proprietary software developed for PPS Land Management System.

## Version History

### v1.0.0 (Current)
- Initial release
- Complete land management system
- Admin dashboard and customer portal
- Interactive maps and search functionality
- Comprehensive reporting system
- File upload and media management

---

**Note**: This system is designed for production use with proper server configuration and security measures. Always use HTTPS in production and keep software updated.

